-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 28, 2021 at 03:26 PM
-- Server version: 8.0.18
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `parkfinder`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `adminId` int(11) NOT NULL,
  `adminName` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `adminEmail` varchar(150) COLLATE utf8mb4_general_ci NOT NULL,
  `adminCin` varchar(9) COLLATE utf8mb4_general_ci NOT NULL,
  `adminGender` varchar(6) COLLATE utf8mb4_general_ci NOT NULL,
  `adminBirth` date NOT NULL,
  `adminCity` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `adminPhone` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `adminPassword` varchar(60) COLLATE utf8mb4_general_ci NOT NULL,
  `adminSup` tinyint(1) NOT NULL DEFAULT '0',
  `adminStatus` tinyint(1) NOT NULL DEFAULT '1',
  `adminCreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`adminId`, `adminName`, `adminEmail`, `adminCin`, `adminGender`, `adminBirth`, `adminCity`, `adminPhone`, `adminPassword`, `adminSup`, `adminStatus`, `adminCreate`) VALUES
(11, 'last1', 'admin@admin.com', 'test1', 'Male', '2000-02-22', 'test', '123', '1', 1, 1, '2021-06-20 20:45:18'),
(15, 'last', 'last@last.com', 'last', 'Male', '2000-02-22', 'casav', '12345678', '1', 1, 0, '2021-06-28 11:22:20'),
(17, 'dazda', 'dzad@dd.com', 'dazdza', 'Male', '2000-02-22', 'dzadaz', '123', '1', 0, 0, '2021-06-28 15:05:35');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageId` int(11) NOT NULL,
  `userName` varchar(60) COLLATE utf8mb4_general_ci NOT NULL,
  `userEmail` varchar(160) COLLATE utf8mb4_general_ci NOT NULL,
  `messageCategory` text COLLATE utf8mb4_general_ci NOT NULL,
  `message` text COLLATE utf8mb4_general_ci NOT NULL,
  `userPhoto` text COLLATE utf8mb4_general_ci NOT NULL,
  `messageStatus` tinyint(1) NOT NULL DEFAULT '0',
  `messageCreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`messageId`, `userName`, `userEmail`, `messageCategory`, `message`, `userPhoto`, `messageStatus`, `messageCreate`) VALUES
(1, 'test123', 'test@test.com', 'Request quotation', 'dzadzafzaf\r\n', 'img/user1.png', 0, '2021-06-26 09:38:16'),
(2, 'test123', 'test@test.com', 'Other', 'dzazadzadza', '', 0, '2021-06-26 22:28:43'),
(3, 'test123', 'test@test.com', 'Request quotation', 'dzadzadzaza', '', 0, '2021-06-26 22:31:24'),
(4, 'test123', 'test@test.com', 'Request order status', 'dzadzad', '', 0, '2021-06-26 22:32:01'),
(5, 'test123', 'test@test.com', 'Request quotation', 'dzadza', '', 0, '2021-06-26 22:33:39'),
(6, 'test123', 'test@test.com', 'Request order status', 'dzdzadza', '', 0, '2021-06-26 22:34:45'),
(7, 'test123', 'test@test.com', 'Request copy of an invoice', 'dzadazdzadzadza', 'img/user1.png', 0, '2021-06-26 22:37:54'),
(8, 'test123', 'test@test.com', 'Request copy of an invoice', 'dzadzadaz', 'img/user1.png', 0, '2021-06-26 22:38:25'),
(9, 'test123', 'test@test.com', 'Request copy of an invoice', 'test', 'img/user1.png', 0, '2021-06-27 15:11:02'),
(10, 'user', 'test@test.com', 'Other', 'Last', 'img/user1.png', 0, '2021-06-28 14:36:13'),
(11, 'z', 'z1@z.com', 'Request order status', 'dadazd', 'img/user1.png', 0, '2021-06-28 14:52:55');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notificationsId` int(11) NOT NULL,
  `notificationsName` text COLLATE utf8mb4_general_ci NOT NULL,
  `notificationsDescription` text COLLATE utf8mb4_general_ci NOT NULL,
  `userName` varchar(60) COLLATE utf8mb4_general_ci NOT NULL,
  `notificationsStatus` tinyint(1) NOT NULL DEFAULT '0',
  `notificationsCreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notificationsId`, `notificationsName`, `notificationsDescription`, `userName`, `notificationsStatus`, `notificationsCreate`) VALUES
(1, 'Reservation has been added successfully', 'Hey test123 Your Reservation has been added successfully , have greate day! \n Parking Name : mall \n Departure Time : 15:43 \n Arrival Time : 15:43 \n Car Number : dzadza', 'test123', 1, '2021-06-27 14:43:06'),
(5, 'Reservation has been canceled successfully', 'Hey test123 Your Reservation has been canceled successfully', 'test123', 1, '2021-06-27 14:53:07'),
(6, 'Balance has been added successfully', 'Hey test123 You have added 20 Dh to Your Balance. Have a greate Day!', 'test123', 1, '2021-06-27 15:03:29'),
(7, 'Balance has been added successfully', 'Hey test123 You have added 20 Dh to Your Balance. Have a greate Day!', 'test123', 1, '2021-06-27 15:04:35'),
(8, 'Balance has been added successfully', 'Hey test123 You have added 50 Dh to Your Balance. Have a greate Day!', 'test123', 1, '2021-06-27 15:04:46'),
(9, 'Your Message has been added successfully', 'Hey , Your Message has been added successfully, have great Day! \n Message Category : Request copy of an invoice \n Your Message : test', 'test123', 1, '2021-06-27 15:11:02'),
(12, 'Balance has been added successfully', 'Hey Last You have added 20 Dh to Your Balance. Have a greate Day!', 'Last', 1, '2021-06-28 11:41:20'),
(13, 'Reservation has been added successfully', 'Hey Last Your Reservation has been added successfully , have greate day! \n|| Parking Name : mall \n|| Departure Time : 12:42 \n|| Arrival Time : 12:44 \n|| Car Number : Usususis', 'Last', 1, '2021-06-28 11:42:08'),
(14, 'Balance has been added successfully', 'Hey Last You have added 500 Dh to Your Balance. Have a greate Day!', 'Last', 1, '2021-06-28 11:42:24'),
(15, 'Reservation has been canceled successfully . Have a great Day !', 'Hey Last Your Reservation has been canceled successfully', 'Last', 1, '2021-06-28 11:43:35'),
(16, 'Balance has been added successfully', 'Hey user You have added 50 Dh to Your Balance. Have a greate Day!', 'user', 1, '2021-06-28 13:42:01'),
(17, 'Reservation has been added successfully', 'Hey user Your Reservation has been added successfully , have greate day! \n|| Parking Name : mall \n|| Departure Time : 15:35 \n|| Arrival Time : 15:35 \n|| Car Number : Usueuwuw', 'user', 0, '2021-06-28 14:35:37'),
(18, 'Reservation has been canceled successfully . Have a great Day !', 'Hey user Your Reservation has been canceled successfully', 'user', 0, '2021-06-28 14:35:53'),
(19, 'Balance has been added successfully', 'Hey user You have added 20 Dh to Your Balance. Have a greate Day!', 'user', 1, '2021-06-28 14:35:59'),
(20, 'Your Message has been added successfully', 'Hey , Your Message has been added successfully, have great Day! \n Message Category : Other \n Your Message : Last', 'user', 0, '2021-06-28 14:36:13'),
(21, 'Reservation has been added successfully', 'Hey user Your Reservation has been added successfully , have greate day! \n|| Parking Name : mall \n|| Departure Time : 15:38 \n|| Arrival Time : 15:38 \n|| Car Number : Isisieie', 'user', 0, '2021-06-28 14:38:17'),
(22, 'Reservation has been added successfully', 'Hey user Your Reservation has been added successfully , have greate day! \n|| Parking Name : testa \n|| Departure Time : 15:45 \n|| Arrival Time : 15:45 \n|| Car Number : Hshshshs', 'user', 0, '2021-06-28 14:45:21'),
(23, 'Reservation has been added successfully', 'Hey user Your Reservation has been added successfully , have greate day! \n|| Parking Name : mall \n|| Departure Time : 15:48 \n|| Arrival Time : 15:48 \n|| Car Number : Dududu', 'user', 0, '2021-06-28 14:48:29'),
(24, 'Reservation has been added successfully', 'Hey user Your Reservation has been added successfully , have greate day! \n|| Parking Name : testa \n|| Departure Time : 15:50 \n|| Arrival Time : 15:50 \n|| Car Number : Iwiiwiw', 'user', 0, '2021-06-28 14:50:45'),
(25, 'Balance has been added successfully', 'Hey z You have added 20 Dh to Your Balance. Have a greate Day!', 'z', 0, '2021-06-28 14:51:59'),
(26, 'Reservation has been added successfully', 'Hey z Your Reservation has been added successfully , have greate day! \n|| Parking Name : mall \n|| Departure Time : 15:52 \n|| Arrival Time : 03:52 \n|| Car Number : dzdzdaz', 'z', 0, '2021-06-28 14:52:39'),
(27, 'Reservation has been canceled successfully . Have a great Day !', 'Hey z Your Reservation has been canceled successfully', 'z', 0, '2021-06-28 14:52:47'),
(28, 'Your Message has been added successfully', 'Hey , Your Message has been added successfully, have great Day! \n Message Category : Request order status \n Your Message : dadazd', 'z', 0, '2021-06-28 14:52:55'),
(29, 'Reservation has been canceled successfully . Have a great Day !', 'Hey user Your Reservation has been canceled successfully', 'user', 1, '2021-06-28 14:53:45'),
(30, 'Reservation has been added successfully', 'Hey user Your Reservation has been added successfully , have greate day! \n|| Parking Name : mall \n|| Departure Time : 16:01 \n|| Arrival Time : 16:01 \n|| Car Number : Heheheje', 'user', 1, '2021-06-28 15:01:02'),
(31, 'Support', 'Hey z ,jkkjfez', 'z', 1, '2021-06-28 15:06:20');

-- --------------------------------------------------------

--
-- Table structure for table `parkings`
--

CREATE TABLE `parkings` (
  `parkingId` int(11) NOT NULL,
  `parkingName` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `parkingDescription` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `parkingGps` text COLLATE utf8mb4_general_ci NOT NULL,
  `parkingCapacity` int(11) NOT NULL,
  `parkingPhoto` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `parkingStatus` tinyint(1) NOT NULL DEFAULT '0',
  `parkingCreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parkings`
--

INSERT INTO `parkings` (`parkingId`, `parkingName`, `parkingDescription`, `parkingGps`, `parkingCapacity`, `parkingPhoto`, `parkingStatus`, `parkingCreate`) VALUES
(6, 'w', 'test123', '-7.580670, 33.573728', 123, 'test', 0, '2021-06-21 11:58:34'),
(8, 'mall', 'parking mall', '-7.707085180525899, 33.576655523068226, ', 50, 'images/mall.jpg', 1, '2021-06-24 13:43:30');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `reservationId` int(11) NOT NULL,
  `userName` varchar(60) COLLATE utf8mb4_general_ci NOT NULL,
  `parkingName` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `parkingPhoto` text COLLATE utf8mb4_general_ci NOT NULL,
  `departureTime` time NOT NULL,
  `arrivalTime` time NOT NULL,
  `carNumber` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `reservationStatus` tinyint(1) NOT NULL DEFAULT '1',
  `reservationCrate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`reservationId`, `userName`, `parkingName`, `parkingPhoto`, `departureTime`, `arrivalTime`, `carNumber`, `reservationStatus`, `reservationCrate`) VALUES
(73, 'test123', 'mall', 'images/mall.jpg', '00:06:00', '00:06:00', 'dadzadzad', 1, '2021-06-26 23:06:37'),
(74, 'test2', 'mall', 'images/mall.jpg', '03:12:00', '03:13:00', '0123456', 1, '2021-06-27 02:13:02'),
(75, 'test2', 'mall', 'images/mall.jpg', '12:39:00', '00:39:00', 'ABCDEF', 1, '2021-06-27 11:39:50'),
(76, 'test123', 'mall', 'images/mall.jpg', '14:22:00', '14:22:00', 'abcdef', 1, '2021-06-27 13:22:03'),
(77, 'test123', 'mall', 'images/mall.jpg', '15:43:00', '15:43:00', 'dzadza', 0, '2021-06-27 14:43:06'),
(78, 'Last', 'mall', 'images/mall.jpg', '12:42:00', '12:44:00', 'Usususis', 0, '2021-06-28 11:42:08'),
(79, 'user', 'mall', 'images/mall.jpg', '15:35:00', '15:35:00', 'Usueuwuw', 0, '2021-06-28 14:35:37'),
(80, 'user', 'mall', 'images/mall.jpg', '15:38:00', '15:38:00', 'Isisieie', 1, '2021-06-28 14:38:17'),
(81, 'user', 'testa', 'test', '15:45:00', '15:45:00', 'Hshshshs', 0, '2021-06-28 14:45:21'),
(82, 'user', 'mall', 'images/mall.jpg', '15:48:00', '15:48:00', 'Dududu', 1, '2021-06-28 14:48:29'),
(83, 'user', 'testa', 'test', '15:50:00', '15:50:00', 'Iwiiwiw', 1, '2021-06-28 14:50:45'),
(84, 'z', 'mall', 'images/mall.jpg', '15:52:00', '03:52:00', 'dzdzdaz', 0, '2021-06-28 14:52:39'),
(85, 'user', 'mall', 'images/mall.jpg', '16:01:00', '16:01:00', 'Heheheje', 1, '2021-06-28 15:01:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `userName` varchar(60) COLLATE utf8mb4_general_ci NOT NULL,
  `userEmail` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `userCin` varchar(9) COLLATE utf8mb4_general_ci NOT NULL,
  `userGender` varchar(6) COLLATE utf8mb4_general_ci NOT NULL,
  `userBirth` date NOT NULL,
  `userCity` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `userPhone` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `userPhoto` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'img/user1.png',
  `userSolde` int(11) NOT NULL DEFAULT '0',
  `userTotalReservation` int(11) NOT NULL DEFAULT '0',
  `userTotalCount` int(11) NOT NULL DEFAULT '0',
  `userPassword` varchar(60) COLLATE utf8mb4_general_ci NOT NULL,
  `userStatus` tinyint(1) NOT NULL DEFAULT '1',
  `userConfirmation` tinyint(1) NOT NULL DEFAULT '0',
  `userCreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `userName`, `userEmail`, `userCin`, `userGender`, `userBirth`, `userCity`, `userPhone`, `userPhoto`, `userSolde`, `userTotalReservation`, `userTotalCount`, `userPassword`, `userStatus`, `userConfirmation`, `userCreate`) VALUES
(1, 'user', 'test@test.com', 'as', 'Male', '2000-02-22', 'city', '123456', 'img/user1.png', 3370, 59, 45, '1', 1, 0, '2021-06-19 16:20:10'),
(2, 'test2', 'test2@test.com', 'test', 'Male', '2000-02-22', 'cca', '123456', 'img/user1.png', 220, 2, 0, '1', 1, 0, '2021-06-19 18:16:03'),
(3, 'Test3', 'test3@test.com', 'Test3', 'Male', '2000-06-21', 'cca', '123456', 'img/user1.png', 1, 1, 0, '2', 1, 0, '2021-06-20 23:01:02'),
(4, 'J', 's@h.com', 'Hsjd', 'Male', '1998-11-09', 'cca', '123456', 'img/user1.png', 0, 0, 0, '2', 1, 0, '2021-06-21 09:11:42'),
(5, 'test', 'test@test3.com', 'abc', 'Female', '2000-02-02', 'cca', '123456', 'img/user1.png', 20, 0, 0, '2', 1, 0, '2021-06-21 10:16:31'),
(6, 'test4', 'test4@test.com', 'test4', 'Female', '2000-10-20', 'cca', '123456', 'img/user1.png', 500, 0, 0, '2', 1, 0, '2021-06-21 10:29:50'),
(7, 'T', 'tabitmohamed28@gmail.com', 'Bk652890', 'Male', '1992-05-19', 'cca', '123456', 'img/user1.png', 0, 0, 0, '2', 1, 0, '2021-06-24 15:30:35'),
(8, 'name', 'name@name.com', 'a123', 'Male', '2000-11-11', 'cca', '123456', 'img/user1.png', 0, 0, 0, '2', 1, 0, '2021-06-26 16:08:20'),
(9, 'z', 'z@z.com', 'adda', 'Male', '2000-02-22', 'abcd', '1', 'img/user1.png', 0, 1, 5, '1', 1, 0, '2021-06-27 13:48:43'),
(10, 'z', 'z1@z.com', 'adda', 'Male', '2000-02-22', 'abcd', '123', 'img/user1.png', 20, 1, 5, '0', 1, 0, '2021-06-27 13:49:49'),
(11, 'Last', 'last@last.com', 'Abc293773', 'Male', '2001-06-28', 'Casablanca', '08552', 'img/user1.png', 520, 1, 5, '12', 1, 0, '2021-06-28 11:40:22'),
(12, 'azdda', 'dzadza@dazdza.com', 'dazdza', 'Male', '2000-01-22', 'dzaza', '1234', 'img/user1.png', 0, 0, 0, '1', 1, 0, '2021-06-28 14:54:59'),
(13, 'Heheh', 'hhed@udud.com', 'Hdhd', 'Male', '2000-06-28', 'Bdbzbs', '167', 'img/user1.png', 0, 0, 0, '1', 1, 0, '2021-06-28 15:03:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageId`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notificationsId`);

--
-- Indexes for table `parkings`
--
ALTER TABLE `parkings`
  ADD PRIMARY KEY (`parkingId`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`reservationId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notificationsId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `parkings`
--
ALTER TABLE `parkings`
  MODIFY `parkingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `reservationId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
