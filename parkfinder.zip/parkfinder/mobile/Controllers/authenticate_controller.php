<?php

require '../Models/User.php';
require '../Models/functions.inc.php';


if (isset($_POST['save'])) {
    $userName = isset($_POST['name']) ? $_POST['name'] : "";
    $userEmail = isset($_POST['email']) ? $_POST['email'] : "" ;
    $userCin = isset($_POST['cin']) ? $_POST['cin']:"" ;
    $userGender = isset($_POST['gender']) ? $_POST['gender']:"" ;
    $userBirth = isset($_POST['birth']) ? $_POST['birth'] : "" ;
    $userCity = isset($_POST['city']) ? $_POST['city'] : "" ;
    $userPhone = isset($_POST['phone'])? $_POST['phone'] : "";
    $userPassword = isset($_POST['pass'])? $_POST['pass'] : "";
    $userPasswordrpt = isset($_POST['passrpt'])? $_POST['passrpt'] : "";



    if (emptyInputRegister($userName, $userEmail, $userCin, $userGender, $userBirth, $userCity, $userPhone, $userPassword, $userPasswordrpt) !== false) {
        header("location:../signup.php?error=empty inptut");
        exit();
    }
    if (invalidName($userName) !== false) {
        header("location:../signup.php?error=invalid name");
        exit();
    }
    if (invalidEmail($userEmail) !== false) {
        header("location:../signup.php?error=invalid email");
        exit();
    }
    if (invalidNumber($userPhone) !== false) {
        header("location:../signup.php?error=invalid phone");
        exit();
    }

    if (passMatch($userPassword, $userPasswordrpt) !== false) {
        header("location:../signup.php?error=passwords dont match");
        exit();
    }

    $user = new user(0, $userName, $userEmail, $userCin, $userGender, $userBirth, $userCity, $userPhone, $userPhoto, $userSolde, $userTotalReservation, $userTotalCount, $userPassword, $userStatus, $userConfirmation, $userCreate);

    $userAdded = $user->userRegisterLogic();
    if($userAdded){
        //$_SESSION['currentUser'] = $user;
        header("Location: ../thankyou.php");
    }
    else{
        //print_r($user);
        //print_r($userAdded );
        header("Location:../signup.php?error=Error:User already exists");
    }
}

if (isset($_POST['update'])) {
    //$userId = $_POST['update'];
/*    $userName = isset($_POST['name']) ? $_POST['name'] : "";
    $userEmail = isset($_POST['email']) ? $_POST['email'] : "" ;
    $userCin = isset($_POST['cin']) ? $_POST['cin']:"" ;
    $userGender = isset($_POST['gender']) ? $_POST['gender']:"" ;
    $userBirth = isset($_POST['birth']) ? $_POST['birth'] : "" ; */
    $userCity = isset($_POST['city']) ? $_POST['city'] : "" ;
    $userPhone = isset($_POST['phone'])? $_POST['phone'] : "";
    $userPassword = isset($_POST['password'])? $_POST['password'] : "";
    $userNPassword = isset($_POST['npassword'])? $_POST['npassword'] : "";
    $userPasswordrpt = isset($_POST['cpassword'])? $_POST['cpassword'] : "";

    /* print_r($userCity);
    print_r($userPhone);
    print_r($userPassword);
    print_r($userNPassword);
    print_r($userPasswordrpt);  */
    if(checkCPass($userPassword , $userCPassword) !== false) {
        header("location:../profile.php?error=passwords current dont match");
        exit();
    }
    if (passMatch($userNPassword, $userPasswordrpt) !== false) {
        header("location:../profile.php?error=passwords dont match");
        exit();
    }
    $user = new user($userId, null, null, null, null, null, $userCity, $userPhone, null, null, null, null, $userPasswordrpt, null, null, null);

    $userUpdated = $user->editUserById();
    if($userUpdated){
        header("Location: ../logout.php");
        //print($userUpdated);
        //print_r($user);
    }
    else{
        /* print($userUpdated);
        print_r($user);
        print_r($userUpdated);
        printf($userUpdated); */
        
        header("Location:../profile.php?error=Error");
    }
} 
if (isset($_GET['add20solde'])) {
    //echo("add20solde");
    $userId = $_GET['add20solde'];
    //$user = new User($userId, $userName, $userEmail, $userCin, $userGender, $userBirth, $userCity, $userPhone, $userPhoto, $userSolde, $userTotalReservation, $userPassword, $userStatus, $userCreate);
    //print_r($user);
    $user = new user($userId, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    $add20SoldeByUser = $user->add20SoldeById($userId);
    if($add20SoldeByUser){
        header("Location: ../index.php");
    }
    else{        
        //print_r($user);
        header("Location:../pricing.php?error=Error");
    }
        
}
if (isset($_GET['add50solde'])) {
    //echo("add20solde");
    $userId = $_GET['add50solde'];
    //$user = new User($userId, $userName, $userEmail, $userCin, $userGender, $userBirth, $userCity, $userPhone, $userPhoto, $userSolde, $userTotalReservation, $userPassword, $userStatus, $userCreate);
    //print_r($user);
    $user = new user($userId, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    $add50SoldeByUser = $user->add50SoldeById($userId);
    if($add50SoldeByUser){
        header("Location: ../index.php");
    }
    else{        
        //print_r($user);
        //header("Location:../pricing.php?error=Error");
    }
        
}
if (isset($_GET['add100solde'])) {
    //echo("add20solde");
    $userId = $_GET['add100solde'];
    //$user = new User($userId, $userName, $userEmail, $userCin, $userGender, $userBirth, $userCity, $userPhone, $userPhoto, $userSolde, $userTotalReservation, $userPassword, $userStatus, $userCreate);
    //print_r($user);
    $user = new user($userId, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    $add100SoldeByUser = $user->add100SoldeById($userId);
    if($add100SoldeByUser){
        header("Location: ../index.php");
    }
    else{        
        //print_r($user);
        //header("Location:../pricing.php?error=Error");
    }
        
}
if (isset($_GET['add300solde'])) {
    //echo("add20solde");
    $userId = $_GET['add300solde'];
    //$user = new User($userId, $userName, $userEmail, $userCin, $userGender, $userBirth, $userCity, $userPhone, $userPhoto, $userSolde, $userTotalReservation, $userPassword, $userStatus, $userCreate);
    //print_r($user);
    $user = new user($userId, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    $add300SoldeByUser = $user->add300SoldeById($userId);
    if($add300SoldeByUser){
        header("Location: ../index.php");
    }
    else{        
        //print_r($user);
        //header("Location:../pricing.php?error=Error");
    }
        
}
if (isset($_GET['add500solde'])) {
    //echo("add20solde");
    $userId = $_GET['add500solde'];
    //$user = new User($userId, $userName, $userEmail, $userCin, $userGender, $userBirth, $userCity, $userPhone, $userPhoto, $userSolde, $userTotalReservation, $userPassword, $userStatus, $userCreate);
    //print_r($user);
    $user = new user($userId, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
    $add500SoldeByUser = $user->add500SoldeById($userId);
    if($add500SoldeByUser){
        header("Location: ../index.php");
    }
    else{        
        //print_r($user);
        //header("Location:../pricing.php?error=Error");
    }
        
}
?>