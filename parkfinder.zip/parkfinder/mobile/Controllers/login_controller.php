<?php

require '../Models/User.php';
require_once '../Models/functions.inc.php';


$userEmail = isset($_POST['email']) ? $_POST['email'] : "";
$userPassword = isset($_POST['password']) ? $_POST['password']: "";




$tempUser = User::getUserByMailAndPassword($userEmail, $userPassword);

if($userEmail == '' || $userPassword == ''){
    header("Location: ../login.php?error=Both mail and password are mandatory");
exit();
}



$user = new User($tempUser->userId, $tempUser->userName, $tempUser->userEmail, $tempUser->userCin, $tempUser->userGender, $tempUser->userBirth, $tempUser->userCity, $tempUser->userPhone, $tempUser->userPhoto, $tempUser->userSolde, $tempUser->userTotalReservation, $tempUser->userTotalCount, $tempUser->userPassword, $tempUser->userStatus, $tempUser->userConfirmation, $tempUser->userCreate);
print_r($user);
if($user->UserLoginLogic()){
    //$_SESSION['currentUser'] = $user;
    $currentUser = array(
        'userId'=>$tempUser->userId,
        'userName'=>$tempUser->userName,
        'userEmail'=>$tempUser->userEmail,
        'userCin'=>$tempUser->userCin,
        'userGender'=>$tempUser->userGender,
        'userBirth'=>$tempUser->userBirth,
        'userCity'=>$tempUser->userCity,
        'userPhone'=>$tempUser->userPhone,
        'userPhoto'=>$tempUser->userPhoto,
        'userSolde'=>$tempUser->userSolde,
        'userTotalReservation'=>$tempUser->userTotalReservation,
        'userPassword'=>$tempUser->userPassword,
        'userStatus'=>$tempUser->userStatus,
        'userConfirmation'=>$tempUser->userConfirmation,
        'userCreate'=>$tempUser->userCreate,
        
    );
    
    $_SESSION['currentUser'] = $currentUser;
    //
    //echo "----------------------------------------";
    //print_r($currentUser);

    header("Location: ../index.php");
}
else{
    
    header("location: ../login.php?error=Incorrect mail or password, please try again");
} 

?>