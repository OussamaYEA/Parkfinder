<?php

require '../Models/Message.php';

if (isset($_POST['send'])) {
    $messageCategory = isset($_POST['mcategory']) ? $_POST['mcategory']:"" ;
    $message = isset($_POST['message']) ? $_POST['message']:"" ;

    /* if (emptyInputReservation($parkingName, $departureTime, $arrivalTime, $carNumber) !== false) {
        header("location:../map.php?error=empty inptut");
        exit();
    } */
    

    $userName = ($_SESSION['currentUser']['userName']);
    $userEmail = ($_SESSION['currentUser']['userEmail']);
    $userPhoto = ($_SESSION['currentUser']['userPhoto']);
    print $userName;
    $message = new Message(0, $userName, $userEmail, $messageCategory, $message, $userPhoto, $messageStatus, $messageCreate);
    $MessageAdded = $message->AddMessageLogic();
    if($MessageAdded){
        header("Location: ../index.php");
        //print_r($reservation);
        //print_r($ReservationAdded);
    }
    else{
        print($reservation);
        print_r($ReservationAdded);
        //header("Location:../reserve.php?error=Error Try Later");
    }
}
?>