<?php
require_once '../Models/Parking.php';
//$action = isset($_GET['action'])? $_GET['action'] : '';


$parkingName = isset($_POST['name']) ? $_POST['name'] : "";
$parkingDescription = isset($_POST['desc']) ? $_POST['desc']:"" ;
$parkingGps = isset($_POST['gps']) ? $_POST['gps']:"" ;
$parkingPhoto = isset($_POST['capacity']) ? $_POST['capacity']:"" ;
$parkingCapacity = isset($_POST['photo']) ? $_POST['photo']:"" ;





$parking = new Parking(0, $parkingName, $parkingDescription , $parkingGps, $parkingCapacity, $parkingPhoto, $parkingStatus, $parkingCreate);
$ParkingAdded = $parking->AddParkingLogic();
if($ParkingAdded){
    header("Location: ../parking.php");
}
else{
    //print_r($ParkingAdded);
    header("Location:../addparking.php?error=Error:Parking already exists");
}
?>