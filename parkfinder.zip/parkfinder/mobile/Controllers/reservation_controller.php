<?php

require '../Models/Reservation.php';

if (isset($_POST['reserve'])) {
    $parkingPhoto = isset($_POST['pphoto']) ? $_POST['pphoto'] : "";
    $parkingName = isset($_POST['pname']) ? $_POST['pname'] : "";
    $departureTime = isset($_POST['dtime']) ? $_POST['dtime'] : "" ;
    $arrivalTime = isset($_POST['atime']) ? $_POST['atime']:"" ;
    $carNumber = isset($_POST['cnumber']) ? $_POST['cnumber']:"" ;

    /* if (emptyInputReservation($parkingName, $departureTime, $arrivalTime, $carNumber) !== false) {
        header("location:../map.php?error=empty inptut");
        exit();
    } */
    

    print $parkingName;
    $userName = ($_SESSION['currentUser']['userName']);
    print $userName;
    $reservation = new Reservation(0, $userName, $parkingName, $parkingPhoto, $departureTime, $arrivalTime, $carNumber, $reservationStatus, $reservationCrate);
    $ReservationAdded = $reservation->AddReservationLogic();
    if($ReservationAdded){
        header("Location: ../map.php");
        //print_r($reservation);
        //print_r($ReservationAdded);
        //print_r($parkingPhoto);
    }
    else{
        //print_r($reservation);
        //print_r($departureTime);
        header("Location:../reserve.php?error=Error Try Later");
    }
}


if (isset($_GET['cancel'])) {
    $reservationId = $_GET['cancel'];
    $reservation = new Reservation($reservationId, null, null, null, null, null, null, null, null);
    $reservationCanceled = $reservation->cancelReservationById($reservationId);
    if($reservationCanceled){
        header("Location: ../alltransactions.php");
    }
    else{
        print_r($reservation);
        print_r($reservationCanceled);
        //header("Location:../alltransactions.php?error=Error");
    }
        
}
?>