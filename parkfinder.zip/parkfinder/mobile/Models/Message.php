<?php
session_start();
require_once 'dbConnection.php';
class Message
{
    public $messageId;
    public $userName;
    public $userEmail;
    public $messageCategory;
    public $message;
    public $userPhoto;
    public $messageStatus;
    public $messageCreate;

    public function __construct($messageId, $userName, $userEmail, $messageCategory, $message, $userPhoto, $messageStatus, $messageCreate)
    {
        $this->messageId = $messageId;
        $this->userName = $userName;
        $this->userEmail = $userEmail;
        $this->messageCategory= $messageCategory;
        $this->message= $message;
        $this->userPhoto = $userPhoto;
        $this->messageStatus = $messageStatus;
        $this->messageCreate = $messageCreate;
    }

    public function AddMessageLogic(){
        
        $dbConnection = Db::GetConnection();
        $userName = ($_SESSION['currentUser']['userName']);
        $userEmail = ($_SESSION['currentUser']['userEmail']);
        $userPhoto = ($_SESSION['currentUser']['userPhoto']);
        //print "select count(*) as total from parkings WHERE parkingName = '". $this->parkingName ."'";
        $response = $dbConnection->query("select count(*) as total from messages WHERE message = '". $this->message ."'");
        $row = $response->fetch();

        print "Total count : " . $row['total'];

        if ( intval($row['total']) > 0 ) return false;
        /*while($row = $response->fetch())
        {
            if($row['ProductName'] == $this->Name){
                return false;
            }
        }*/
        
        $sql = "insert into `messages` (`messageId`, `userName`, `userEmail`, `messageCategory`, `message`, `userPhoto`) VALUES (NULL,'$userName','$userEmail','". $this->messageCategory ."','". $this->message ."','$userPhoto')";
        $sql2 = "insert into `notifications` (`notificationsId`, `notificationsName`, `notificationsDescription`, `userName`) VALUES (NULL, 'Your Message has been added successfully','Hey , Your Message has been added successfully, have great Day! \n Message Category : $this->messageCategory \n Your Message : $this->message','$userName')";

        $added = $dbConnection->exec($sql);
        $added2 = $dbConnection->exec($sql2);
        print $added;
        print $sql;
        
        
        $dbConnection = null;
        if($added || $added2){
            return true;
            print "ok 2";
        }
        return false;
        
    }
    public static function getAllMessagesList()
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query('SELECT * FROM `messages`;');
        $messages = [];
        while($row = $response->fetch()){
            $m = new Reservation($row['messageId'], $row['userName'], $row['userEmail'], $row['messageCategory'], $row['message'], $row['userPhoto'], $row['messageStatus'], $row['messageCreate']);
            array_push($messages, $m);
        }
        return $messages;
    }
}