<?php

require_once 'dbConnection.php';

class Notification{
    
    public $notificationsId;
    public $notificationsName;
    public $notificationsDescription;
    public $userName;
    public $notificationsStatus;
    public $notificationsCreate;

    public function __construct($notificationsId, $notificationsName, $notificationsDescription, $userName, $notificationsStatus, $notificationsCreate)
    {   
        $this->notificationsId = $notificationsId;
        $this->notificationsName = $notificationsName;
        $this->notificationsDescription = $notificationsDescription;
        $this->userName = $userName;
        $this->notificationsStatus = $notificationsStatus;
        $this->notificationsCreate = $notificationsCreate;

    }


    public static function getAllNotificationByUser()
    {
        $DbConnection = Db::GetConnection();
        $userName = $_SESSION["currentUser"]['userName'];
        $response = $DbConnection->query("SELECT * FROM `notifications` WHERE userName ='$userName' ORDER BY `notificationsId` DESC ;");
        $notifications = [];
        while($row = $response->fetch()){
            $n = new Notification($row['notificationsId'],$row['notificationsName'], $row['notificationsDescription'], $row['userName'], $row['notificationsStatus'], $row['notificationsCreate']);
            array_push($notifications, $n);
        }
        return $notifications;
    }
    public static function getNotificationById($id)
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query("SELECT * FROM `notifications` WHERE notificationsId = '$id' ;"); 
        $response2 = $DbConnection->query("UPDATE notifications SET notificationsStatus='1' WHERE notificationsId = '$id' ;");         
        $row = $response->fetch();
        $row2 = $response2->fetch();
        $n = new Notification($row['notificationsId'],$row['notificationsName'], $row['notificationsDescription'], $row['userName'], $row['notificationsStatus'], $row['notificationsCreate']);
        return $n;
    }
}