<?php

require_once 'dbConnection.php';

class Parking{
    
    public $parkingId;
    public $parkingName;
    public $parkingDescription;
    public $parkingGps;
    public $parkingCapacity;
    public $parkingPhoto;
    public $parkingStatus;
    public $parkingCreate;

    public function __construct($parkingId, $parkingName, $parkingDescription, $parkingGps, $parkingCapacity, $parkingPhoto, $parkingStatus, $parkingCreate)
    {   
        $this->parkingId = $parkingId;
        $this->parkingName = $parkingName;
        $this->parkingDescription = $parkingDescription;
        $this->parkingGps = $parkingGps;
        $this->parkingCapacity = $parkingCapacity;
        $this->parkingPhoto = $parkingPhoto;
        $this->parkingStatus = $parkingStatus;
        $this->parkingCreate = $parkingCreate;

    }
                /* Add parking */
    public function AddParkingLogic(){
        
        $dbConnection = Db::GetConnection();
        print "select count(*) as total from parkings WHERE parkingName = '". $this->parkingName ."'";
        $response = $dbConnection->query("select count(*) as total from parkings WHERE parkingName = '". $this->parkingName ."'");
        $row = $response->fetch();

        print "Total count : " . $row['total'];

        if ( intval($row['total']) > 0 ) return false;
        /*while($row = $response->fetch())
        {
            if($row['ProductName'] == $this->Name){
                return false;
            }
        }*/
        
        $sql = "insert into `parkings` (`parkingId`, `parkingName`, `parkingDescription`, `parkingGps`, `parkingCapacity`, `parkingPhoto`) VALUES (NULL,'". $this->parkingName ."','". $this->parkingDescription ."','". $this->parkingGps ."','". $this->parkingPhoto ."','". $this->parkingCapacity."')";
        $added = $dbConnection->exec($sql);

        print $added;
        print $sql;
        
        $dbConnection = null;
        if($added){
            return true;
            print "ok 2";
        }
        return false;
        
    }

    

    public static function getParkingsName()
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query('select * FROM `parkings`;');
        $products = [];
        while($row = $response->fetch()){
            array_push($products, $row['parkingName']);
        }
        return $products;
    }

    public static function getAllParkingsList()
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query('SELECT * FROM `parkings` WHERE parkingStatus = 1;');
        $parkings = [];
        while($row = $response->fetch()){
            $p = new Parking($row['parkingId'],$row['parkingName'], $row['parkingDescription'], $row['parkingGps'], $row['parkingCapacity'], $row['parkingPhoto'], $row['parkingStatus'], $row['parkingCreate']);
            array_push($parkings, $p);
        }
        return $parkings;
    }

    /* public static function getProductsByCategory($categoryId)
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query('SELECT * FROM `products` WHERE CategoryId = '. $categoryId .';');
        $products = [];
        while($row = $response->fetch()){
            $data = [];
            $p = new Product($row['ProductId'],$row['ProductName'], $row['ProductPrice'], $row['ProductDescription'], $row['ProductImg'], $row['ProductRating'], $row['CategoryId'], $row['ProductImg2'], $row['ProductImg3'], $row['ProductImg4'], $row['ProductStock']);
            
            $categoryData = $DbConnection->query('SELECT * FROM `categories` WHERE CategoryId='. $row['CategoryId'] .';')->fetch();
            
            array_push($data,  $p);
            array_push($data,  $categoryData);
            array_push($products, $data);
        }
        return $products;
    } */
    public static function getParkingsById($id)
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query("SELECT * FROM `parkings` WHERE parkingId = '$id' ;");         
        $row = $response->fetch();
        $p = new Parking($row['parkingId'],$row['parkingName'], $row['parkingDescription'], $row['parkingGps'], $row['parkingCapacity'], $row['parkingPhoto'], $row['parkingStatus'], $row['parkingCreate']);
        return $p;
    }
    
    public  function editParkingById($parkingId)
    {
        $dbConnection = Db::GetConnection();
        $sql = "UPDATE parkings SET parkingName='$this->parkingName', parkingDescription='$this->parkingDescription', parkingGps ='$this->parkingGps', parkingCapacity='$this->parkingPhoto', parkingPhoto='$this->parkingCapacity' WHERE parkingId = $parkingId";
        $added = $dbConnection->exec($sql);
        //printf($sql);
        $dbConnection = null;
        if($added){
            return true;
        }
        return false;

    }
    public static function deleteParkingById($id)
    {
        $DbConnection = Db::GetConnection();
        $sql = "DELETE  FROM `parkings` WHERE parkingId = '$id' ;";
        $removed = $DbConnection->exec($sql);        
        $DbConnection = null;
        if($removed){
            return true;
        }
        return false;
    }
    

    public function blockParkingById($parkingId)
    {
        $dbConnection = Db::GetConnection();
        $sql = "UPDATE parkings SET parkingStatus='0' WHERE parkingId = $parkingId";
        $updated = $dbConnection->exec($sql);
        printf($sql);
        $dbConnection = null;
        if($updated){
            return true;
        }
        return false;
    }

    public function unblockParkingById($parkingId)
    {
        $dbConnection = Db::GetConnection();
        $sql = "UPDATE parkings SET parkingStatus='1' WHERE parkingId = $parkingId";
        print $sql;
        $updated = $dbConnection->exec($sql);
        //printf($sql);
        $dbConnection = null;
        if($updated){
            return true;
        }
        return false;
    }
}

?>