<?php
session_start();
require_once 'dbConnection.php';
require_once 'User.php';
class Reservation
{
    public $reservationId;
    public $userName;
    public $parkingName;
    public $parkingPhoto;
    public $departureTime;
    public $arrivalTime;
    public $carNumber;
    public $reservationStatus;
    public $reservationCrate;

    public function __construct($reservationId, $userName, $parkingName,$parkingPhoto, $departureTime, $arrivalTime, $carNumber, $reservationStatus, $reservationCrate)
    {
        $this->reservationId = $reservationId;
        $this->userName = $userName;
        $this->parkingName = $parkingName;
        $this->parkingPhoto = $parkingPhoto;
        $this->departureTime= $departureTime;
        $this->arrivalTime = $arrivalTime;
        $this->carNumber = $carNumber;
        $this->reservationStatus = $reservationStatus;
        $this->reservationCrate = $reservationCrate;
    }
    public function cancelReservationById($reservationId)
    {
        $dbConnection = Db::GetConnection();
        $user = $_SESSION["currentUser"]['userName'];
        $sql = "UPDATE reservations SET reservationStatus='0' WHERE reservationId = $reservationId";
        $sql2 = "insert into `notifications` (`notificationsId`, `notificationsName`, `notificationsDescription`, `userName`) VALUES (NULL, 'Reservation has been canceled successfully . Have a great Day !','Hey $user Your Reservation has been canceled successfully','$user')";
        $updated = $dbConnection->exec($sql);
        $updated2 = $dbConnection->exec($sql2);
        printf($sql);
        $dbConnection = null;
        if($updated || $updated2){
            return true;
        }
        return false;
    }

    public function AddReservationLogic(){
      
        $dbConnection = Db::GetConnection();
        $userId = ($_SESSION['currentUser']['userName']);
        $response = $dbConnection->query("select count(*) as total from reservations WHERE reservationId = '". $this->reservationId ."'");
        $row = $response->fetch();

        //print "Total count : " . $row['total'];

        if ( intval($row['total']) > 0 ) return false;
        while($row = $response->fetch())
        {
            
        }
        
        $sql = "insert into `reservations` (`reservationId`, `userName`, `parkingName`, `parkingPhoto`, `departureTime`, `arrivalTime`, `carNumber`) VALUES (NULL, '$userId','". $this->parkingName ."','". $this->parkingPhoto ."','". $this->departureTime ."','". $this->arrivalTime ."','". $this->carNumber."')";
        $sql2 = "UPDATE users SET userTotalReservation = userTotalReservation + 1, userTotalCount = userTotalCount +5 WHERE userName = '$userId'";
        $sql3 = "insert into `notifications` (`notificationsId`, `notificationsName`, `notificationsDescription`, `userName`) VALUES (NULL, 'Reservation has been added successfully','Hey $userId Your Reservation has been added successfully , have greate day! \n|| Parking Name : $this->parkingName \n|| Departure Time : $this->departureTime \n|| Arrival Time : $this->arrivalTime \n|| Car Number : $this->carNumber','$userId')";
        $added = $dbConnection->exec($sql);
        $added2 = $dbConnection->exec($sql2);
        $added3 = $dbConnection->exec($sql3);

        //print $added;
        //print $added2;
        //print $sql;
        //print $sql2;
        
        $dbConnection = null;
        if($added || $added2 || $added3){
            return true;
        }
        return false;
        
    }

    public static function getAllReservationsList()
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query('SELECT * FROM `reservations`;');
        $reservations = [];
        while($row = $response->fetch()){
            $r = new Reservation($row['reservationId'], $row['userName'], $row['parkingName'], $row['parkingPhoto'], $row['departureTime'], $row['arrivalTime'], $row['carNumber'], $row['reservationStatus'], $row['reservationCrate']);
            array_push($reservations, $r);
        }
        return $reservations;
    }
    public static function getReservationByUser()
    {
        $dbConnection = Db::GetConnection();
        $userName = $_SESSION["currentUser"]['userName'];
        $response = $dbConnection->query("SELECT * FROM `reservations`  WHERE userName = '$userName' order by reservationId desc;");
        $reservations = [];
        while($row = $response->fetch()){
            $r = new Reservation($row['reservationId'], $row['userName'], $row['parkingName'], $row['parkingPhoto'], $row['departureTime'], $row['arrivalTime'], $row['carNumber'], $row['reservationStatus'], $row['reservationCrate'], $row['parkingPhoto']);
            array_push($reservations, $r);
        }
        return $reservations;
    }

    public static function getLast10Reservations()
    {
        $DbConnection = Db::GetConnection();
        $userName = $_SESSION["currentUser"]['userName'];
        $response = $DbConnection->query('SELECT * from reservations order by reservationId desc limit 5;');
        
        $reservations = [];
        while($row = $response->fetch()){
            $r = new Reservation($row['reservationId'], $row['userName'], $row['parkingName'], $row['parkingPhoto'], $row['departureTime'], $row['arrivalTime'], $row['carNumber'], $row['reservationStatus'], $row['reservationCrate']);
            array_push($reservations, $r);
        }
        return $reservations;
    }
    public static function getLast5ReservationsByUser()
    {
        $DbConnection = Db::GetConnection();
        $userName = $_SESSION["currentUser"]['userName'];
        $response = $DbConnection->query("SELECT * from reservations WHERE userName = '$userName' order by reservationId desc limit 10;");
        $reservations = [];
        while($row = $response->fetch()){
            $r = new Reservation($row['reservationId'], $row['userName'], $row['parkingName'], $row['parkingPhoto'], $row['departureTime'], $row['arrivalTime'], $row['carNumber'], $row['reservationStatus'], $row['reservationCrate']);
            array_push($reservations, $r);
        }
        return $reservations;
    }
    public static function getReservationById($id)
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query("SELECT * FROM `reservations` WHERE reservationId = '$id' ;");         
        $row = $response->fetch();
        $r = new Reservation($row['reservationId'], $row['userName'], $row['parkingName'], $row['parkingPhoto'], $row['departureTime'], $row['arrivalTime'], $row['carNumber'], $row['reservationStatus'], $row['reservationCrate']);

        return $r;
    }
    
    

    /* public static function getReservationByUser($userName)
    {
        $dbConnection = Db::GetConnection();
        $userName = $_SESSION["currentUser"]['userName'];
        $sql = "SELECT * FROM reservations WHERE userName = $userName";
        print $sql;
        $added = $dbConnection->exec($sql);
        //printf($sql);
        $dbConnection = null;
        if($added){
            return true;
        }
        return false;
    } */
    /* public static function getReservationByUser($userName)
    {
        $dbConnection = Db::GetConnection();
        $userName = $_SESSION["currentUser"]['userName'];
        $sql = "SELECT * FROM reservations WHERE userName = $userName";
        print $sql;
        $added = $dbConnection->query($sql);
        //printf($sql);
        while($row = $added->fetch()){
            $r = new Reservation($row['reservationId'], $row['userName'], $row['parkingName'], $row['departureTime'], $row['arrivalTime'], $row['carNumber'], $row['reservationStatus'], $row['reservationCrate']);
            array_push($reservations, $r);
        }
        return $reservations;
    } */

    


}