<?php
session_start();
require_once 'dbConnection.php';
class User
{
    public $userId;
    public $userName;
    public $userEmail;
    public $userCin;
    public $userGender;
    public $userBirth;
    public $userCity;
    public $userPhone;
    public $userPhoto;
    public $userSolde;
    public $userTotalReservation;
    public $userTotalCount;
    public $userPassword;
    public $userStatus;
    public $userConfirmation;
    public $userCreate;



    public function __construct($userId, $userName, $userEmail, $userCin, $userGender, $userBirth, $userCity, $userPhone, $userPhoto, $userSolde, $userTotalReservation, $userTotalCount, $userPassword, $userStatus, $userConfirmation, $userCreate)
    {
        $this->userId = $userId;
        $this->userName = $userName;
        $this->userEmail = $userEmail;
        $this->userCin= $userCin;
        $this->userGender = $userGender;
        $this->userBirth = $userBirth;
        $this->userCity = $userCity;
        $this->userPhone = $userPhone;
        $this->userPhoto = $userPhoto;
        $this->userSolde = $userSolde;
        $this->userTotalReservation = $userTotalReservation;
        $this->userTotalCount = $userTotalCount;
        $this->userPassword = $userPassword; 
        $this->userStatus = $userStatus;
        $this->userConfirmation = $userConfirmation;   
        $this->userCreate = $userCreate;
    }

    public function UserRegisterLogic(){
        
        $dbConnection = Db::GetConnection();
        $response = $dbConnection->query("select * from users");
        while($row = $response->fetch())
        {
            if($row['userEmail'] == $this->userEmail){
                return false;
            }
        }
        //$hashedPass = password_hash($pass, PASSWORD_DEFAULT);
        $sql = 'insert into `users` (`userId`, `userName`, `userEmail`, `userCin`, `userGender`, `userBirth`, `userCity`, `userPhone`, `userPassword`) VALUES (NULL, "' . $this->userName .'", "' . $this->userEmail .'", "' . $this->userCin .'", "' . $this->userGender . '", "' .  $this->userBirth .'", "' . $this->userCity .'", "' . $this->userPhone .'", "' . $this->userPassword .'");';
        $added = $dbConnection->exec($sql);
        print_r($sql);
        $dbConnection = null;
        if($added){
            return true;
        }
        return false;
        
    }

    public function UserLoginLogic(){
        
        $dbConnection = Db::GetConnection();
        $response = $dbConnection->query("select * from users");
        while($row = $response->fetch())
        {
            if($row['userEmail'] == $this->userEmail && $row['userPassword'] == $this->userPassword){
                $dbConnection = null;
                return true;
            }
        }
        $dbConnection = null;
        return false;
    }

    public static function getUserByMailAndPassword($userEmail, $userPassword){
        
        $dbConnection = Db::GetConnection();
        $response = $dbConnection->query('select * from users');
        while($row = $response->fetch())
        {
            if($row['userEmail'] == $userEmail && $row['userPassword'] == $userPassword){
                $dbConnection = null;
                return new User($row['userId'], $row['userName'], $row['userEmail'], $row['userCin'], $row['userGender'], $row['userBirth'], $row['userCity'], $row['userPhone'], $row['userPhoto'], $row['userSolde'], $row['userTotalReservation'], $row['userTotalCount'], $row['userPassword'], $row['userStatus'], $row['userConfirmation'], $row['userCreate']);
            }
        }
        $dbConnection = null;
        return null;
    }
    
    /* public static function reloadUser($id)
    {   
        $userId = $id;
        //$userId = $_SESSION["currentUser"]['userId'];
        //print_r($userId);
        //print_r( '<script>console.log("$userId"); </script>');
        //$userId = $_SESSION['userId'];
        $DbConnection = Db::GetConnection();
        $sql = "SELECT * FROM `users` WHERE userId = $userId";
        $result = $DbConnection->query($sql);      
        $DbConnection = null;
        //unset($_SESSION['currentUser']['solde']);
        while($row = $result->fetch()){
            $user = new User($row['userId'], $row['userName'], $row['userEmail'], $row['userCin'], $row['userGender'], $row['userBirth'], $row['userCity'], $row['userPhone'], $row['userPhoto'], $row['userSolde'], $row['userTotalReservation'], $row['userPassword'], $row['userStatus'], $row['userConfirmation'], $row['userCreate']);
            //$_SESSION["currentUser"] = $user;
        }
        //$test = $_SESSION["currentUser"]['userSolde'];
        print $sql;
        return false;
        //sreturn $user;
        
    } */
    public static function getUserById()
    {
        $DbConnection = Db::GetConnection();
        $userId = $_SESSION['currentUser']['userId'];
        $response = $DbConnection->query("SELECT * FROM `users` WHERE userId = $userId");
        $row = $response->fetch();
        $u = new User($row['userId'], $row['userName'], $row['userEmail'], $row['userCin'], $row['userGender'], $row['userBirth'], $row['userCity'], $row['userPhone'], $row['userPhoto'], $row['userSolde'], $row['userTotalReservation'], $row['userTotalCount'], $row['userPassword'], $row['userStatus'], $row['userConfirmation'], $row['userCreate']);
        return $u;
    }
    public static function getAllUsersList()
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query('SELECT * FROM `users`;');
        $users = [];
        while($row = $response->fetch()){
            $u = new User($row['userId'], $row['userName'], $row['userEmail'], $row['userCin'], $row['userGender'], $row['userBirth'], $row['userCity'], $row['userPhone'], $row['userPhoto'], $row['userSolde'], $row['userTotalReservation'], $row['userTotalCount'], $row['userPassword'], $row['userStatus'], $row['userConfirmation'], $row['userCreate']);
            array_push($users, $u);
        }
        return $users;
    }
    
    /* public function editUserById($userId)
    {
        $dbConnection = Db::GetConnection();
        $sql = "UPDATE users SET userName='$this->userName', userEmail='$this->userEmail', userCin ='$this->userCin', userGender='$this->userGender', userBirth='$this->userBirth', userCity='$this->userCity', userPhone='$this->userPhone', adminPassword='$this->adminPassword' WHERE userId = $userId";
        $updated = $dbConnection->exec($sql);
        printf($sql);
        $dbConnection = null;
        if($updated){
            return true;
        }
        return false;
    } */
    public function editUserById()
    {
        $user = 1;
        $user = $_SESSION["currentUser"]['userId'];
        $dbConnection = Db::GetConnection();
        $sql = "UPDATE users SET userCity='$this->userCity', userPhone='$this->userPhone', userPassword='$this->userPassword' WHERE userId = $user";
        $updated = $dbConnection->exec($sql);
        printf($sql);
        $dbConnection = null;
        if($updated){
            return true;
        }
        return false;
    }

    public static function deleteUserById($id)
    {
        $DbConnection = Db::GetConnection();
        $sql = "DELETE FROM `users` WHERE userId = '$id' ;";
        $removed = $DbConnection->exec($sql);      
        $DbConnection = null;
        if($removed){
            return true;
        }
        return false;
    }



    public function add20SoldeById($userId)
    {
        $dbConnection = Db::GetConnection();
        $userId = $_SESSION["currentUser"]['userId'];
        $userName = $_SESSION["currentUser"]['userName'];
        $sql = "UPDATE users SET userSolde = userSolde + 20 WHERE userId = $userId";
        $sql2 = "insert into `notifications` (`notificationsId`, `notificationsName`, `notificationsDescription`, `userName`) VALUES (NULL, 'Balance has been added successfully','Hey $userName You have added 20 Dh to Your Balance. Have a greate Day!','$userName')";

        print $sql;
        print $sql2;
        $updated = $dbConnection->exec($sql);
        $updated2 = $dbConnection->exec($sql2);
        //printf($sql);
        $dbConnection = null;
        if($updated || $updated2){
            return true;
        }
        return false;
    }
    public function add50SoldeById($userId)
    {
        $dbConnection = Db::GetConnection();
        $userId = $_SESSION["currentUser"]['userId'];
        $userName = $_SESSION["currentUser"]['userName'];
        $sql = "UPDATE USERS SET userSolde = userSolde + 50 WHERE userId = $userId";
        $sql2 = "insert into `notifications` (`notificationsId`, `notificationsName`, `notificationsDescription`, `userName`) VALUES (NULL, 'Balance has been added successfully','Hey $userName You have added 50 Dh to Your Balance. Have a greate Day!','$userName')";
        print $sql;
        $updated = $dbConnection->exec($sql);
        $updated2 = $dbConnection->exec($sql2);
        //printf($sql);
        $dbConnection = null;
        if($updated || $updated2){
            return true;
        }
        return false;
    }
    public function add100SoldeById($userId)
    {
        $dbConnection = Db::GetConnection();
        $userId = $_SESSION["currentUser"]['userId'];
        $userName = $_SESSION["currentUser"]['userName'];
        $sql = "UPDATE USERS SET userSolde = userSolde + 100 WHERE userId = $userId";
        $sql2 = "insert into `notifications` (`notificationsId`, `notificationsName`, `notificationsDescription`, `userName`) VALUES (NULL, 'Balance has been added successfully','Hey $userName You have added 100 Dh to Your Balance. Have a greate Day!','$userName')";
        print $sql;
        $updated = $dbConnection->exec($sql);
        $updated2 = $dbConnection->exec($sql2);
        //printf($sql);
        $dbConnection = null;
        if($updated || $updated2){
            return true;
        }
        return false;
    }
    public function add300SoldeById($userId)
    {
        $dbConnection = Db::GetConnection();
        $userId = $_SESSION["currentUser"]['userId'];
        $userName = $_SESSION["currentUser"]['userName'];
        $sql = "UPDATE USERS SET userSolde = userSolde + 300 WHERE userId = $userId";
        $sql2 = "insert into `notifications` (`notificationsId`, `notificationsName`, `notificationsDescription`, `userName`) VALUES (NULL, 'Balance has been added successfully','Hey $userName You have added 300 Dh to Your Balance. Have a greate Day!','$userName')";
        print $sql;
        $updated = $dbConnection->exec($sql);
        $updated2 = $dbConnection->exec($sql2);
        //printf($sql);
        $dbConnection = null;
        if($updated || $updated2){
            return true;
        }
        return false;
    }
    public function add500SoldeById($userId)
    {
        $dbConnection = Db::GetConnection();
        $userId = $_SESSION["currentUser"]['userId'];
        $userName = $_SESSION["currentUser"]['userName'];
        $sql = "UPDATE USERS SET userSolde = userSolde + 500 WHERE userId = $userId";
        $sql2 = "insert into `notifications` (`notificationsId`, `notificationsName`, `notificationsDescription`, `userName`) VALUES (NULL, 'Balance has been added successfully','Hey $userName You have added 500 Dh to Your Balance. Have a greate Day!','$userName')";
        print $sql;
        print $sql2;
        $updated = $dbConnection->exec($sql);
        $updated2 = $dbConnection->exec($sql2);
        //printf($sql);
        $dbConnection = null;
        if($updated || $updated2){
            return true;
        }
        return false;
    }


    
}


?>