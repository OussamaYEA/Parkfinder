<?php

class Db
{
    

    public static function GetConnection()
    {   
        try{
            $Connection = new PDO("mysql:host=localhost;dbname=parkfinder", "root", "mysql");
            return $Connection;
        }
        catch(Exception $e)
        {
            echo 'Error : '. $e->getMessage();
        }
    }    
}
