<?php
$userCPassword = $_SESSION['currentUser']['userPassword'];
function emptyInputRegister($name, $email, $gender, $birth, $country, $address, $phone, $pass, $passrpt) {
 $result;
 if (empty($name) || empty($email) || empty($gender) || empty($birth) || empty($country) || empty($address) || empty($phone) || empty($pass) || empty($passrpt)) {
    $result = true;
 }
 else {
    $result = false;
 }
 return $result;
}
function emptyInputReservation($parkingName, $departureTime, $arrivalTime, $carNumber) {
    $result;
    if (empty($parkingName) || empty($departureTime) || empty($arrivalTime) || empty($carNumber)) {
       $result = true;
    }
    else {
       $result = false;
    }
    return $result;
   }

function invalidName($name) {
    $result;
    if (!preg_match("/^[a-zA-Z0-9]*$/", $name)) {
       $result = true;
    }
    else {
        $result = false;
    }
    return $result;
}

function invalidEmail($email) {
    $result;
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $result = true;
    }
    else {
        $result = false;
    }
    return $result;
}

function invalidNumber($phone)
{
    $result;
    if (!preg_match("/^[0-9]*$/", $phone)){
       $result = true;
    }
    else {
        $result = false;
    }
    return $result;
}
function checkPass($pass){
    $result;
    if (sizeof($pass) < 8){
        $result = true;   
    }
    else {
        $result = false;
    }
}



function passMatch($pass, $passrpt) {
    $result;
    if ($pass !== $passrpt) {
        $result = true;
    }
    else {
        $result = false;
    }
    return $result;
}
function checkCPass($userPassword , $userCPassword) {
    $result;
    if ($userPassword !== $userCPassword){
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

function emptyInputLogin($name, $pass) {
    $result;
    if (empty($name) || empty($pass)) {
       $result = true;
    }
    else {
       $result = false;
    }
    return $result;
}
function loginUser($Connection,$name, $pass) {
    $nameExists = nameExists($Connection, $name, $name);

    if($nameExists === false) {
        header("location: ../login.php?error=wronglogin");
        exit();
    }
    $passHashed = $nameExists["usersPwd"];
    $checkPass = password_verify($pass, $passHashed);
    if($checkPass ===false) {
        header("location: ../login.php?error=wronglogin");
        exit();
    }
    else if ($checkPass ===true) {
        session_start();
        $_SESSION["userid"] = $nameExists["usersId"];
        $_SESSION["username"] = $nameExists["usersName"];
        header("location: ../index.php");
        exit();
    }
}