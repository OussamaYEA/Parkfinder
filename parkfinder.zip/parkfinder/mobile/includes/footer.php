<head>
    <link rel="shortcut icon" href="images/favicon1.png"/>
</head>
<div class="footer">
            <ul class="nav nav-tabs justify-content-center" id="myTab" role="tablist">
                <li class="nav-item">
                    <a href="index.php" class="nav-link" id="home-tab"  role="tab" aria-controls="home" aria-selected="true">
                        <i class="material-icons">home</i>
                        <small class="sr-only">Home</small>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="search-tab" href="map.php" role="tab" aria-controls="search" aria-selected="false">
                        <i class="material-icons">room</i>
                        <small class="sr-only">search</small>
                    </a>
                <!-- </li>
                <li class="nav-item centerlarge">
                    <a class="nav-link bg-default" id="cart-tab" data-toggle="tab" href="#cart" role="tab" aria-controls="cart" aria-selected="false">
                        <i class="material-icons">shopping_basket</i>
                        <small class="sr-only">chat</small>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="favorite-tab" data-toggle="tab" href="#favorite" role="tab" aria-controls="favorite" aria-selected="false">
                        <i class="material-icons">star</i>
                        <small class="sr-only">Best</small>
                    </a>
                </li> -->
                <li class="nav-item">
                    <a class="nav-link active" id="profile-tab"  href="profile.php" role="tab" aria-controls="profile" aria-selected="false">
                        <i class="material-icons">person</i>
                        <small class="sr-only">Account</small>
                    </a>
                </li>
            </ul>
        </div>