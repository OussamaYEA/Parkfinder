<?php
session_start();
$userId = User::getUserById();
//print_r($userId);
    $user = $_SESSION["currentUser"];
    if(!isset($_SESSION['currentUser'])){
        header("Location:login.php");
    }
    if($_SESSION["currentUser"]['userStatus'] == "0"){
        header("Location:login.php?error=You Have been blocked please contact support ");
    }
    
    
    /* try
    {
        $pdo = new PDO('mysql:host=localhost;dbname=parkfinder', 'root', 'mysql', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ));
        $stmt = $pdo->query(" SELECT * FROM users WHERE userId=$user->userId ");
        $messages = $stmt->fetchAll(PDO::FETCH_OBJ);
        print_r($messages);
    }
    catch(Exception $e)
    {
        exit('<b>Catched exception at line '. $e->getLine() .' :</b> '. $e->getMessage());
    } */   
    //$userId = user::reloadUser();
    require_once './Models/Notification.php';
?>
<head>
    <link rel="shortcut icon" href="images/favicon1.png"/>
</head>
<div class="header">
    <div class="row no-gutters">
        <div class="col-auto">
            <button class="btn  btn-link text-dark menu-btn"><i class="material-icons">menu</i><span class="new-notification"></span></button>
        </div>
        <div class="col text-center"><img src="img/logo1.png" alt="" class="header-logo"></div>
        <div class="col-auto">
            <a href="notification.php" class="btn  btn-link text-dark position-relative"><i class="material-icons">notifications_none</i><span class="<?php if($notificationsStatus == "0" AND $userName = $_SESSION["currentUser"]['userName']){echo"";} ?>counts"></span></a>
        </div>
    </div>
</div>