<?php
	require_once './Models/User.php';
?>
<?php
    $user = $_SESSION["currentUser"];
    if(!isset($_SESSION['currentUser'])){
        header("Location:login.php");
    }
    if($_SESSION["currentUser"]['userStatus'] == "0"){
        header("Location:login.php?error=You Have been blocked please contact support ");
    }
?>
<head>
    <link rel="shortcut icon" href="images/favicon1.png"/>
</head>
<div class="sidebar">
        <div class="my-5">
            <div class="row">
                <div class="col-auto">
                    <figure class="avatar avatar-60 border-0"><img src="img/user1.png" alt=""></figure>
                </div>
                <div class="col pl-0 align-self-center">
                    <h5 class="mb-1"><?echo $user['userName'] ?></h5>
                    <p class="text-mute small"><?echo $user['userCity'] ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="list-group main-menu">
                    <a href="index.php" class="list-group-item list-group-item-action "><i class="material-icons icons-raised">home</i>Home</a>
                    <a href="notification.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised">notifications</i>Notification <span class="badge badge-dark text-white">2</span></a>
                    <a href="pricing.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised">monetization_on</i>Add Solde</a>
                    <a href="alltransactions.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised">find_in_page</i>History</a>                    
                    <a href="javascript:void(0)" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#colorscheme"><i class="material-icons icons-raised">color_lens</i>Color scheme</a>
                    <a href="contactus.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised">question_answer</i>Contact US</a>
                    <a href="aboutus.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised">assignment_ind</i>About US</a>
                    <a href="faqs.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised">feedback</i>FAQs</a>
                    <a href="logout.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised bg-danger">power_settings_new</i>Logout</a>
                </div>
            </div>
        </div>
    </div>
    <a href="javascript:void(0)" class="closesidemenu"><i class="material-icons icons-raised bg-dark ">close</i></a>