<?php
require_once './Models/User.php';
require_once './Models/Parking.php';
require_once './Models/Reservation.php';

?>
<?php
//$user = $_SESSION["currentUser"];

?>
<!doctype html>
<html lang="en" class="deeppurple-theme">


<!-- Mirrored from maxartkiller.com/website/Fimobile/Fimobile-HTML/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 Jun 2021 14:56:08 GMT -->

<head>
    <link rel="shortcut icon" href="images/favicon1.png"/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="Maxartkiller">

    <title>Home · Parkfinder</title>

    <!-- Material design icons CSS -->
    <link rel="stylesheet" href="vendor/materializeicon/material-icons.css">

    <!-- Roboto fonts CSS -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap-4.4.1/css/bootstrap.min.css" rel="stylesheet">

    <!-- Swiper CSS -->
    <link href="vendor/swiper/css/swiper.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <!-- <link href="css/style1.css" rel="stylesheet">
    <link href="css/swiper-bundle.min.css" rel="stylesheet"> -->
</head>

<body>
    <!-- verification mail -->
    
    <!-- end verification mail -->
    <!-- <div class="row no-gutters vh-100 loader-screen">
        <div class="col align-self-center text-white text-center">
            <img src="img/logo1.png" alt="logo">
            <h1 class="mt-3"><span class="font-weight-light ">P</span>Finder</h1>
            <p class="text-mute text-uppercase small"></p>
            <div class="laoderhorizontal">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div> -->
    <!-- sidebar -->
    <?php
    include_once 'includes/sidebar.php';
    ?>
    <!-- end sidebar -->
    <div class="wrapper homepage">
        <!-- header -->
        <?php
        include_once 'includes/header.php';
        ?>
        <!-- header ends -->

        <div class="container">
            <div class="card bg-template shadow mt-4 h-190">
                <div class="card-body">
                    <div class="row">
                        <div class="col-auto">
                            <figure class="avatar avatar-60"><img src="img/user1.png" alt=""></figure>
                        </div>
                        <div class="col pl-0 align-self-center">
                            <h5 class="mb-1"><? print_r( $userId->userName) ?></h5>
                            <p class="text-mute small"><? print_r( $userId->userCity) ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container top-100">
            <div class="card mb-4 shadow">
                <div class="card-body border-bottom">
                    <div class="row">
                        <div class="col">
                            <h3 class="mb-0 font-weight-normal"><? print_r( $userId->userSolde) ?> DH </h3>
                            <p class="text-mute">My Balance</p>
                        </div>
                        <div class="col-auto">
                            <a href="pricing.php"><button class="btn btn-default btn-rounded-54 shadow" data-toggle="modal" data-target=""><i class="material-icons">add</i></button></a>
                        </div>
                    </div>
                </div>
                <div class="card-body border-bottom">
                    <div class="row">
                        <div class="col">
                            <h3 class="mb-0 font-weight-normal"><? print_r( $userId->userTotalReservation) ?><span style="float: right ;"><? print_r( $userId->userTotalCount) ?> DH</span></h3>
                            <p class="text-mute">Reservations<span style="float: right ;">Total Count</span></p>
                        </div>
                        <div class="col-auto">
                            <a href="alltransactions.php"><button class="btn btn-default btn-rounded-54 shadow" data-toggle="modal" data-target=""><i class="material-icons">view_list</i></button></a>
                        </div>
                    </div>
                </div>
                <!-- <div class="card-footer bg-none">
                    <div class="row">
                        <div class="col">
                            <p>71.00 <i class="material-icons text-danger vm small">arrow_downward</i><br><small class="text-mute">INR</small></p>
                        </div>
                        <div class="col text-center">
                            <p>1.00 <i class="material-icons text-success vm small">arrow_upward</i><br><small class="text-mute">USD</small></p>
                        </div>
                        <div class="col text-right">
                            <p><i class="material-icons text-success vm small mr-1">arrow_upward</i>0.78<br><small class="text-mute">GBP</small></p>
                        </div>
                    </div>
                </div> -->
            </div>
        </div>
        <!-- <div class="container">
            <div class="row">
                <div class="swiper-container icon-slide mb-4">
                    <div class="swiper-wrapper">
                        <a href="#" class="swiper-slide text-center" data-toggle="modal" data-target="#paymodal">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay bg-template"></div>
                                <i class="material-icons text-template">local_atm</i>
                            </div>
                            <p class="small mt-2">Pay</p>
                        </a>
                        <a href="#" class="swiper-slide text-center" data-toggle="modal" data-target="#sendmoney">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay bg-template"></div>
                                <i class="material-icons text-template">send</i>
                            </div>
                            <p class="small mt-2">Send</p>
                        </a>
                        <a href="#" class="swiper-slide text-center" data-toggle="modal" data-target="#bookmodal">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay bg-template"></div>
                                <i class="material-icons text-template">directions_railway</i>
                            </div>
                            <p class="small mt-2">Book</p>
                        </a>
                        <a href="#" class="swiper-slide text-center">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay bg-template"></div>
                                <i class="material-icons text-template">assignment</i>
                            </div>
                            <p class="small mt-2">Bills</p>
                        </a>
                        <a href="#" class="swiper-slide text-center">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay bg-template"></div>
                                <i class="material-icons text-template">camera</i>
                            </div>
                            <p class="small mt-2">Scan</p>
                        </a>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>

            <div class="row mb-2">
                <div class="container px-0">
                    Swiper 
                    <div class="swiper-container two-slide">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="card shadow border-0">
                                    <div class="card-body">
                                        <div class="row no-gutters h-100">
                                            <div class="col">
                                                <p>$ 1548.00<br><small class="text-secondary">Home Loan EMI</small></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="card shadow border-0">
                                    <div class="card-body">
                                        <div class="row no-gutters h-100">
                                            <div class="col">
                                                <p>$ 1548.00<br><small class="text-secondary">Cash Loan EMI</small></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="card shadow border-0">
                                    <div class="card-body">
                                        <div class="row no-gutters h-100">
                                            <div class="col">
                                                <p>$ 1548.00<br><small class="text-secondary">Car Loan EMI</small></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="card shadow border-0">
                                    <div class="card-body">
                                        <div class="row no-gutters h-100">
                                            <div class="col">
                                                <p>$ 1548.00<br><small class="text-secondary">Business Loan EMI</small></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="card shadow border-0">
                                    <div class="card-body">
                                        <div class="row no-gutters h-100">
                                            <div class="col">
                                                <p>$ 1548.00<br><small class="text-secondary">Edu Loan EMI</small></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="card shadow border-0">
                                    <div class="card-body">
                                        <div class="row no-gutters h-100">
                                            <div class="col">
                                                <p>$ 1548.00<br><small class="text-secondary">Home Loan EMI</small></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-pagination"></div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="container px-0">
                    Swiper 
                    <div class="swiper-container offer-slide">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="card shadow border-0 bg-template">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-auto pr-0">
                                                <img src="img/graphics-carousel-scheme1.png" alt="" class="mw-100">
                                            </div>
                                            <div class="col align-self-center">
                                                <h5 class="mb-2 font-weight-normal">Gold loan scheme</h5>
                                                <p class="text-mute">Get all money at market rate of gold</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="card shadow border-0 bg-template">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col pr-0 align-self-center">
                                                <h5 class="mb-2 font-weight-normal">Gold loan scheme</h5>
                                                <p class="text-mute">Get all money at market rate of gold</p>
                                            </div>
                                            <div class="col-auto">
                                                <img src="img/graphics-carousel-scheme1.png" alt="" class="mw-100">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="container">
            <h6 class="subtitle">Your Status <a href="allpayment.php" class="float-right small"></a></h6>
            <?php
                $parkings = Parking::getAllParkingsList();
                foreach ($parkings as $value) {
            ?>
            <div class="card shadow border-0 mb-3">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h5 class="font-weight-normal mb-1"><? echo $value->parkingName?> </h5>
                            <p class="text-mute small text-secondary mb-2">20d to pay electricity bill</p>
                            <div class="progress h-4">
                                <div class="progress-bar bg-success" role="progressbar" style="width:<? print_r( $userId->userTotalReservation) ?>%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <div class="col-auto pl-0">
                            <button class="avatar avatar-50 no-shadow border-0 bg-template">
                                <i class="material-icons">local_parking</i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            }
        ?>
            <!-- <div class="card shadow border-0 mb-3">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h5 class="font-weight-normal mb-1">$ 106.00 <span class="badge badge-danger small vm text-white">Prior</span></h5>
                            <p class="text-mute small text-secondary mb-2">33 days to pay gas bill</p>
                            <div class="progress h-4">
                                <div class="progress-bar bg-danger" role="progressbar" style="width: 65%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        </div>
                        <div class="col-auto pl-0">
                            <button class="avatar avatar-50 no-shadow border-0 bg-template">
                                <i class="material-icons">local_atm</i>
                            </button>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>
        <!-- start -->
        <!-- <div class="row">
            <div class="container mb-4 px-0">
                <div class="swiper-container swiperprojects">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="card shadow-sm">
                                <button class="btn btn-danger avatar avatar-40 p-0 rounded-circle position-absolute top-0 end-0 m-3"><i
                                        class="bi bi-heart h4 mb-0"></i></button>
                                <figure class="card-img-top overflow-hidden mb-0 coverimg"><img src="assets/img/project1.jpg"
                                        alt="project images"></figure>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-auto align-self-center">
                                            <div id="progressCircle3" class="progressCircle"></div>
                                        </div>
                                        <div class="col">
                                            <p class="text-uppercase text-muted mb-1">Case Study</p>
                                            <h3 class="mb-1">34251</h3>
                                            <p class="small text-muted">Views</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card shadow-sm">
                                <button class="btn btn-danger avatar avatar-40 p-0 rounded-circle position-absolute top-0 end-0 m-3"><i
                                        class="bi bi-heart h4 mb-0"></i></button>
                                <figure class="card-img-top overflow-hidden mb-0 coverimg"><img src="assets/img/project2.jpg"
                                        alt="project images"></figure>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-auto align-self-center">
                                            <div id="progressCircle4" class="progressCircle"></div>
                                        </div>
                                        <div class="col">
                                            <p class="text-uppercase text-muted mb-1">Case Study</p>
                                            <h3 class="mb-1">34251</h3>
                                            <p class="small text-muted">Views</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card shadow-sm">
                                <button class="btn btn-danger avatar avatar-40 p-0 rounded-circle position-absolute top-0 end-0 m-3"><i
                                        class="bi bi-heart h4 mb-0"></i></button>
                                <figure class="card-img-top overflow-hidden mb-0 coverimg"><img src="assets/img/project3.jpg"
                                        alt="project images"></figure>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-auto align-self-center">
                                            <div id="progressCircle5" class="progressCircle"></div>
                                        </div>
                                        <div class="col">
                                            <p class="text-uppercase text-muted mb-1">Case Study</p>
                                            <h3 class="mb-1">34251</h3>
                                            <p class="small text-muted">Views</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card shadow-sm">
                                <button class="btn btn-danger avatar avatar-40 p-0 rounded-circle position-absolute top-0 end-0 m-3"><i
                                        class="bi bi-heart h4 mb-0"></i></button>
                                <figure class="card-img-top overflow-hidden mb-0 coverimg"><img src="assets/img/project1.jpg"
                                        alt="project images"></figure>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-auto align-self-center">
                                            <div id="progressCircle6" class="progressCircle"></div>
                                        </div>
                                        <div class="col">
                                            <p class="text-uppercase text-muted mb-1">Case Study</p>
                                            <h3 class="mb-1">34251</h3>
                                            <p class="small text-muted">Views</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- end -->
        <!-- <div class="container">
            <h6 class="subtitle">Recent Messages</h6>
            <div class="card shadow border-0 mb-3">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-auto pr-0">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <img src="img/user1.png" alt="">
                            </div>
                        </div>
                        <div class="col">
                            <h6 class="font-weight-normal mb-1">Mrs. Magon Johnson </h6>
                            <p class="text-mute small text-secondary">"Thank you for your purchase with our shop and making online payment."</p>
                        </div>
                    </div>
                </div>
                <div class="card-footer border-top bg-none">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Recipient's username" aria-label="Quick reply" aria-describedby="button-addon4">
                        <div class="input-group-append">
                            <button class="btn btn-default btn-rounded-36 shadow-sm" type="button" id="button-addon4"><i class="material-icons md-18">send</i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card shadow border-0 mb-3">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-auto pr-0">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <img src="img/user2.png" alt="">
                            </div>
                        </div>
                        <div class="col">
                            <h6 class="font-weight-normal mb-1">Ms. Shivani Dilux</h6>
                            <p class="text-mute small text-secondary">"Thank you for your purchase with our shop and making online payment."</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <h6 class="subtitle">Loan Status </h6>
            <div class="card shadow border-0 mb-3">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-auto pr-0">
                            <div class="avatar avatar-50 no-shadow border-0">
                                <div class="overlay bg-template"></div>
                                <i class="material-icons vm text-template">local_atm</i>
                            </div>
                        </div>
                        <div class="col-auto align-self-center">
                            <h6 class="font-weight-normal mb-1">EMI</h6>
                            <p class="text-mute small text-secondary">Home Loan</p>
                        </div>
                        <div class="col-auto align-self-center border-left">
                            <h6 class="font-weight-normal mb-1">$ 1548.00</h6>
                            <p class="text-mute small text-secondary">Due: 15-12-2019</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card shadow border-0 mb-3">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-auto pr-0">
                            <div class="avatar avatar-50 no-shadow border-0">
                                <div class="overlay bg-template"></div>
                                <i class="material-icons vm text-template">local_atm</i>
                            </div>
                        </div>
                        <div class="col-auto align-self-center">
                            <h6 class="font-weight-normal mb-1">EMI</h6>
                            <p class="text-mute small text-secondary">Car Loan</p>
                        </div>
                        <div class="col-auto align-self-center border-left">
                            <h6 class="font-weight-normal mb-1">$ 658.00</h6>
                            <p class="text-mute small text-secondary">Due: 18-12-2019</p>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- <div class="container">
            <h6 class="subtitle">News Updates</h6>
            <div class="row">
                Swiper
                <div class="swiper-container news-slide">
                    <div class="swiper-wrapper" >
                        <div class="swiper-slide" style="width: 315px;">
                            <div class="card shadow-sm border-0 bg-dark text-white">
                                <figure class="background">
                                    <img src="img/product2.jpg" alt="">
                                </figure>
                                
                                <div class="card-body">
                                    <h5 class="small">Morocco Mall</h5>
                                    <p class="text-mute small">By Anand Mangal</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card shadow-sm border-0 bg-dark text-white">
                                <figure class="background">
                                    <img src="img/product2.jpg" alt="">
                                </figure>
                                
                                <div class="card-body">
                                    <h5 class="small">Multipurpose Juice allows you to grow faster</h5>
                                    <p class="text-mute small">By Anand Mangal</p>
                                </div>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div class="card shadow-sm border-0 bg-dark text-white">
                                <figure class="background">
                                    <img src="img/product3.jpg" alt="">
                                </figure>
                                <div class="card-body">
                                    <a href="#" class="btn btn-default btn-rounded-36 shadow-sm float-bottom-right"><i class="material-icons md-18">arrow_forward</i></a>
                                    <h5 class="small">Multipurpose Juice allows you to grow faster</h5>
                                    <p class="text-mute small">By Anand Mangal</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card shadow-sm border-0 bg-dark text-white">
                                <figure class="background">
                                    <img src="img/product2.jpg" alt="">
                                </figure>
                                <div class="card-body">
                                    <a href="#" class="btn btn-default btn-rounded-36 shadow-sm float-bottom-right"><i class="material-icons md-18">arrow_forward</i></a>
                                    <h5 class="small">Multipurpose Juice allows you to grow faster</h5>
                                    <p class="text-mute small">By Anand Mangal</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card shadow-sm border-0 bg-dark text-white">
                                <figure class="background">
                                    <img src="img/product3.jpg" alt="">
                                </figure>
                                <div class="card-body">
                                    <a href="#" class="btn btn-default btn-rounded-36 shadow-sm float-bottom-right"><i class="material-icons md-18">arrow_forward</i></a>
                                    <h5 class="small">Multipurpose Juice allows you to grow faster</h5>
                                    <p class="text-mute small">By Anand Mangal</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card shadow-sm border-0 bg-dark text-white">
                                <figure class="background">
                                    <img src="img/product2.jpg" alt="">
                                </figure>
                                <div class="card-body">
                                    <a href="#" class="btn btn-default btn-rounded-36 shadow-sm float-bottom-right"><i class="material-icons md-18">arrow_forward</i></a>
                                    <h5 class="small">Multipurpose Juice allows you to grow faster</h5>
                                    <p class="text-mute small">By Anand Mangal</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="card shadow-sm border-0 bg-dark text-white">
                                <figure class="background">
                                    <img src="img/product3.jpg" alt="">
                                </figure>
                                <div class="card-body">
                                    <a href="#" class="btn btn-default btn-rounded-36 shadow-sm float-bottom-right"><i class="material-icons md-18">arrow_forward</i></a>
                                    <h5 class="small">Multipurpose Juice allows you to grow faster</h5>
                                    <p class="text-mute small">By Anand Mangal</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    Add Pagination
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col text-center">
                    <h5 class="subtitle mb-1">Most Exciting Feature</h5>
                    <p class="text-secondary">Take a look at our services</p>
                </div>
            </div>
            <div class="row text-center mt-4">
                <div class="col-6 col-md-3">
                    <div class="card shadow border-0 mb-3">
                        <div class="card-body">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay bg-template"></div>
                                <i class="material-icons vm md-36 text-template">card_giftcard</i>
                            </div>
                            <h3 class="mt-3 mb-0 font-weight-normal">2546</h3>
                            <p class="text-secondary text-mute small">Gift it out</p>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card shadow border-0 mb-3">
                        <div class="card-body">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay bg-template"></div>
                                <i class="material-icons vm md-36 text-template">subscriptions</i>
                            </div>
                            <h3 class="mt-3 mb-0 font-weight-normal">635</h3>
                            <p class="text-secondary text-mute small">Monthly Billed</p>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card shadow border-0 mb-3">
                        <div class="card-body">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay bg-template"></div>
                                <i class="material-icons vm md-36 text-template">local_florist</i>
                            </div>
                            <h3 class="mt-3 mb-0 font-weight-normal">1542</h3>
                            <p class="text-secondary text-mute small">Eco environment</p>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card shadow border-0 mb-3">
                        <div class="card-body">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay bg-template"></div>
                                <i class="material-icons vm md-36 text-template">location_city</i>
                            </div>
                            <h3 class="mt-3 mb-0 font-weight-normal">154</h3>
                            <p class="text-secondary text-mute small">Four Offices</p>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="container">
            <!-- page content here -->
            <h6 class="subtitle">Last 5 Reservations <a href="alltransactions.php" class="float-right small">View All</a></h6>

            <!-- <a class="btn btn-link btn-sm" href="projects.php">View all</a> -->

            <div class="row">
                <div class="col-12 px-0">
                    <ul class="list-group list-group-flush border-top border-bottom">
                    <?php
                        $reservation = Reservation::getLast5ReservationsByUser();
                        foreach ($reservation as $value) {
                            ?>
                        <li class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col-auto pr-0">
                                    <div class="avatar avatar-50 no-shadow border-0">
                                        <img style="width: 160%;" src="<? echo $value->parkingPhoto?>" alt="">
                                    </div>
                                </div>
                                <div class="col align-self-center pr-0">
                                    <h6 class="font-weight-normal mb-1"><? echo $value->parkingName?></h6>
                                    <p class="text-mute small text-secondary"><? echo $value->reservationCrate?></p>
                                </div>
                                <div class="col-auto">
                                    <h6 class="text-danger">5.0 DH</h6>
                                </div>
                            </div>
                        </li>
                        <?php
                        }
                    ?>
                        
                    </ul>
                </div>
            </div>
            <!-- page content ends -->
        </div>

        <!-- footer-->
        <div class="footer">
            <ul class="nav nav-tabs justify-content-center" id="myTab" role="tablist">
                <li class="nav-item">
                    <a href="index.php" class="nav-link active" id="home-tab" role="tab" aria-controls="home" aria-selected="true">
                        <i class="material-icons">home</i>
                        <small class="sr-only">Home</small>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="search-tab" href="map.php" role="tab" aria-controls="search" aria-selected="false">
                        <i class="material-icons">room</i>
                        <small class="sr-only">search</small>
                    </a>
                    <!-- </li>
                <li class="nav-item centerlarge">
                    <a class="nav-link bg-default" id="cart-tab" data-toggle="tab" href="#cart" role="tab" aria-controls="cart" aria-selected="false">
                        <i class="material-icons">shopping_basket</i>
                        <small class="sr-only">chat</small>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="favorite-tab" data-toggle="tab" href="#favorite" role="tab" aria-controls="favorite" aria-selected="false">
                        <i class="material-icons">star</i>
                        <small class="sr-only">Best</small>
                    </a>
                </li> -->
                <li class="nav-item">
                    <a class="nav-link" id="profile-tab" href="profile.php" role="tab" aria-controls="profile" aria-selected="false">
                        <i class="material-icons">person</i>
                        <small class="sr-only">Account</small>
                    </a>
                </li>
            </ul>
        </div>
        <!-- footer ends-->

    </div>

    <!-- notification -->
    <div class="notification bg-white shadow-sm border-primary">
        <div class="row">
            <!-- <div class="col-auto align-self-center pr-0">
                <i class="material-icons text-primary md-36">fullscreen</i>
            </div> -->
            <div class="col">
                <h6 style="text-align: center;">Welcome <? echo $user['userName'] ?> to ParkFinder</h6>
                <!-- <p class="mb-0 text-secondary"></p> -->
            </div>
            <div class="col-auto align-self-center pl-0">
                <button class="btn btn-link closenotification"><i class="material-icons text-secondary text-mute md-18 ">close</i></button>
            </div>
        </div>
    </div>
    <!-- notification ends -->

    <!-- color chooser menu start -->
    <div class="modal fade " id="colorscheme" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content ">
                <div class="modal-header theme-header border-0">
                    <h6 class="">Color Picker</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body pt-0">
                    <div class="text-center theme-color">
                        <button class="m-1 btn red-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="red-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn blue-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="blue-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn yellow-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="yellow-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn green-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="green-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn pink-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="pink-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn orange-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="orange-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn purple-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="purple-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn deeppurple-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="deeppurple-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn lightblue-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="lightblue-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn teal-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="teal-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn lime-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="lime-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn deeporange-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="deeporange-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn gray-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="gray-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn black-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="black-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-6 text-left">
                        <div class="row">
                            <div class="col-auto text-right align-self-center"><i class="material-icons text-warning vm">wb_sunny</i></div>
                            <div class="col-auto text-center align-self-center px-0">
                                <div class="custom-control custom-switch float-right">
                                    <input type="checkbox" name="themelayout" class="custom-control-input" id="theme-dark">
                                    <label class="custom-control-label" for="theme-dark"></label>
                                </div>
                            </div>
                            <div class="col-auto text-left align-self-center"><i class="material-icons text-dark vm">brightness_2</i></div>
                        </div>
                    </div>
                    <div class="col-6 text-right">
                        <div class="row">
                            <div class="col-auto text-right align-self-center">LTR</div>
                            <div class="col-auto text-center align-self-center px-0">
                                <div class="custom-control custom-switch float-right">
                                    <input type="checkbox" name="rtllayout" class="custom-control-input" id="theme-rtl">
                                    <label class="custom-control-label" for="theme-rtl"></label>
                                </div>
                            </div>
                            <div class="col-auto text-left align-self-center">RTL</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- color chooser menu ends -->

    <!-- Modal -->
    <div class="modal fade" id="addmoney" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center pt-0">
                    <img src="img/infomarmation-graphics2.png" alt="logo" class="logo-small">
                    <div class="form-group mt-4">
                        <input type="text" class="form-control form-control-lg text-center" placeholder="Enter amount" required="" autofocus="">
                    </div>
                    <p class="text-mute">You will be redirected to payment gatway to procceed further. Enter amount in USD.</p>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-default btn-lg btn-rounded shadow btn-block" class="close" data-dismiss="modal">Next</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="sendmoney" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5>Send Money</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body pt-0">
                    <div class="form-group mt-4">
                        <select class="form-control form-control-lg text-center">
                            <option>Mrs. Magon Johnson</option>
                            <option selected>Ms. Shivani Dilux</option>
                        </select>
                    </div>

                    <div class="card shadow border-0 mb-3">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-auto pr-0">
                                    <div class="avatar avatar-60 no-shadow border-0">
                                        <img src="img/user2.png" alt="">
                                    </div>
                                </div>
                                <div class="col">
                                    <h6 class="font-weight-normal mb-1">Ms. Shivani Dilux</h6>
                                    <p class="text-mute small text-secondary">London, UK</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group text-center mt-4">
                        <input type="text" class="form-control form-control-lg text-center" placeholder="Enter amount" required="" autofocus="">
                    </div>
                    <p class="text-mute text-center">You will be redirected to payment gatway to procceed further. Enter amount in USD.</p>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-default btn-lg btn-rounded shadow btn-block" class="close" data-dismiss="modal">Next</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="paymodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5>Pay</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body pt-0">
                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="customRadioInline1" name="customRadioInline1" class="custom-control-input">
                        <label class="custom-control-label" for="customRadioInline1">To Bill</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input" checked>
                        <label class="custom-control-label" for="customRadioInline2">To Person</label>
                    </div>

                    <div class="form-group mt-4">
                        <select class="form-control text-center">
                            <option>Mrs. Magon Johnson</option>
                            <option selected>Ms. Shivani Dilux</option>
                        </select>
                    </div>

                    <div class="card shadow border-0 mb-3">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-auto pr-0">
                                    <div class="avatar avatar-60 no-shadow border-0">
                                        <img src="img/user2.png" alt="">
                                    </div>
                                </div>
                                <div class="col align-self-center">
                                    <h6 class="font-weight-normal mb-1">Ms. Shivani Dilux</h6>
                                    <p class="text-mute small text-secondary">London, UK</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group text-center mt-4">
                        <input type="text" class="form-control form-control-lg text-center" placeholder="Enter amount" required="" autofocus="">
                    </div>
                    <p class="text-mute text-center">You will be redirected to payment gatway to procceed further. Enter amount in USD.</p>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-default btn-lg btn-rounded shadow btn-block" class="close" data-dismiss="modal">Next</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="bookmodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5>Pay</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body pt-0">
                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="customRadioInline12" name="customRadioInline12" class="custom-control-input">
                        <label class="custom-control-label" for="customRadioInline12">Flight</label>
                    </div>
                    <div class="custom-control custom-radio custom-control-inline">
                        <input type="radio" id="customRadioInline22" name="customRadioInline12" class="custom-control-input" checked>
                        <label class="custom-control-label" for="customRadioInline22">Train</label>
                    </div>
                    <h6 class="subtitle">Select Location</h6>
                    <div class="form-group mt-4">
                        <input type="text" class="form-control text-center" placeholder="Select start point" required="" autofocus="">
                    </div>
                    <div class="form-group mt-4">
                        <input type="text" class="form-control text-center" placeholder="Select end point" required="">
                    </div>
                    <h6 class="subtitle">Select Date</h6>
                    <div class="form-group mt-4">
                        <input type="date" class="form-control text-center" placeholder="Select end point" required="">
                    </div>
                    <h6 class="subtitle">number of passangers</h6>
                    <div class="form-group mt-4">
                        <select class="form-control  text-center">
                            <option>1</option>
                            <option selected>2</option>
                            <option>3</option>
                            <option>4</option>
                            <option>5</option>
                            <option>6</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-default btn-lg btn-rounded shadow btn-block" class="close" data-dismiss="modal">Next</button>
                </div>
            </div>
        </div>
    </div>

    <!-- jquery, popper and bootstrap js -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap-4.4.1/js/bootstrap.min.js"></script>

    <!-- swiper js -->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- cookie js -->
    <script src="vendor/cookie/jquery.cookie.js"></script>

    <!-- template custom js -->
    <script src="js/main.js"></script>

    <!-- page level script -->
    <script></script>

</body>


<!-- Mirrored from maxartkiller.com/website/Fimobile/Fimobile-HTML/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 Jun 2021 14:56:30 GMT -->

</html>