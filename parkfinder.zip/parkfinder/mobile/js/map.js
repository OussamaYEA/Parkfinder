

navigator.geolocation.getCurrentPosition(successLocation, errorLocation, {
  enableHighAccuracy: true
})
 
function successLocation(position) {
  setupMap([position.coords.longitude, position.coords.latitude])
}
 
function errorLocation() {
  setupMap([-6.890341847701545, 33.95829695956633])
}
 
function setupMap(center) {
  
  /* const nav = new mapboxgl.NavigationControl()
  map.addControl(nav) */
  
  var directions = new MapboxDirections({
    accessToken: mapboxgl.accessToken
  })
  
  map.addControl(directions, "top-left")

  var marker1 = new mapboxgl.Marker()
  .setLngLat(center).setPopup(new mapboxgl.Popup({ offset: 25 }) // add popups
  .setHTML('<h5>My Location</h5><p></p>'))
  .addTo(map);

  
  


  

  map.addControl(new mapboxgl.GeolocateControl({
    positionOption:{
      enableHighAccuracy: true
    },
    trackUserLocation: true
  }))
  const inputs = []
  const reserveBtn = document.getElementById('reserve-btn')
  document.querySelectorAll("input[type='text']").forEach(function(input) {
    input.addEventListener('change', function(e){
      if ( inputs[0].value && inputs[1].value ) {
        reserveBtn.classList.remove('invisible')
        reserveBtn.classList.add('visible')
      } else {
        reserveBtn.classList.remove('visible')
        reserveBtn.classList.add('invisible')
      }
    })
    inputs.push(input)
  })
}

document.getElementById('reserve-btn').addEventListener('click',function(){
  document.querySelector('.bg-modal').style.display = 'flex';
});
document.querySelector('.close').addEventListener('click',function(){
  document.querySelector('.bg-modal').style.display = 'none'
})