<?php
  require_once 'Models/User.php';
  include_once 'includes/header.php';
  require_once 'Models/Parking.php';
  
?>
<!doctype html>
<html lang="en" class="deeppurple-theme">


<!-- Mirrored from maxartkiller.com/website/Fimobile/Fimobile-HTML/statistics.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 Jun 2021 14:57:07 GMT -->
<head>
    <link rel="shortcut icon" href="images/favicon1.png"/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="Maxartkiller">

    <title>Map · Parkfinder</title>

    <script src='https://api.mapbox.com/mapbox-gl-js/v1.12.0/mapbox-gl.js'></script>
    <link href='https://api.mapbox.com/mapbox-gl-js/v1.12.0/mapbox-gl.css' rel='stylesheet' />
    <script
    src="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-directions/v4.1.0/mapbox-gl-directions.js"></script>
    <link rel="stylesheet"
    href="https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-directions/v4.1.0/mapbox-gl-directions.css"
    type="text/css" />
    <!-- Material design icons CSS -->
    <link rel="stylesheet" href="vendor/materializeicon/material-icons.css">

    <!-- Roboto fonts CSS -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap-4.4.1/css/bootstrap.min.css" rel="stylesheet">

    <!-- Swiper CSS -->
    <link href="vendor/swiper/css/swiper.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <style>
    body {
      margin: 0;
    }

    #map {
      height: 100vh;
      width: 100vw;
    }

    a.mapboxgl-ctrl-logo {
      display: none;
    }

    .mapboxgl-ctrl-attrib-inner {
      display: none;
    }
    .mapboxgl-ctrl-top-left {
    top: 50px;
    left: 0;
    }
    .mapboxgl-ctrl-top-right {
    top: 50;
    right: 0;
    }

    .modal-dialog {
      text-align: center;
    }

    .flex {
      display: flex;
      flex-direction: column;
    }

    .btn {
      width: 100%;
    }

    span {
      margin-top: 2%;
      margin-bottom: 2%;
    }

    .reserve {
      position: absolute;
      margin-left: 1%;
      top: 78%;
    }

    .directions-control.directions-control-directions {
      display: block;
    }

    .bg-modal {
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.7);
      position: absolute;
      top: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      display: none;
      z-index: 2;
    }

    .modal-content {
      width: 90%;
      height: 40%;
      background: white;
      border-radius: 5px;
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .close {
      position: absolute;
      top: 0;
      font-size: 42px;
      opacity: 1;
      transform: rotate(45deg);
      cursor: pointer;
      padding-left: 2%;
    }

    form {
      display: flex;
      flex-direction: column;
      align-content: center;
      justify-content: center;
      align-items: center;
    }

    form input {
      margin-top: 2%;
      margin-bottom: 2%;
      width: 90%;
      border-radius: 5px;
      border: none;
      background: gainsboro;
      padding: 1%;
    }

    form span {
      margin: 0 5%;
    }

    .time {
      display: flex;
      flex-direction: row;
      align-items: center;
      align-content: center;
      justify-content: center;
      width: 90%;
    }
    .marker {
      background:url('images/icons/parking.svg');
      background-size: cover;
      width: 50px;
      height: 50px;
      border-radius: 50%;
      cursor: pointer;
      padding: 10px;
      box-sizing: border-box;
    }
    .wrapper{
        height: 100%;
    }
    
  </style>
</head>

<body>
    <div class="row no-gutters vh-100 loader-screen">
        <div class="col align-self-center text-white text-center">
            <img src="img/logo1.png" alt="logo">
            <h1 class="mt-3"><span class="font-weight-light ">P</span>arkfinder</h1>
            <p class="text-mute text-uppercase small"></p>
            <div class="laoderhorizontal">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>
    <!-- sidebar -->
    <?php
	require_once './Models/User.php';
?>
<?php
    $user = $_SESSION["currentUser"];
    if(!isset($_SESSION['currentUser'])){
        header("Location:login.php");
    }
?>
<div class="sidebar">
        <div class="my-5">
            <div class="row">
                <div class="col-auto">
                    <figure class="avatar avatar-60 border-0"><img src="img/user1.png" alt=""></figure>
                </div>
                <div class="col pl-0 align-self-center">
                    <h5 class="mb-1"><?echo $user['userName'] ?></h5>
                    <p class="text-mute small"><?echo $user['userCity'] ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="list-group main-menu">
                    <a href="index.php" class="list-group-item list-group-item-action "><i class="material-icons icons-raised">home</i>Home</a>
                    <a href="notification.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised">notifications</i>Notification <span class="badge badge-dark text-white">2</span></a>
                    <a href="pricing.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised">monetization_on</i>Add Solde</a>
                    <a href="alltransactions.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised">find_in_page</i>History</a>                    
                    <!-- <a href="javascript:void(0)" class="list-group-item list-group-item-action" data-toggle="modal" data-target="#colorscheme"><i class="material-icons icons-raised">color_lens</i>Color scheme</a> -->
                    <a href="contactus.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised">question_answer</i>Contact US</a>
                    <a href="aboutus.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised">assignment_ind</i>About US</a>
                    <a href="faqs.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised">feedback</i>FAQs</a>
                    <a href="logout.php" class="list-group-item list-group-item-action"><i class="material-icons icons-raised bg-danger">power_settings_new</i>Logout</a>
                </div>
            </div>
        </div>
    </div>
    <a href="javascript:void(0)" class="closesidemenu"><i class="material-icons icons-raised bg-dark ">close</i></a>
    <style>
        .mt-5, .my-5 {
        margin-top: 5rem!important;
        }
        .col-auto {
            padding-top: 15px;
        }
        .header .btn{
            height: 0px;
        }
    </style>
    <!-- end sidebar -->
    <div class="wrapper">
        <!-- header -->
        
        <!-- header ends -->
        

        <div id='map'></div>
        <div class="reserve">
            <a class="reserve" id="reserve">
            <button type="submit" id="reserve-btn" class="btn btn-warning invisible">Reserve Now</button></a>
        </div>
        <div class="bg-modal">
        <div class="modal-content">
        <div class="close">+</div>
        <form action="">
            <input type="text" placeholder="Parking Name">
            <div class="time">
            <input type="time" placeholder="Departure-Time">
            <span>To</span>
            <input type="time" placeholder="Arrival-Time">
            </div>

            <input placeholder="Enter Your Matriculate Number" type="text">
            <a class="reserve" id="reserve">
            <button type="submit" id="reserve-btn" class="btn btn-warning">Reserve Now</button>
            </a>
        </form>
        </div>
        </div>
        

        <!-- footer-->
        <div class="footer">
        
            <ul class="nav nav-tabs justify-content-center" id="myTab" role="tablist">
                <li class="nav-item">
                    <a href="index.php" class="nav-link" id="home-tab"  role="tab" aria-controls="home" aria-selected="true">
                        <i class="material-icons">home</i>
                        <small class="sr-only">Home</small>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" id="search-tab" href="map.php" role="tab" aria-controls="search" aria-selected="false">
                        <i class="material-icons">room</i>
                        <small class="sr-only">search</small>
                    </a>
                <!-- </li>
                <li class="nav-item centerlarge">
                    <a class="nav-link bg-default" id="cart-tab" data-toggle="tab" href="#cart" role="tab" aria-controls="cart" aria-selected="false">
                        <i class="material-icons">shopping_basket</i>
                        <small class="sr-only">chat</small>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="favorite-tab" data-toggle="tab" href="#favorite" role="tab" aria-controls="favorite" aria-selected="false">
                        <i class="material-icons">star</i>
                        <small class="sr-only">Best</small>
                    </a>
                </li> -->
                <li class="nav-item">
                    <a class="nav-link" id="profile-tab"  href="profile.php" role="tab" aria-controls="profile" aria-selected="false">
                        <i class="material-icons">person</i>
                        <small class="sr-only">Account</small>
                    </a>
                </li>
            </ul>
        </div>
        <!-- footer ends-->

    </div>




    <!-- color chooser menu start -->
    <div class="modal fade " id="colorscheme" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content ">
                <div class="modal-header theme-header border-0">
                    <h6 class="">Color Picker</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body pt-0">
                    <div class="text-center theme-color">
                        <button class="m-1 btn red-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="red-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn blue-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="blue-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn yellow-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="yellow-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn green-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="green-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn pink-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="pink-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn orange-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="orange-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn purple-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="purple-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn deeppurple-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="deeppurple-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn lightblue-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="lightblue-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn teal-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="teal-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn lime-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="lime-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn deeporange-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="deeporange-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn gray-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="gray-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn black-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="black-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-6 text-left">
                        <div class="row">
                            <div class="col-auto text-right align-self-center"><i class="material-icons text-warning vm">wb_sunny</i></div>
                            <div class="col-auto text-center align-self-center px-0">
                                <div class="custom-control custom-switch float-right">
                                    <input type="checkbox" name="themelayout" class="custom-control-input" id="theme-dark">
                                    <label class="custom-control-label" for="theme-dark"></label>
                                </div>
                            </div>
                            <div class="col-auto text-left align-self-center"><i class="material-icons text-dark vm">brightness_2</i></div>
                        </div>
                    </div>
                    <div class="col-6 text-right">
                        <div class="row">
                            <div class="col-auto text-right align-self-center">LTR</div>
                            <div class="col-auto text-center align-self-center px-0">
                                <div class="custom-control custom-switch float-right">
                                    <input type="checkbox" name="rtllayout" class="custom-control-input" id="theme-rtl">
                                    <label class="custom-control-label" for="theme-rtl"></label>
                                </div>
                            </div>
                            <div class="col-auto text-left align-self-center">RTL</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- color chooser menu ends -->


    <!-- jquery, popper and bootstrap js -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap-4.4.1/js/bootstrap.min.js"></script>

    <!-- swiper js -->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- cookie js -->
    <script src="vendor/cookie/jquery.cookie.js"></script>

    <!-- chart js -->
    <script src="vendor/chartjs/Chart.min.js"></script>
    <script src="vendor/chartjs/utils.js"></script>

    <!-- template custom js -->
    <script src="js/main.js"></script>

    <!-- page level script -->
    <script>
    mapboxgl.accessToken =
  "pk.eyJ1IjoiYXpoYmJ4IiwiYSI6ImNrcHdlcmQ1bTBpamsydnAyM2p3dXowNXIifQ.pNO-sIvUH5zOxytCFuH-7Q"


 

    var center = [-7.61838,33.59224];
    var map = new mapboxgl.Map({
    container: "map",
    style: "mapbox://styles/azhbbx/ckq14htdf0bce17k38tnj64t0",
    center: center,
    zoom: 15

    })

    <?php
    $parkings = Parking::getAllParkingsList();
        foreach ($parkings as $value) {
    ?>

    var el = document.createElement('div');
    el.className = 'marker';
    
    new mapboxgl.Marker(el)
    .setLngLat([<? echo $value->parkingGps?>]).setPopup(new mapboxgl.Popup({ offset: 25 }) // add popups
    .setHTML('<img style="width:183px" src="<? echo $value->parkingPhoto?>"><h3 style="text-align:center;text-transform:uppercase;"><? echo $value->parkingName?></h3><p><? echo $value->parkingDescription?></p> <a href="reserve.php?parking=parking&id=<?php echo $value->parkingId?>" type="submit" class="btn btn-lg btn-default text-white btn-block btn-rounded shadow"><span>Reserve</span></a> '))
    .addTo(map);
            

    <?php
}
?>


  </script>
  <script src="js/map.js" defer></script>

</body>


<!-- Mirrored from maxartkiller.com/website/Fimobile/Fimobile-HTML/statistics.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 Jun 2021 14:57:10 GMT -->
</html>
