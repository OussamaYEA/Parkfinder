<!doctype html>
<html lang="en" class="deeppurple-theme">


<!-- Mirrored from maxartkiller.com/website/Fimobile/Fimobile-HTML/pricing.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 Jun 2021 14:57:11 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="Maxartkiller">

    <title>Pricing · Parkfinder</title>

    <!-- Material design icons CSS -->
    <link rel="shortcut icon" href="images/favicon1.png"/>
    <link rel="stylesheet" href="vendor/materializeicon/material-icons.css">

    <!-- Roboto fonts CSS -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap-4.4.1/css/bootstrap.min.css" rel="stylesheet">

    <!-- Swiper CSS -->
    <link href="vendor/swiper/css/swiper.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Loader -->
    <div class="row no-gutters vh-100 loader-screen">
        <div class="col align-self-center text-white text-center">
            <img src="img/logo1.png" alt="logo">
            <h1 class="mt-3"><span class="font-weight-light ">P</span>arkfinder</h1>
            <p class="text-mute text-uppercase small"></p>
            <div class="laoderhorizontal">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>
    <!-- Loader ends -->

    <!-- sidebar -->
    <?php
        include_once 'includes/sidebar.php';
        ?>
    <!-- sidebar ends -->

    <div class="wrapper">
        <!-- header -->
        <?php
        include_once 'includes/header.php';
        ?>

        <div class="container">
            <!-- page content here -->
            <h3 class="font-weight-light text-center mt-4">Affordable<br><span class="text-template">Pricing</span> and <span class="text-template">Plan</span></h3>
            <p class="text-secondary text-mute text-center mb-4">5 DH for Reservation And 5 DH for 1-Hour</p>
            
            <div class="card shadow border-0 mb-3">
                <div class="card-body">
                    <div class="row h-100">
                        <div class="col-auto pr-0">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay gradient-danger"></div>
                                <i style="padding-left: 13px;" class="material-icons text-danger md-36">attach_money attach_money</i>
                            </div>
                        </div>
                        <div class="col">
                            <h3>20 DH <small class="text-mute text-secondary"></small></h3>
                            <ul class="list pl-4 my-3">
                                <li>Up to 2 Reservations</li>

                            </ul>
                            <button href="Controllers/authenticate_controller.php?add20solde=<?php echo $value->userId?>" class="btn btn-default btn-rounded-54 shadow" data-toggle="modal" data-target="#addmoney20"><i class="material-icons">add</i></button>
                        </div>
                    </div>
                </div>
            </div>            
            <div class="card shadow border-0 mb-3">
                <div class="card-body">
                    <div class="row h-100">
                        <div class="col-auto pr-0">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay gradient-danger"></div>
                                <i style="padding-left: 13px;" class="material-icons text-danger md-36">attach_money attach_money</i>
                            </div>
                        </div>
                        <div class="col">
                            <h3>50 DH <small class="text-mute text-secondary"></small></h3>
                            <ul class="list pl-4 my-3">
                                <li>Up to 2 Reservations</li>
                            </ul>
                            <button class="btn btn-default btn-rounded-54 shadow" data-toggle="modal" data-target="#addmoney50"><i class="material-icons">add</i></button>
                        </div>
                    </div>
                </div>
            </div>            
            <div class="card shadow border-0 mb-3">
                <div class="card-body">
                    <div class="row h-100">
                        <div class="col-auto pr-0">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay gradient-success"></div>
                                <i style="padding-left: 13px;" class="material-icons text-success md-36">attach_money attach_money</i>
                            </div>
                        </div>
                        <div class="col">
                            <h3>100 DH <small class="text-mute text-secondary"></small></h3>
                            <ul class="list pl-4 my-3">
                                <li>Up to 10 Reservations</li>
                            </ul>
                            <button class="btn btn-default btn-rounded-54 shadow" data-toggle="modal" data-target="#addmoney100"><i class="material-icons">add</i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card shadow border-0 mb-3">
                <div class="card-body">
                    <div class="row h-100">
                        <div class="col-auto pr-0">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay gradient-success"></div>
                                <i style="padding-left: 13px;" class="material-icons text-success md-36">attach_money attach_money</i>
                            </div>
                        </div>
                        <div class="col">
                            <h3>300 DH <small class="text-mute text-secondary"></small></h3>
                            <ul class="list pl-4 my-3">
                                <li>Up to 30 Reservations</li>
                            </ul>
                            <button class="btn btn-default btn-rounded-54 shadow" data-toggle="modal" data-target="#addmoney300"><i class="material-icons">add</i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card shadow border-0 mb-3">
                <div class="card-body">
                    <div class="row h-100">
                        <div class="col-auto pr-0">
                            <div class="avatar avatar-60 no-shadow border-0">
                                <div class="overlay gradient-success"></div>
                                <i style="padding-left: 13px;" class="material-icons text-success md-36">attach_money attach_money</i>
                            </div>
                        </div>
                        <div class="col">
                            <h3>500 DH <small class="text-mute text-secondary"></small></h3>
                            <ul class="list pl-4 my-3">
                                <li>Up to 50 Reservations</li>
                            </ul>
                            <button class="btn btn-default btn-rounded-54 shadow" data-toggle="modal" data-target="#addmoney500"><i class="material-icons">add</i></button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- page content ends -->
        </div>

        <!-- footer-->
        <div class="footer">
            <ul class="nav nav-tabs justify-content-center" id="myTab" role="tablist">
                <li class="nav-item">
                    <a href="index.php" class="nav-link" id="home-tab"  role="tab" aria-controls="home" aria-selected="true">
                        <i class="material-icons">home</i>
                        <small class="sr-only">Home</small>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="search-tab" href="map.php" role="tab" aria-controls="search" aria-selected="false">
                        <i class="material-icons">room</i>
                        <small class="sr-only">search</small>
                    </a>
                <!-- </li>
                <li class="nav-item centerlarge">
                    <a class="nav-link bg-default" id="cart-tab" data-toggle="tab" href="#cart" role="tab" aria-controls="cart" aria-selected="false">
                        <i class="material-icons">shopping_basket</i>
                        <small class="sr-only">chat</small>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="favorite-tab" data-toggle="tab" href="#favorite" role="tab" aria-controls="favorite" aria-selected="false">
                        <i class="material-icons">star</i>
                        <small class="sr-only">Best</small>
                    </a>
                </li> -->
                <li class="nav-item">
                    <a class="nav-link" id="profile-tab"  href="profile.php" role="tab" aria-controls="profile" aria-selected="false">
                        <i class="material-icons">person</i>
                        <small class="sr-only">Account</small>
                    </a>
                </li>
            </ul>
        </div>
        <!-- footer ends-->
    </div>

    <!-- Modal -->
    <div class="modal fade" id="addmoney" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center pt-0">
                    <img src="img/card.png" alt="logo" class="logo-small">
                    <div class="form-group mt-4">
                        <input type="text" class="form-control form-control-lg text-center" placeholder="Enter amount" autofocus="" required>
                    </div>
                    <p class="text-mute">Please enter your credit card to continue your payment.</p>
                </div>
                <div class="modal-footer border-0">
                <a href="Controllers/authenticate_controller.php?add20solde=<?php echo $value->userId?>">test</a>
                    <button type="button" class="btn btn-default btn-lg btn-rounded shadow btn-block" class="close" data-dismiss="modal">Next</button>
                </div>
            </div>
        </div>
    </div>
    <!-- test 20 dh -->
    <form>
    <div class="modal fade" id="addmoney20" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center pt-0">
                    <img src="img/card.png" alt="logo" class="logo-small">
                    <div class="form-group mt-4">
                        <input type="text" class="form-control form-control-lg text-center" placeholder="Enter amount" required>
                    </div>
                    <p class="text-mute">Please enter your credit card to continue your payment.</p>
                </div>
                <div class="modal-footer border-0">
                
                    <a href ="Controllers/authenticate_controller.php?add20solde=<?php echo $value->userId?>"  type="submit" class="btn btn-default btn-lg btn-rounded shadow btn-block" class="" >Next</a>
                </div>
            </div>
        </div>
    </div>
    </form>
    <!-- test 50 dh -->
    <div class="modal fade" id="addmoney50" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center pt-0">
                    <img src="img/card.png" alt="logo" class="logo-small">
                    <div class="form-group mt-4">
                        <input type="text" class="form-control form-control-lg text-center" placeholder="Enter credit card" required>
                    </div>
                    <p class="text-mute">Please enter your credit card to continue your payment.</p>
                </div>
                <div class="modal-footer border-0">
                
                    <a href ="Controllers/authenticate_controller.php?add50solde=<?php echo $value->userId?>"  type="button" class="btn btn-default btn-lg btn-rounded shadow btn-block" class="close" >Next</a>
                </div>
            </div>
        </div>
    </div>
    <!-- test 100 dh -->
    <div class="modal fade" id="addmoney100" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center pt-0">
                    <img src="img/card.png" alt="logo" class="logo-small">
                    <div class="form-group mt-4">
                        <input type="text" class="form-control form-control-lg text-center" placeholder="Enter amount" required="" autofocus="">
                    </div>
                    <p class="text-mute">Please enter your credit card to continue your payment.</p>
                </div>
                <div class="modal-footer border-0">
                
                    <a href ="Controllers/authenticate_controller.php?add100solde=<?php echo $value->userId?>"  type="button" class="btn btn-default btn-lg btn-rounded shadow btn-block" class="close" >Next</a>
                </div>
            </div>
        </div>
    </div>
    <!-- test 300 dh -->
    
    <div class="modal fade" id="addmoney300" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center pt-0">
                    <img src="img/card.png" alt="logo" class="logo-small">
                    <div class="form-group mt-4">
                        <input type="text" class="form-control form-control-lg text-center" placeholder="Enter amount" required="" autofocus="">
                    </div>
                    <p class="text-mute">Please enter your credit card to continue your payment.</p>
                </div>
                <div class="modal-footer border-0">
                
                    <a href ="Controllers/authenticate_controller.php?add300solde=<?php echo $value->userId?>"  type="submit" class="btn btn-default btn-lg btn-rounded shadow btn-block" class="close" >Next</a>
                </div>
            </div>
        </div>
    </div>
    
    <!-- test 500 dh -->
    <div class="modal fade" id="addmoney500" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center pt-0">
                    <img src="img/card.png" alt="logo" class="logo-small">
                    <div class="form-group mt-4">
                        <input type="text" class="form-control form-control-lg text-center" placeholder="Enter amount" required="" autofocus="">
                    </div>
                    <p class="text-mute">Please enter your credit card to continue your payment.</p>
                </div>
                <div class="modal-footer border-0">
                
                    <a href ="Controllers/authenticate_controller.php?add500solde=<?php echo $value->userId?>"  type="button" class="btn btn-default btn-lg btn-rounded shadow btn-block" class="close" >Next</a>
                </div>
            </div>
        </div>
    </div>

    <!-- color chooser menu start -->
    <div class="modal fade " id="colorscheme" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content ">
                <div class="modal-header theme-header border-0">
                    <h6 class="">Color Picker</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body pt-0">
                    <div class="text-center theme-color">
                        <button class="m-1 btn red-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="red-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn blue-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="blue-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn yellow-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="yellow-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn green-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="green-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn pink-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="pink-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn orange-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="orange-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn purple-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="purple-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn deeppurple-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="deeppurple-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn lightblue-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="lightblue-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn teal-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="teal-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn lime-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="lime-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn deeporange-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="deeporange-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn gray-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="gray-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn black-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="black-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-6 text-left">
                        <div class="row">
                            <div class="col-auto text-right align-self-center"><i class="material-icons text-warning vm">wb_sunny</i></div>
                            <div class="col-auto text-center align-self-center px-0">
                                <div class="custom-control custom-switch float-right">
                                    <input type="checkbox" name="themelayout" class="custom-control-input" id="theme-dark">
                                    <label class="custom-control-label" for="theme-dark"></label>
                                </div>
                            </div>
                            <div class="col-auto text-left align-self-center"><i class="material-icons text-dark vm">brightness_2</i></div>
                        </div>
                    </div>
                    <div class="col-6 text-right">
                        <div class="row">
                            <div class="col-auto text-right align-self-center">LTR</div>
                            <div class="col-auto text-center align-self-center px-0">
                                <div class="custom-control custom-switch float-right">
                                    <input type="checkbox" name="rtllayout" class="custom-control-input" id="theme-rtl">
                                    <label class="custom-control-label" for="theme-rtl"></label>
                                </div>
                            </div>
                            <div class="col-auto text-left align-self-center">RTL</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- color chooser menu ends -->


    <!-- jquery, popper and bootstrap js -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap-4.4.1/js/bootstrap.min.js"></script>

    <!-- swiper js -->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- cookie js -->
    <script src="vendor/cookie/jquery.cookie.js"></script>

    <!-- template custom js -->
    <script src="js/main.js"></script>

    <!-- page level script -->
    <script>
        $(window).on('load', function() {

        });

    </script>

</body>


<!-- Mirrored from maxartkiller.com/website/Fimobile/Fimobile-HTML/pricing.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 Jun 2021 14:57:11 GMT -->
</html>
