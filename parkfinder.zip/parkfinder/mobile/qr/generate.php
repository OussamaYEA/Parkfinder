<?php
header("Content-Type: image/png");
require "vendor/autoload.php";
require_once '../Models/Reservation.php';

use Endroid\QrCode\QrCode;

$reservation = Reservation::getReservationById($_GET['id']);
$parkingName =  $reservation->parkingName;


$qrcode = new QrCode(
    "User Name : $reservation->userName;
    Parking Name :$parkingName
    Departure Time : $reservation->departureTime
    Arrival Time : $reservation->arrivalTime
    Car Number : $reservation->carNumber
    Reservation Create : $reservation->reservationCrate"

);

echo $qrcode->writeString();
die();