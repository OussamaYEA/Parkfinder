<?php
    /* if(!isset($_SESSION['currentUser'])){
        header("Location:index.php");
    } */
?>
<!doctype html>
<html lang="en" class="deeppurple-theme">


<!-- Mirrored from maxartkiller.com/website/Fimobile/Fimobile-HTML/signup.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 Jun 2021 14:57:13 GMT -->
<head>
    <meta charset="utf-8">
    <link rel="shortcut icon" href="images/favicon1.png"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="Maxartkiller">

    <title>Signup · Parkfinder</title>

    <!-- Material design icons CSS -->
    <link rel="stylesheet" href="vendor/materializeicon/material-icons.css">

    <!-- Roboto fonts CSS -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap-4.4.1/css/bootstrap.min.css" rel="stylesheet">

    <!-- Swiper CSS -->
    <link href="vendor/swiper/css/swiper.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Loader -->
    <div class="row no-gutters vh-100 loader-screen">
        <div class="col align-self-center text-white text-center">
            <img src="img/logo1.png" alt="logo">
            <h1 class="mt-3"><span class="font-weight-light ">P</span>arkfinder</h1>
            <p class="text-mute text-uppercase small"></p>
            <div class="laoderhorizontal">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>
    <!-- Loader ends -->

    <div class="wrapper">
        <!-- header -->
        <div class="header">
            <div class="row no-gutters">
                <div class="col-auto">
                    <a href="introduction.php" class="btn  btn-link text-dark"><i class="material-icons">chevron_left</i></a>
                </div>
                <div class="col text-center"></div>
                <div class="col-auto">
                </div>
            </div>
        </div>
        <!-- header ends -->

        <div class="row no-gutters login-row">
            <div class="col align-self-center px-3 text-center">
                <br>
                <img src="img/logo1.png" alt="logo" class="logo-small">
                <form class="form-signin mt-3 " action="Controllers/authenticate_controller.php" method="POST">
                    <div class="form-group float-label">
                        <input name="name" type="text" id="inputFullName" class="form-control form-control-lg" required>
                        <label for="inputFullName" class="form-control-label">Full Name</label>
                    </div>
                    <div class="form-group float-label">
                        <input name="email" type="email" id="inputEmail" class="form-control form-control-lg" required>
                        <label for="inputEmail" class="form-control-label">Email</label>
                    </div>
                    <div class="form-group float-label">
                        <input name="cin" style="text-transform:uppercase;" type="text" id="inputCIN" class="form-control form-control-lg" required>
                        <label for="inputCIN" class="form-control-label">CIN</label>
                    </div>
                    <!-- <div class="form-group float-label">
                        <select style="background-color: #ffffff;
                        border-radius: 20px;
                        z-index: 1;
                        position: relative;
                        width: 100%;
                        height: 38px;" id="gender" name="gender" class="gender">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>>
                        </select>
                        <label for="inputGender" class="form-control-label"></label>
                    </div> -->
                    <div class="form-group float-label">
                        <select id="form_need" name="gender" class="form-control" required="required">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                        <label style="top: 0;" class="form-control-label" for="form_need">Please specify your Gender</label>
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group float-label">
                        <input name="birth" type="date" max="2002-01-01" id="inputGender" class="form-control form-control-lg" required>
                        <label style="top: 0;" for="inputGender" class="form-control-label">Birth</label>
                    </div>
                    <div class="form-group float-label">
                        <input name="city" type="text" id="inputGender" class="form-control form-control-lg" required>
                        <label for="inputGender" class="form-control-label">City</label>
                    </div>
                    <div class="form-group float-label">
                        <input name="phone" type="text" id="inputPhone" class="form-control form-control-lg" required>
                        <label for="inputPhone" class="form-control-label">Phone</label>
                    </div>
                    
                    <div class="form-group float-label">
                        <input name="pass" type="password" id="inputPassword" class="form-control form-control-lg" required>
                        <label for="inputPassword" class="form-control-label">Password</label>
                    </div>
                    <div class="form-group float-label">
                        <input name="passrpt" type="password" id="confirmPassword" class="form-control form-control-lg" required>
                        <label for="confirmPassword" class="form-control-label">Confirm Password</label>
                    </div>

                    
                    <?php
                        $err = isset($_GET['error']) ?  $_GET['error'] : "";
                    ?>
                    <p style="color:orangered;font-weight: bold;"><?= $err ?></p>
                    <button type="submit" name="save" class="btn btn-default btn-lg btn-rounded shadow btn-block">Register</button>
                    <p class="mt-4 d-block text-secondary">
                        By clicking register your are agree to the
                        <a href="javascript:void(0)">Terms and Condition.</a>
                    </p>
                </form>
            </div>
        </div>

        <!-- login buttons -->
        <!-- <div class="row mx-0 bottom-button-container">
            <div class="col">
                <a href="otp.php" class="btn btn-default btn-lg btn-rounded shadow btn-block">Next</a>
            </div>
        </div> -->
        <!-- login buttons -->
    </div>


    <!-- color chooser menu start -->
    <div class="modal fade " id="colorscheme" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content ">
                <div class="modal-header theme-header border-0">
                    <h6 class="">Color Picker</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body pt-0">
                    <div class="text-center theme-color">
                        <button class="m-1 btn red-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="red-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn blue-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="blue-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn yellow-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="yellow-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn green-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="green-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn pink-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="pink-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn orange-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="orange-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn purple-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="purple-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn deeppurple-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="deeppurple-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn lightblue-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="lightblue-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn teal-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="teal-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn lime-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="lime-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn deeporange-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="deeporange-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn gray-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="gray-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                        <button class="m-1 btn black-theme-bg text-white btn-rounded-54 shadow-sm" data-theme="black-theme"><i class="material-icons w-50">color_lens_outline</i></button>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="col-6 text-left">
                        <div class="row">
                            <div class="col-auto text-right align-self-center"><i class="material-icons text-warning vm">wb_sunny</i></div>
                            <div class="col-auto text-center align-self-center px-0">
                                <div class="custom-control custom-switch float-right">
                                    <input type="checkbox" name="themelayout" class="custom-control-input" id="theme-dark">
                                    <label class="custom-control-label" for="theme-dark"></label>
                                </div>
                            </div>
                            <div class="col-auto text-left align-self-center"><i class="material-icons text-dark vm">brightness_2</i></div>
                        </div>
                    </div>
                    <div class="col-6 text-right">
                        <div class="row">
                            <div class="col-auto text-right align-self-center">LTR</div>
                            <div class="col-auto text-center align-self-center px-0">
                                <div class="custom-control custom-switch float-right">
                                    <input type="checkbox" name="rtllayout" class="custom-control-input" id="theme-rtl">
                                    <label class="custom-control-label" for="theme-rtl"></label>
                                </div>
                            </div>
                            <div class="col-auto text-left align-self-center">RTL</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- color chooser menu ends -->


    <!-- jquery, popper and bootstrap js -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="vendor/bootstrap-4.4.1/js/bootstrap.min.js"></script>

    <!-- swiper js -->
    <script src="vendor/swiper/js/swiper.min.js"></script>

    <!-- cookie js -->
    <script src="vendor/cookie/jquery.cookie.js"></script>

    <!-- template custom js -->
    <script src="js/main.js"></script>

</body>


<!-- Mirrored from maxartkiller.com/website/Fimobile/Fimobile-HTML/signup.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 Jun 2021 14:57:14 GMT -->
</html>
