<?php
require_once './Models/User.php';
$userId = User::getAllUsersList();
print_r ($user->userCreate);
require_once './Models/Parking.php';
require_once './Models/Reservation.php';

//print_r($userId->userId);
?>
<?php
$user = $_SESSION["currentUser"];

?>
<!doctype html>
<html lang="en" class="deeppurple-theme">


<!-- Mirrored from maxartkiller.com/website/Fimobile/Fimobile-HTML/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 12 Jun 2021 14:56:08 GMT -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, viewport-fit=cover, user-scalable=no">
    <meta name="description" content="">
    <meta name="author" content="Maxartkiller">

    <title>Home · Fimobile</title>

    <!-- Material design icons CSS -->
    <link rel="stylesheet" href="vendor/materializeicon/material-icons.css">

    <!-- Roboto fonts CSS -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap-4.4.1/css/bootstrap.min.css" rel="stylesheet">

    <!-- Swiper CSS -->
    <link href="vendor/swiper/css/swiper.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <!-- <link href="css/style.css" rel="stylesheet"> -->
    <!-- <link href="css/style1.css" rel="stylesheet">
    <link href="css/swiper-bundle.min.css" rel="stylesheet"> -->
</head>
<main>
    
<main>

<body>

    
    <!-- end sidebar -->
    <div class="wrapper homepage">
        <!-- header -->
        <?php
        //include_once 'includes/header.php';
        ?>
        <h1><?php print_r($user['userCreate'])?></h1>

