<?php

require '../Models/Admin.php';
require_once '../Models/functions.inc.php';





/* $admin = new Admin($tempAdmin->adminId, $tempAdmin->adminName, $tempAdmin->adminEmail, $tempAdmin->adminCin, $tempAdmin->adminGender, $tempAdmin->adminBirth, $tempAdmin->adminCity, $tempAdmin->adminPhone, $tempAdmin->adminSup, $tempAdmin->adminPassword, $tempAdmin->adminStatus, $tempAdmin->adminCreate);

if($admin->deleteAdminById($id)){
    header("Location: ../admin.php");
}
else{
    
    header("location: ../admin.php?error=Error:Incorrect mail or password, please try again");
} 

?> */