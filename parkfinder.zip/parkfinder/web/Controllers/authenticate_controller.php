<?php

require '../Models/Admin.php';
require '../Models/functions.inc.php';

if (isset($_POST['save'])) {
    $adminName = isset($_POST['name']) ? $_POST['name'] : "";
    $adminEmail = isset($_POST['email']) ? $_POST['email'] : "" ;
    $adminCin = isset($_POST['cin']) ? $_POST['cin']:"" ;
    $adminGender = isset($_POST['gender']) ? $_POST['gender']:"" ;
    $adminBirth = isset($_POST['birth']) ? $_POST['birth'] : "" ;
    $adminCity = isset($_POST['city']) ? $_POST['city'] : "" ;
    $adminPhone = isset($_POST['phone'])? $_POST['phone'] : "";
    $adminSup = isset($_POST['sup'])? $_POST['sup'] : "";
    $adminPassword = isset($_POST['pass'])? $_POST['pass'] : "";
    $adminPasswordrpt = isset($_POST['passrpt'])? $_POST['passrpt'] : "";



    if (emptyInputRegister($adminName, $adminEmail, $adminCin, $adminGender, $adminBirth, $adminCity, $adminPhone, $adminPassword, $adminPasswordrpt) !== false) {
        header("location:/parkfinder/web/addadmin.php?error=empty inptut");
        exit();
    }
    if (invalidName($adminName) !== false) {
        header("location:/parkfinder/web/addadmin.php?error=invalid name");
        exit();
    }
    if (invalidEmail($adminEmail) !== false) {
        header("location:/parkfinder/web/addadmin.php?error=invalid email");
        exit();
    }
    if (invalidNumber($adminPhone) !== false) {
        header("location:/parkfinder/web/addadmin.php?error=invalid phone");
        exit();
    }

    if (passMatch($adminPassword, $adminPasswordrpt) !== false) {
        header("location:/parkfinder/web/addadmin.php?error=passwords dont match");
        exit();
    }

    $admin = new Admin(0, $adminName, $adminEmail, $adminCin, $adminGender, $adminBirth, $adminCity, $adminPhone, $adminSup, $adminPassword, $adminStatus, $adminCreate);

    $adminAdded = $admin->AdminRegisterLogic();
    if($adminAdded){
        $_SESSION['currentUser'] = $admin;
        header("Location: ../admin.php");
    }
    else{
        //print_r($adminAdded );
        header("Location:../addadmin.php?error=Error:User already exists");
    }
}

if (isset($_POST['update'])) {
    $adminId = $_POST['id'];
    $adminName = isset($_POST['name']) ? $_POST['name'] : "";
    $adminEmail = isset($_POST['email']) ? $_POST['email'] : "" ;
    $adminCin = isset($_POST['cin']) ? $_POST['cin']:"" ;
    $adminGender = isset($_POST['gender']) ? $_POST['gender']:"" ;
    $adminBirth = isset($_POST['birth']) ? $_POST['birth'] : "" ;
    $adminCity = isset($_POST['city']) ? $_POST['city'] : "" ;
    $adminPhone = isset($_POST['phone'])? $_POST['phone'] : "";
    $adminSup = isset($_POST['sup'])? $_POST['sup'] : "";
    $adminPassword = isset($_POST['pass'])? $_POST['pass'] : "";
    $adminPasswordrpt = isset($_POST['passrpt'])? $_POST['passrpt'] : "";

    $admin = new Admin($adminId, $adminName, $adminEmail, $adminCin, $adminGender, $adminBirth, $adminCity, $adminPhone, $adminSup, $adminPassword, $adminStatus, $adminCreate);

    
    $adminUpdated = $admin->editAdminById($adminId);
    if($adminUpdated){
        header("Location: ../admin.php");
    }
    else{
        print_r($admin);
        print($adminUpdated);
        printf($adminUpdated);
        
        //header("Location:../editadmin.php?error=Error");
    }
}

if (isset($_GET['deleteId'])) {
	$adminId = $_GET['deleteId'];
    $admin = new Admin(null, null, null, null, null, null,null, null, null, null, null, null);
    $adminRemoved = $admin->deleteAdminById($adminId);

    if($adminRemoved){
        header("Location: ../admin.php");
    }
    else{
        header("Location:../editadmin.php?error=Error");
    }
}

if (isset($_GET['blockId'])) {
    $adminId = $_GET['blockId'];
    $admin = new Admin($adminId, null, null, null, null, null, null, null, null, null, null, null);
    $adminBlocked = $admin->blockAdminById($adminId);
    if($adminBlocked){
        header("Location: ../admin.php");
    }
    else{
        header("Location:../admin.php?error=Error");
    }
        
}
if (isset($_GET['unblockId'])) {
    echo("unblockid");
    $adminId = $_GET['unblockId'];
    //$user = new User($userId, $userName, $userEmail, $userCin, $userGender, $userBirth, $userCity, $userPhone, $userPhoto, $userSolde, $userTotalReservation, $userPassword, $userStatus, $userCreate);
    //print_r($user);
    $admin = new Admin($adminId, null, null, null, null, null, null, null, null, null, null, null);
    $adminUnblocked = $admin->unblockAdminById($adminId);
    if($adminUnblocked){
        header("Location: ../admin.php");
    }
    else{        
        header("Location:../admin.php?error=Error");
    }
        
}



?>