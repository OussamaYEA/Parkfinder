<?php

require '../Models/Admin.php';
require_once '../Models/functions.inc.php';


$adminEmail = isset($_POST['email']) ? $_POST['email'] : "";
$adminPassword = isset($_POST['password']) ? $_POST['password']: "";




$tempAdmin = Admin::getAdminByMailAndPassword($adminEmail, $adminPassword);

if($adminEmail == '' || $adminPassword == ''){
    header("Location: ../index.php?error=Both mail and password are mandatory");
exit();
}



$admin = new Admin($tempAdmin->adminId, $tempAdmin->adminName, $tempAdmin->adminEmail, $tempAdmin->adminCin, $tempAdmin->adminGender, $tempAdmin->adminBirth, $tempAdmin->adminCity, $tempAdmin->adminPhone, $tempAdmin->adminSup, $tempAdmin->adminPassword, $tempAdmin->adminStatus, $tempAdmin->adminCreate);

if($admin->AdminLoginLogic()){
    $_SESSION['currentAdmin'] = $admin;
    //print_r($admin);
    header("Location: ../home.php");
}
else{
    
    header("location: ../index.php?error=Error:Incorrect mail or password, please try again");
} 

?>