<?php

require '../Models/Notification.php';

if (isset($_POST['answer'])) {
    $notificationsName = isset($_POST['mcategory']) ? $_POST['mcategory'] : "";
    $notificationsDescription = isset($_POST['message']) ? $_POST['message'] : "";
    $userName = isset($_POST['userName']) ? $_POST['userName'] : "" ;

    /* if (emptyInputReservation($parkingName, $departureTime, $arrivalTime, $carNumber) !== false) {
        header("location:../map.php?error=empty inptut");
        exit();
    } */
    
    /* echo("dzddza");

    print $notificationsName;
    print $notificationsDescription;
    print $userName; */
    
    print $userName;
    $notification = new Notification(0, $notificationsName, $notificationsDescription, $userName, $notificationsStatus, $notificationsCreate);
    $NotificationAdded = $notification->AddAnswerLogic();
    if($NotificationAdded){
        header("Location: ../inbox.php");
        /* print_r($reservation);
        print_r($ReservationAdded);
        print_r($parkingPhoto); */
    }
    else{
        /* print_r($reservation);
        print_r($departureTime); */
        header("Location:../inbox-message.php?error=Error Try Later");
    }
}