<?php
require_once '../Models/Parking.php';
//$action = isset($_GET['action'])? $_GET['action'] : '';

if (isset($_POST['add'])){
    $parkingName = isset($_POST['name']) ? $_POST['name'] : "";
    $parkingDescription = isset($_POST['desc']) ? $_POST['desc']:"" ;
    $parkingGps = isset($_POST['gps']) ? $_POST['gps']:"" ;
    $parkingPhoto = isset($_POST['capacity']) ? $_POST['capacity']:"" ;
    $parkingCapacity = isset($_POST['photo']) ? $_POST['photo']:"" ;

    
    $parking = new Parking(0, $parkingName, $parkingDescription , $parkingGps, $parkingCapacity, $parkingPhoto, $parkingStatus, $parkingCreate);
    $ParkingAdded = $parking->AddParkingLogic();
    if($ParkingAdded){
        header("Location: ../parking.php");
    }
    else{
        //print_r($ParkingAdded);
        header("Location:../addparking.php?error=Error:Parking already exists");
    }
}

if (isset($_POST['update'])) {
    $parkingId = $_POST['id'];
    $parkingName = isset($_POST['name']) ? $_POST['name'] : "";
    $parkingDescription = isset($_POST['desc']) ? $_POST['desc']:"" ;
    $parkingGps = isset($_POST['gps']) ? $_POST['gps']:"" ;
    $parkingPhoto = isset($_POST['capacity']) ? $_POST['capacity']:"" ;
    $parkingCapacity = isset($_POST['photo']) ? $_POST['photo']:"" ;

    $parking = new Parking($parkingId, $parkingName, $parkingDescription , $parkingGps, $parkingCapacity, $parkingPhoto, $parkingStatus, $parkingCreate);
    
    $parkingUpdated = $parking->editParkingById($parkingId);
    if($parkingUpdated){
        header("Location: ../parking.php");
    }
    else{
        header("Location: ../editparking.php?error=Error");
    }
}

if (isset($_GET['deleteId'])) {
    $parkingId = $_GET['deleteId'];
    $parking = new Parking(null, null, null, null, null, null, null, null);
    $parkingRemoved = $parking->deleteParkingById($parkingId);

    if($parkingRemoved){
        header("Location: ../parking.php");
    }
    else{
        header("Location:../editadmin.php?error=Error");
    }
}


if (isset($_GET['blockId'])) {
    $parkingId = $_GET['blockId'];
    $parking = new Parking($parkingId, null, null, null, null, null, null, null);
    $parkingBlocked = $parking->blockParkingById($parkingId);
    if($parkingBlocked){
        header("Location: ../parking.php");
    }
    else{   
        header("Location:../parking.php?error=Error");
    }
        
}
if (isset($_GET['unblockId'])) {
    echo("unblockid");
    $parkingId = $_GET['unblockId'];
    //$user = new User($userId, $userName, $userEmail, $userCin, $userGender, $userBirth, $userCity, $userPhone, $userPhoto, $userSolde, $userTotalReservation, $userPassword, $userStatus, $userCreate);
    //print_r($user);
    $parking = new Parking($parkingId, null, null, null, null, null, null, null);
    $parkingUnblocked = $parking->unblockParkingById($parkingId);
    if($parkingUnblocked){
        header("Location: ../parking.php");
    }
    else{
            
    header("Location:../parking.php?error=Error");
    }
}
?>