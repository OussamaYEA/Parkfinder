<?php

require '../Models/User.php';
//require '../Models/functions.inc.php';

if (isset($_GET['blockId'])) {
    $userId = $_GET['blockId'];
    $user = new User($userId);
    $userBlocked = $user->blockUserById($userId);
    if($userBlocked){
        header("Location: ../users.php");
    }
    else{
        header("Location:../editadmin.php?error=Error");
    }
    
}
if (isset($_GET['unblockId'])) {
    echo("unblockid");
    $userId = $_GET['unblockId'];
    //$user = new User($userId, $userName, $userEmail, $userCin, $userGender, $userBirth, $userCity, $userPhone, $userPhoto, $userSolde, $userTotalReservation, $userPassword, $userStatus, $userCreate);
    //print_r($user);
    $user = new User($userId);
    $userUnlocked = $user->unblockUserById($userId);
    if($userUnlocked){
        header("Location: ../users.php");
    }
    else{        
        header("Location:../users.php?error=Error");
    }
    
}
