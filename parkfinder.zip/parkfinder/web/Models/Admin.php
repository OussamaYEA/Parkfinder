<?php
session_start();
require_once 'dbConnection.php';
class Admin
{
    public $adminId;
    public $adminName;
    public $adminEmail;
    public $adminCin;
    public $adminGender;
    public $adminBirth;
    public $adminCity;
    public $adminPhone;
    public $adminSup;
    public $adminPassword;
    public $adminStatus;
    public $adminCreate;



    public function __construct($adminId, $adminName, $adminEmail, $adminCin, $adminGender, $adminBirth, $adminCity, $adminPhone,$adminSup, $adminPassword, $adminStatus, $adminCreate)
    {
        $this->adminId = $adminId;
        $this->adminName = $adminName;
        $this->adminEmail = $adminEmail;
        $this->adminCin= $adminCin;
        $this->adminGender = $adminGender;
        $this->adminBirth = $adminBirth;
        $this->adminCity = $adminCity;
        $this->adminPhone = $adminPhone;
        $this->adminSup = $adminSup;
        $this->adminPassword = $adminPassword;
        $this->adminStatus = $adminStatus;
        $this->adminCreate = $adminCreate;
    }

    public function AdminRegisterLogic(){
        
        $dbConnection = Db::GetConnection();
        $response = $dbConnection->query("select * from admins");
        while($row = $response->fetch())
        {
            if($row['adminEmail'] == $this->adminEmail){
                return false;
            }
        }
        //$hashedPass = password_hash($pass, PASSWORD_DEFAULT);
        $sql = 'insert into `admins` (`adminId`, `adminName`, `adminEmail`, `adminCin`, `adminGender`, `adminBirth`, `adminCity`, `adminPhone`, `adminSup`, `adminPassword`) VALUES (NULL, "' . $this->adminName .'", "' . $this->adminEmail .'", "' . $this->adminCin .'","' . $this->adminGender . '", "' .  $this->adminBirth .'", "' . $this->adminCity .'", "' . $this->adminPhone .'","' . $this->adminSup .'", "' . $this->adminPassword .'");';
        $added = $dbConnection->exec($sql);
        $dbConnection = null;
        if($added){
            return true;
        }
        return false;
        
    }

    public function AdminLoginLogic(){
        
        $dbConnection = Db::GetConnection();
        $response = $dbConnection->query("select * from admins");
        while($row = $response->fetch())
        {
            if($row['adminEmail'] == $this->adminEmail && $row['adminPassword'] == $this->adminPassword){
                $dbConnection = null;
                return true;
            }
        }
        $dbConnection = null;
        return false;
    }

    public static function getAdminByMailAndPassword($adminEmail, $adminPassword){
        
        $dbConnection = Db::GetConnection();
        $response = $dbConnection->query('select * from admins');
        while($row = $response->fetch())
        {
            if($row['adminEmail'] == $adminEmail && $row['adminPassword'] == $adminPassword){
                $dbConnection = null;
                return new Admin($row['adminId'], $row['adminName'], $row['adminEmail'], $row['adminCin'], $row['adminGender'], $row['adminBirth'], $row['adminCity'], $row['adminPhone'], $row['adminSup'], $row['adminPassword'], $row['adminStatus'], $row['adminCreate']);
            }
        }
        $dbConnection = null;
        return null;
    }
    

    public static function getAllAdminsList()
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query('SELECT * FROM `admins`;');
        $admins = [];
        while($row = $response->fetch()){
            $a = new Admin($row['adminId'], $row['adminName'], $row['adminEmail'], $row['adminCin'], $row['adminGender'], $row['adminBirth'], $row['adminCity'], $row['adminPhone'], $row['adminSup'], $row['adminPassword'], $row['adminStatus'], $row['adminCreate']);
            array_push($admins, $a);
        }
        return $admins;
    }
    
    public static function getAdminById($id)
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query("SELECT * FROM `admins` WHERE adminId = '$id' ;");        
        $row = $response->fetch();
        $a = new Admin($row['adminId'], $row['adminName'], $row['adminEmail'], $row['adminCin'], $row['adminGender'], $row['adminBirth'], $row['adminCity'], $row['adminPhone'], $row['adminSup'], $row['adminPassword'], $row['adminStatus'], $row['adminCreate']);
        return $a;
    }
    public function editAdminById($adminId)
    {
        $dbConnection = Db::GetConnection();
        $sql = "UPDATE admins SET adminName='$this->adminName', adminEmail='$this->adminEmail', adminCin ='$this->adminCin', adminGender='$this->adminGender', adminBirth='$this->adminBirth', adminCity='$this->adminCity', adminPhone='$this->adminPhone', adminSup='$this->adminSup', adminPassword='$this->adminPassword' WHERE adminId = $adminId";
        $updated = $dbConnection->exec($sql);
        //printf($sql);
        $dbConnection = null;
        if($updated){
            return true;
        }
        return false;

    }
    public static function deleteAdminById($id)
    {
        $DbConnection = Db::GetConnection();
        $sql = "DELETE FROM `admins` WHERE adminId = '$id' ;";
        $removed = $DbConnection->exec($sql);      
        $dbConnection = null;
        if($removed){
            return true;
        }
        return false;
    }

    public function blockAdminById($adminId)
    {
        $dbConnection = Db::GetConnection();
        $sql = "UPDATE admins SET adminStatus='0' WHERE adminId = $adminId";
        $updated = $dbConnection->exec($sql);
        printf($sql);
        $dbConnection = null;
        if($updated){
            return true;
        }
        return false;
    }

    public function unblockAdminById($adminId)
    {
        $dbConnection = Db::GetConnection();
        $sql = "UPDATE admins SET adminStatus='1' WHERE adminId = $adminId";
        print $sql;
        $updated = $dbConnection->exec($sql);
        //printf($sql);
        $dbConnection = null;
        if($updated){
            return true;
        }
        return false;
    }

}


?>