<?php

require_once 'dbConnection.php';

class Notification{
    
    public $notificationsId;
    public $notificationsName;
    public $notificationsDescription;
    public $userName;
    public $notificationsStatus;
    public $notificationsCreate;

    public function __construct($notificationsId, $notificationsName, $notificationsDescription, $userName, $notificationsStatus, $notificationsCreate)
    {   
        $this->notificationsId = $notificationsId;
        $this->notificationsName = $notificationsName;
        $this->notificationsDescription = $notificationsDescription;
        $this->userName = $userName;
        $this->notificationsStatus = $notificationsStatus;
        $this->notificationsCreate = $notificationsCreate;

    }
    public function AddAnswerLogic(){
        
        $dbConnection = Db::GetConnection();
        /* $response = $dbConnection->query("select count(*) as total from notifications WHERE parkingName = '". $this->parkingName ."'");
        $row = $response->fetch();

        print "Total count : " . $row['total'];

        if ( intval($row['total']) > 0 ) return false; */
        /*while($row = $response->fetch())
        {
            if($row['ProductName'] == $this->Name){
                return false;
            }
        }*/
        
        $sql = "insert into `notifications` (`notificationsId`, `notificationsName`, `notificationsDescription`, `userName`) VALUES (NULL, 'Support','Hey $this->userName $this->notificationsDescription','$this->userName')";
        $added = $dbConnection->exec($sql);

        print $added;
        print $sql;
        
        $dbConnection = null;
        if($added){
            return true;
            print "ok 2";
        }
        return false;
        
    }

    public static function getAllNotificationList()
    {
        $userName = $_SESSION["currentUser"]['userName'];
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query("SELECT * FROM `notifications` WHERE userName ='$userName';");
        $notifications = [];
        while($row = $response->fetch()){
            $n = new Notification($row['notificationsId'],$row['notificationsName'], $row['notificationsDescription'], $row['userName'], $row['notificationsStatus'], $row['notificationsCreate']);
            array_push($notifications, $n);
        }
        return $notifications;
    }
}