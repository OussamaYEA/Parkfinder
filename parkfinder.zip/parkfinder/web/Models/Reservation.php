<?php
session_start();
require_once 'dbConnection.php';
class Reservation
{
    public $reservationId;
    public $userName;
    public $parkingName;
    public $departureTime;
    public $arrivalTime;
    public $carNumber;
    public $reservationStatus;
    public $reservationCrate;

    public function __construct($reservationId, $userName, $parkingName, $departureTime, $arrivalTime, $carNumber, $reservationStatus, $reservationCrate)
    {
        $this->reservationId = $reservationId;
        $this->userName = $userName;
        $this->parkingName = $parkingName;
        $this->departureTime= $departureTime;
        $this->arrivalTime = $arrivalTime;
        $this->carNumber = $carNumber;
        $this->reservationStatus = $reservationStatus;
        $this->reservationCrate = $reservationCrate;
    }


    public static function getAllReservationsList()
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query('SELECT * FROM `reservations` order by reservationId desc;');
        $reservations = [];
        while($row = $response->fetch()){
            $r = new Reservation($row['reservationId'], $row['userName'], $row['parkingName'], $row['departureTime'], $row['arrivalTime'], $row['carNumber'], $row['reservationStatus'], $row['reservationCrate']);
            //$parkingName = $DbConnection->query('SELECT * FROM `reservations` WHERE parkingName='. $row['parkingName'] .';')->fetch();
            array_push($reservations, $r);
            //array_push($reservations, $parkingName);
        }
        return $reservations;
    }

    public static function getLast10Reservations()
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query('SELECT * from reservations order by reservationId desc limit 10;');
        $reservations = [];
        while($row = $response->fetch()){
            $r = new Reservation($row['reservationId'], $row['userName'], $row['parkingName'], $row['departureTime'], $row['arrivalTime'], $row['carNumber'], $row['reservationStatus'], $row['reservationCrate']);
            array_push($reservations, $r);
        }
        return $reservations;
    }




}