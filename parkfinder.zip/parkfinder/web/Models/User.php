<?php
session_start();
require_once 'dbConnection.php';
class User
{
    public $userId;
    public $userName;
    public $userEmail;
    public $userCin;
    public $userGender;
    public $userBirth;
    public $userCity;
    public $userPhone;
    public $userPhoto;
    public $userSolde;
    public $userTotalReservation;
    public $userPassword;
    public $userStatus;
    public $userConfirmation;
    public $userCreate;

    public function setUserId($userId){
        $this->userId = $userId;
    }

    public function getUserId(){
        return $this->userId;
    }

    public function __construct($userId = null, $userName = null, $userEmail = null, $userCin = null, $userGender = null, $userBirth = null, $userCity = null, $userPhone = null, $userPhoto = null, $userSolde = null, $userTotalReservation = null, $userPassword = null, $userStatus = null,$userConfirmation = null, $userCreate = null)
    {
        $this->userId = $userId;
        $this->userName = $userName;
        $this->userEmail = $userEmail;
        $this->userCin= $userCin;
        $this->userGender = $userGender;
        $this->userBirth = $userBirth;
        $this->userCity = $userCity;
        $this->userPhone = $userPhone;
        $this->userPhoto = $userPhoto;
        $this->userSolde = $userSolde;
        $this->userTotalReservation = $userTotalReservation;
        $this->userPassword = $userPassword;    
        $this->userStatus = $userStatus;
        $this->userConfirmation = $userConfirmation;
        $this->userCreate = $userCreate;
    }

    public function UserRegisterLogic(){
        
        $dbConnection = Db::GetConnection();
        $response = $dbConnection->query("select * from users");
        while($row = $response->fetch())
        {
            if($row['userEmail'] == $this->userEmail){
                return false;
            }
        }
        //$hashedPass = password_hash($pass, PASSWORD_DEFAULT);
        $sql = 'insert into `users` (`userId`, `userName`, `userEmail`, `userCin`, `userGender`, `userBirth`, `userCity`, `userPhone`, `userPassword`) VALUES (NULL, "' . $this->userName .'", "' . $this->userEmail .'", "' . $this->userCin .'", "' . $this->userGender . '", "' .  $this->userBirth .'", "' . $this->userCity .'", "' . $this->userPhone .'", "' . $this->userPassword .'");';
        $added = $dbConnection->exec($sql);
        $dbConnection = null;
        if($added){
            return true;
        }
        return false;
        
    }

    public function UserLoginLogic(){
        
        $dbConnection = Db::GetConnection();
        $response = $dbConnection->query("select * from users");
        while($row = $response->fetch())
        {
            if($row['userEmail'] == $this->userEmail && $row['userPassword'] == $this->userPassword){
                $dbConnection = null;
                return true;
            }
        }
        $dbConnection = null;
        return false;
    }

    public static function getUserByMailAndPassword($userEmail, $userPassword){
        
        $dbConnection = Db::GetConnection();
        $response = $dbConnection->query('select * from users');
        while($row = $response->fetch())
        {
            if($row['userEmail'] == $userEmail && $row['userPassword'] == $userPassword){
                $dbConnection = null;
                return new User($row['userId'], $row['userName'], $row['userEmail'], $row['userCin'], $row['userGender'], $row['userBirth'], $row['userCity'], $row['userPhone'], $row['userPhoto'], $row['userSolde'], $row['userTotalReservation'], $row['userPassword'], $row['userStatus'], $row['userCreate']);
            }
        }
        $dbConnection = null;
        return null;
    }
    

    public static function getAllUsersList()
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query('SELECT * FROM `users`;');
        $users = [];
        while($row = $response->fetch()){
            $u = new User($row['userId'], $row['userName'], $row['userEmail'], $row['userCin'], $row['userGender'], $row['userBirth'], $row['userCity'], $row['userPhone'], $row['userPhoto'], $row['userSolde'], $row['userTotalReservation'], $row['userPassword'], $row['userStatus'], $row['userConfirmation'], $row['userCreate']);
            array_push($users, $u);
        }
        return $users;
    }

    public static function getLast10Users()
    {
        $DbConnection = Db::GetConnection();
        $response = $DbConnection->query('SELECT * from users order by userId desc limit 10;');
        $users = [];
        while($row = $response->fetch()){
            $u = new User($row['userId'], $row['userName'], $row['userEmail'], $row['userCin'], $row['userGender'], $row['userBirth'], $row['userCity'], $row['userPhone'], $row['userPhoto'], $row['userSolde'], $row['userTotalReservation'], $row['userPassword'], $row['userStatus'], $row['userConfirmation'], $row['userCreate']);
            array_push($users, $u);
        }
        return $users;
    }


    
    public function blockUserById($userId)
    {
        $dbConnection = Db::GetConnection();
        $sql = "UPDATE users SET userStatus='0' WHERE userId = $userId";
        $updated = $dbConnection->exec($sql);
        printf($sql);
        $dbConnection = null;
        if($updated){
            return true;
        }
        return false;
    }

    public function unblockUserById($userId)
    {
        $dbConnection = Db::GetConnection();
        $sql = "UPDATE users SET userStatus='1' WHERE userId = $userId";
        print $sql;
        $updated = $dbConnection->exec($sql);
        //printf($sql);
        $dbConnection = null;
        if($updated){
            return true;
        }
        return false;
    }

}


?>