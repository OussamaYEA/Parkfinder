<!doctype html>
<html lang="en">

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/pages-register.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:52 GMT -->
<head>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="https://realitycheckinc.com/wp-content/themes/themify-ultra/themify/themify-icons/themify-icons.css" rel="stylesheet" type="text/css" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Primex - Admin Dashboard Template</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="image/favicon1.png"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="css/bundle.css" type="text/css">

    <!-- App styles -->
    <link rel="stylesheet" href="css/app.min.css" type="text/css">
</head>
<body class="form-membership">

<!-- begin::preloader-->
<div class="preloader">
    <div class="preloader-icon"></div>
</div>
<!-- end::preloader -->

<div class="form-wrapper">

    
    <!-- logo -->
    <div id="logo">
        <img class="logo" src="image/Fichier 4.png" style="width: 128px;" alt="image">
        <img class="logo-dark" src="../../assets/media/image/logo-dark.php" alt="image">
    </div>
    <!-- ./ logo -->

    <h5>Add Parking</h5>

    <!-- form -->
    <form action="Controllers/parking_controller.php" method="POST">
        <div class="form-group">
            <input name="name" type="text" class="form-control" placeholder="Parking Name" required autofocus>
        </div>
        <div class="form-group">
            <input name="desc" type="text" class="form-control" placeholder="Parking Description" required>
        </div>
        <div class="form-group">
            <input name="gps" type="text" class="form-control" placeholder="GPS" required>
        </div>
        <div class="form-group">
            <label for="capacity">Capacity of Cars By Number</label>
            <input name="capacity" type="number"min= "1" class="form-control" placeholder="Capacity Of Parking " required>
        </div>
        <div class="form-group">
            <label for="photo">Select Image</label>
            <input name="photo" type="text" class="form-control" placeholder="Image" required>
        </div>
        
        <?php 
            $err = isset($_GET['error']) ? $_GET['error'] : "";
        ?>
        <p style="color:red"><?= $err ?></p>
        <button type="submit" name="add" class="btn btn-primary btn-block">Add Parking</button><br><br>
        <a href="parking.php" class="btn btn-outline-light btn-sm">Back</a>
        <hr>
    </form>
    <!-- ./ form -->


</div>

<!-- Plugin scripts -->
<script src="js/bundle.js"></script>

<!-- App scripts -->
<script src="js/app.min.js"></script>
</body>

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/pages-register.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:52 GMT -->
</html>
