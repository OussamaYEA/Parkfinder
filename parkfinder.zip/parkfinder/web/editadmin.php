
<?php
    require_once 'Models/Admin.php';
?>
<!doctype html>
<html lang="en">

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/pages-register.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:52 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Parkfinder - Add Admin</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="image/favicon1.png"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="css/bundle.css" type="text/css">

    <!-- App styles -->
    <link rel="stylesheet" href="css/app.min.css" type="text/css">
</head>
<body class="form-membership">

<!-- begin::preloader-->
<!-- <div class="preloader">
    <div class="preloader-icon"></div>
</div> -->
<!-- end::preloader -->

<div class="form-wrapper">

    
    <!-- logo -->
    <div id="logo">
        <img class="logo" src="image/Fichier 4.png" style="width: 128px;" alt="image">
        <img class="logo-dark" src="../../assets/media/image/logo-dark.php" alt="image">
    </div>
    <!-- ./ logo -->

    <h5>Edit Admin</h5>

    <!-- form -->
    
    <form action="Controllers/authenticate_controller.php" method="POST">
    <?php
        $admin = Admin::getAdminById($_GET['id']);
    ?>
        <input type="hidden" name="id" value="<? echo $admin->adminId?>" >
        <div class="form-group">
            <input type="text" class="form-control" name="name" placeholder="Full Name" value="<? echo $admin->adminName?>" required autofocus>
        </div>
        <div class="form-group">
            <input type="email" class="form-control" name="email" placeholder="Email" value="<? echo $admin->adminEmail?>" required>
        </div>
        <div class="form-group">
            <input style="text-transform:uppercase" type="text" class="form-control" name="cin" placeholder="CIN" value="<? echo $admin->adminCin?>" required>
        </div>
        <div class="form-group">
            <select style="width: 100%; color: #495057;font-family: inherit;border: 1px solid #ced4da;height: 37px;border-radius: 9px;" id="country" name="gender" class="country">
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>      
        </div>
        <div class="form-group">
            <input type="date" class="form-control" name="birth" placeholder="Birth" max="2003-01-01" value="<? echo $admin->adminBirth?>" required>
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="city" placeholder="City" value="<? echo $admin->adminCity?>" required>
        </div>
        <div class="form-group">
            <input type="tel" class="form-control" name="phone" placeholder="Phone Number" value="<? echo $admin->adminPhone?>" required>
        </div>
        <div class="form-group">
            <input type="number" max="1" min="0" value="0" class="form-control" name="sup" placeholder="Sup" value="<? echo $admin->adminSup?>" required>
        </div>
        
        <div class="form-group">
            <input type="text" class="form-control" name="pass" placeholder="Password" value="<? echo $admin->adminPassword?>" required>
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="passrpt" placeholder="Confirm Password" value="<? echo $admin->adminPassword?>" required>
        </div>
        <?php 
             $err = isset($_GET['error']) ? $_GET['error'] : "";
        ?>
        <p style="color:orangered; font-size:25px;font-weight: bold;"><?= $err ?></p>
        <button type="submit" name="update" class="btn btn-primary btn-block">Edit Admin</button>
        <hr>

        <a href="admin.php" class="btn btn-outline-light btn-sm">Back</a>
    </form>
    <!-- ./ form -->


</div>

<!-- Plugin scripts -->
<script src="js/bundle.js"></script>

<!-- App scripts -->
<script src="js/app.min.js"></script>
</body>


</html>
