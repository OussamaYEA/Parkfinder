<?php
require_once './Models/Admin.php';
require_once 'Models/Parking.php';
require_once 'Models/User.php';
require_once 'Models/Reservation.php';
?>
<!doctype html>
<html lang="en">

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:03 GMT -->
<head>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="https://realitycheckinc.com/wp-content/themes/themify-ultra/themify/themify-icons/themify-icons.css" rel="stylesheet" type="text/css" />
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Parkfinder - Home</title>

    <!-- Favicon -->
    <link rel="stylesheet" href="css/material-icons.css">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="shortcut icon" href="image/favicon1.png"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="css/bundle.css" type="text/css">

    
    <!-- Slick -->
    <link rel="stylesheet" href="css/slick.css" type="text/css">
    <link rel="stylesheet" href="css/slick-theme.css" type="text/css">

    <!-- Daterangepicker -->
    <link rel="stylesheet" href="css/daterangepicker.css" type="text/css">

    <!-- DataTable -->
    <link rel="stylesheet" href="css/datatables.min.css" type="text/css">

    <!-- App styles -->
    <link rel="stylesheet" href="css/app.min.css" type="text/css">
</head>
<body  class="stretch-layout small-navigation dark">

<!-- begin::preloader-->
<!-- <div class="preloader">
    <div class="preloader-icon"></div>
</div> -->
<!-- end::preloader -->
<?php
    include_once 'includes/header.php';
?>



    

    <!-- begin::main-content -->
    <div class="main-content">

    
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="">
                <a href=home.php>Home</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">-> Dashboard</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-md-12">

            <div class="row">
                <div class="col-lg-8 col-md-12">
                    <div class="slick-js">
                    <?php
                        $parkings = Parking::getAllParkingsList();
                        foreach ($parkings as $value) {
                    ?>
                        <div>
                            <div style="background-image: url('images/mall.jpg');" class="card bg-primary-gradient border-0">
                                <div class="card-body text-center">
                                    <figure class="avatar mb-3 border-0">
                                        <span class="avatar-title bg-white text-primary rounded-circle">
                                            <i class="fa fa-parking"></i>
                                        </span>
                                        
                                    </figure>
                                    <?php
                                        $curl = curl_init("http://192.168.1.177/");
                                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
                                        $result = curl_exec($curl);
                                        $result = json_decode( $result, true);
                                        //print_r( $result );
                                        $result = $result["Place"];
                                        //print $result["Place"];

                                    
                                    echo "<h2 class='font-weight-bold mb-3'>$result/ $value->parkingCapacity</h2>"
                                    ?>
                                    <h5 class="mb-0"><? echo $value->parkingName?></h5>
                                </div>
                            </div>
                        </div>
                        <?php
                            }
                        ?>
                        <!-- <div>
                            <div class="card bg-secondary-gradient border-0">
                                <div class="card-body text-center">
                                    <figure class="avatar mb-3 border-0">
                                        <span class="avatar-title bg-white text-secondary rounded-circle">
                                            <i class="ti-shopping-cart"></i>
                                        </span>
                                    </figure>
                                    <h2 class="font-weight-bold mb-3">562</h2>
                                    <h5 class="mb-0">Orders</h5>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="card  bg-warning-gradient border-0">
                                <div class="card-body text-center">
                                    <figure class="avatar mb-3 border-0">
                                        <span class="avatar-title bg-white text-warning rounded-circle">
                                            <i class="ti-package"></i>
                                        </span>
                                    </figure>
                                    <h2 class="font-weight-bold mb-3">82</h2>
                                    <h5 class="mb-0">Products</h5>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="card bg-info-gradient border-0">
                                <div class="card-body text-center">
                                    <figure class="avatar mb-3 border-0">
                                        <span class="avatar-title bg-white text-info rounded-circle">
                                            <i class="ti-user"></i>
                                        </span>
                                    </figure>
                                    <h2 class="font-weight-bold mb-3">1.482</h2>
                                    <h5 class="mb-0">Customers</h5>
                                </div>
                            </div>
                        </div> -->
                        <!-- <div>
                            <div class="card bg-dark-gradient border-0">
                                <div class="card-body text-center">
                                    <figure class="avatar mb-3 border-0">
                                        <span class="avatar-title bg-white text-dark rounded-circle">
                                            <i class="ti-exchange-vertical"></i>
                                        </span>
                                    </figure>
                                    <h2 class="font-weight-bold mb-3">10/120</h2>
                                    <h5 class="mb-0">Average bill</h5>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="card bg-danger-gradient border-0">
                                <div class="card-body text-center">
                                    <figure class="avatar mb-3 border-0">
                                        <span class="avatar-title bg-white text-danger rounded-circle">
                                            <i class="ti-back-left"></i>
                                        </span>
                                    </figure>
                                    <h2 class="font-weight-bold mb-3">1.482</h2>
                                    <h5 class="mb-0">Return</h5>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h6 class="card-title">Number of Orders</h6>
                                <div>
                                    <a href="#" class="mr-3">
                                        <i class="fa fa-refresh"></i>
                                    </a>
                                    <div class="dropdown">
                                        <a href="#" data-toggle="dropdown" aria-haspopup="true"
                                           aria-expanded="false">
                                            <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                        </a>
                                        <span class="dropdown-menu dropdown-menu-right">
                                                    <a href="#" class="dropdown-item">Report</a>
                                                    <a href="#" class="dropdown-item">Download</a>
                                                    <a href="#" class="dropdown-item">Close</a>
                                                </span>
                                    </div>
                                </div>
                            </div>
                            <div id="number-of-orders"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <!-- <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h6 class="card-title">Download Reports</h6>
                                <div class="dropdown">
                                    <a href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                    </a>
                                    <span class="dropdown-menu dropdown-menu-right">
                                        <a class="dropdown-item" href="#">Action</a>
                                        <a class="dropdown-item" href="#">Another action</a>
                                        <a class="dropdown-item" href="#">Something else here</a>
                                    </span>
                                </div>
                            </div>
                            <div class="text-center">
                                <p>Download all the data on this dashboard. First, choose a date range.</p>
                                <div class="row">
                                    <div class="col-md-10 offset-md-1">
                                        <div class="form-group">
                                            <input type="text" name="daterangepicker" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <button class="btn btn-primary">
                                    <i class="mr-2" data-feather="download"></i> Download PDF
                                </button>
                            </div>
                        </div>
                    </div> -->
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <h6 class="card-title mb-0">Last Users</h6>
                                <a href="#" class="small">Date</a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-striped mb-0">
                                <?php
                                    $users = User::getLast10Users();
                                    foreach ($users as $value) {
                                ?>
                                    <tr>
                                        <td>
                                            <a href="#"><? echo $value->userName?></a>
                                        </td>
                                        <td style="float: right;"><? echo $value->userCreate?></td>
                                    </tr>
                                    <?php
                                    }
                                ?>
                                    <!-- <tr>
                                        <td>
                                            <a href="#">Samsung Galaxy A30 3/32GB blue</a>
                                        </td>
                                        <td>52</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <a href="#">Samsung Galaxy Note9 6/128GB</a>
                                        </td>
                                        <td>74</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <a href="#">Apple iPhone XR 256GB red</a>
                                        </td>
                                        <td>25</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <a href="#">Samsung Galaxy A30 3/32GB blue</a>
                                        </td>
                                        <td>11</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <a href="#">Apple iPhone XS Max 256GB gold</a>
                                        </td>
                                        <td>52</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <a href="#">ASUS Asus ROG Phone 8/128GB blue</a>
                                        </td>
                                        <td>29</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <a href="#">Apple iPhone XR 256GB Green</a>
                                        </td>
                                        <td>5</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <a href="#">Samsung Galaxy Note9 6/128GB</a>
                                        </td>
                                        <td>74</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <a href="#">Apple iPhone XR 256GB red</a>
                                        </td>
                                        <td>25</td>
                                    </tr -->
                                    
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-13">
                    <div class="row">
                    <?php
                            $parkings = Parking::getAAllParkingsList();
                            foreach ($parkings as $value) {
                                ?>
                        <div class="col-md-6">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <h6 class="card-title mb-2"><? echo $value->parkingName?></h6>
                                        <h2 class="mb-0 font-weight-bold">0</h2>
                                    </div>
                                    <div class="d-flex align-items-center mt-2">
                                        <div class="progress flex-grow-1" style="height: 5px">
                                            <div class="progress-bar bg-primary" role="progressbar"
                                                 style="width: 62%;"
                                                 aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                        <div class="ml-2"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php
                            }
                        ?>
                        
                    </div>
                </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="card-title">Recent Reservations</h6>
                        <div>
                            <a href="#" class="mr-3">
                                <i class="fa fa-refresh"></i>
                            </a>
                            <!-- <div class="dropdown">
                                <a href="#" data-toggle="dropdown" aria-haspopup="true"
                                   aria-expanded="false">
                                    <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item" href="#">Action</a>
                                    <a class="dropdown-item" href="#">Another action</a>
                                    <a class="dropdown-item" href="#">Something else here</a>
                                </div>
                            </div> -->
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive">
                                <table class="table table-striped mb-0">
                                    <thead>
                                    <tr>
                                        <th class="text-left">RESERVATION ID</th>
                                        <th>User Name</th>
                                        <th>Parking Name</th>
                                        <!-- <th>Country</th> -->
                                        <th>Departure Time</th>
                                        <th>Arrival Time</th>
                                        <th>Car Number</th>
                                        <th>Status</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                        $reservations = Reservation::getLast10Reservations();
                                        foreach ($reservations as $value) {
                                    ?>
                                    <tr>
                                        <td>
                                            <a href="#">#<? echo $value->reservationId?></a>
                                        </td>
                                        <td>
                                            <a href="#"><? echo $value->userName?></a>
                                        </td>
                                        <td>
                                            <a href="#"><? echo $value->parkingName?></a>
                                        </td>
                                        <!-- <td>
                                            <img title="Italy" width="30"
                                                 src="../../assets/media/image/flags/011-italy.png"
                                                 alt="...">
                                        </td> -->
                                        <td><? echo $value->departureTime?></td>
                                        <td><? echo $value->arrivalTime?></td>
                                        <td><? echo $value->carNumber?></td>
                                        <td>
                                        <?php
                                        if($value->reservationStatus == "1"){    
                                            echo "<span class='badge badge-success'>Success</span>";
                                        }
                                        if($value->reservationStatus == "0"){    
                                            echo "<span class='badge badge-warning'>Pending</span>";
                                        }
                                        ?>
                                        </td>
                                        <td class="text-right">
                                            <div class="dropdown">
                                                <a href="#" data-toggle="dropdown">
                                                    <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a href="#" class="dropdown-item">Detail</a>
                                                    <a href="#" class="dropdown-item text-danger">Remove</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php
                                    }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h6 class="card-title">Hot Products</h6>
                                <div>
                                    <a href="#" class="mr-3">
                                        <i class="fa fa-refresh"></i>
                                    </a>
                                    <span class="dropdown">
                                        <a href="#" data-toggle="dropdown" aria-haspopup="true"
                                           aria-expanded="false">
                                            <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                        </a>
                                        <span class="dropdown-menu dropdown-menu-right">
                                            <a href="#" class="dropdown-item">Report</a>
                                            <a href="#" class="dropdown-item">Download</a>
                                            <a href="#" class="dropdown-item">Close</a>
                                        </span>
                                    </span>
                                </div>
                            </div>
                            <canvas id="hot-products"></canvas>
                            <div id="hot-products-legends"></div>
                        </div>
                    </div>
                </div> -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <h6 class="card-title">Revenue</h6>
                                <div>
                                    <a href="#" class="mr-3">
                                        <i class="fa fa-refresh"></i>
                                    </a>
                                    <span class="dropdown">
                                                <a href="#" data-toggle="dropdown" aria-haspopup="true"
                                                   aria-expanded="false">
                                                    <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                                </a>
                                                <span class="dropdown-menu dropdown-menu-right">
                                                    <a href="#" class="dropdown-item">Report</a>
                                                    <a href="#" class="dropdown-item">Download</a>
                                                    <a href="#" class="dropdown-item">Close</a>
                                                </span>
                                            </span>
                                </div>
                            </div>
                            <div id="revenue"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div style="padding-bottom: 80px;" class="row">
                <!-- <div class="col-lg-8 col-md-12" style="max-width: 50.000%;">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title d-flex justify-content-between">
                                <h6 class="card-title">Project Tasks</h6>
                                <div>
                                    <a href="#" class="mr-3">
                                        <i class="fa fa-refresh"></i>
                                    </a>
                                    <span class="dropdown">
                                        <a href="#" data-toggle="dropdown" aria-haspopup="true"
                                           aria-expanded="false">
                                            <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                        </a>
                                        <span class="dropdown-menu dropdown-menu-right">
                                            <a href="#" class="dropdown-item">Action</a>
                                            <a href="#" class="dropdown-item">Another action</a>
                                            <a href="#" class="dropdown-item">Something else here</a>
                                        </span>
                                    </span>
                                </div>
                            </div>
                            <div id="project-tasks"></div>
                        </div>
                    </div>
                </div> -->
                

            </div>
            
        </div>
    </div>


    <!-- begin::footer -->
    <footer>
        <div class="container-fluid">
            <div>© 2021 Parkfinder  </div>
            <div>
                <nav class="nav">
                    <a href="#" class="nav-link">Licenses</a>
                    <a href="#" class="nav-link">Change Log</a>
                    <a href="#" class="nav-link">Get Help</a>
                </nav>
            </div>
        </div>
    </footer>
    <!-- end::footer -->

    </div>
    <!-- end::main-content -->

</div>
<!-- end::main -->

<!-- Plugin scripts -->
<script src="js/bundle.js"></script>


    <!-- Slick -->
    <script src="js/slick.min.js"></script>

    <!-- Chartjs -->
    <script src="js/chart.min.js"></script>

    <!-- Apex chart -->
    <script src="js/irregular-data-series.js"></script>
    <script src="js/apexcharts.min.js"></script>

    <!-- Daterangepicker -->
    <script src="js/daterangepicker.js"></script>

    <!-- DataTable -->
    <script src="js/datatables.min.js"></script>

    <!-- Dashboard scripts -->
    <script src="js/dashboard.js"></script>

    <!-- To use theme colors with Javascript -->
    <div class="colors">
        <div class="bg-primary"></div>
        <div class="bg-primary-bright"></div>
        <div class="bg-secondary"></div>
        <div class="bg-secondary-bright"></div>
        <div class="bg-info"></div>
        <div class="bg-info-bright"></div>
        <div class="bg-success"></div>
        <div class="bg-success-bright"></div>
        <div class="bg-danger"></div>
        <div class="bg-danger-bright"></div>
        <div class="bg-warning"></div>
        <div class="bg-warning-bright"></div>
    </div>

    <script>
        $(function () {
            $('.slick-js').slick({
                speed: 500,
                arrows: false,
                slidesToShow: 3,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
                responsive: [
                    {
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 3
                        }
                    },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: 2
                        }
                    },
                    {
                        breakpoint: 500,
                        settings: {
                            slidesToShow: 1
                        }
                    }
                ]
            });

            $('input[name="daterangepicker"]').daterangepicker({
                opens: 'left'
            });

            $('.dataTable').DataTable({
                lengthMenu: [5, 10],
                "columnDefs": [ {
                    "targets": 7,
                    "orderable": false
                } ]
            });
        })
    </script>


<!-- App scripts -->
<script src="js/app.min.js"></script>

</body>

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:28 GMT -->
</html>
