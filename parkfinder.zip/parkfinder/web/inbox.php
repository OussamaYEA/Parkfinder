<?php
require_once 'Models/Admin.php';
require_once 'Models/Message.php';
?>
<!doctype html>
<html lang="en">

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/apps-inbox.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:30 GMT -->
<head>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="https://realitycheckinc.com/wp-content/themes/themify-ultra/themify/themify-icons/themify-icons.css" rel="stylesheet" type="text/css" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Parkfinder - Mail</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="image/favicon1.png"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="css/bundle.css" type="text/css">

    
    <!-- quill -->
    <link href="css/quill.snow.css" rel="stylesheet" type="text/css">

    <!-- Tagsinput -->
    <link rel="stylesheet" href="../../vendors/tagsinput/bootstrap-tagsinput.php" type="text/css">


    <!-- App styles -->
    <link rel="stylesheet" href="css/app.min.css" type="text/css">
</head>
<body  class="stretch-layout small-navigation dark">

<!-- begin::preloader-->
<!-- <div class="preloader">
    <div class="preloader-icon"></div>
</div> -->
<!-- end::preloader -->

<?php
    include_once 'includes/header.php';
?>

    <!--<div class="horizontal-navigation">
            <ul>
                <li>
                    <a  href="#">
                        <i class="nav-icon" data-feather="bar-chart-2"></i> Dashboards
                    </a>
                    <ul>
                        <li>
                            <a  href="dashboards-one.php">Ecommerce</a></li>
                        <li>
                            <a  href="dashboards-two.php">Analytics</a></li>
                        <li>
                            <a  href="dashboards-three.php">Projects</a></li>
                        <li>
                            <a  href="dashboards-widget.php">Widgets</a></li>
                    </ul>
                </li>
                <li>
                    <a  class="active"  href="#">
                        <i class="nav-icon" data-feather="command"></i> Apps  <span class="badge badge-danger">New</span>
                    </a>
                    <ul>
                        <li>
                            <a  href="apps-chat.php">
                                <span>Chat</span>
                                <span class="badge badge-danger">5</span>
                            </a>
                        </li>
                        <li>
                            <a  class="active"
                                href="apps-inbox.php">
                                <span>Mail</span>
                            </a>
                        </li>
                        <li>
                            <a  href="apps-todo.php">
                                <span>Todo</span>
                                <span class="badge badge-warning">2</span>
                            </a>
                        </li>
                        <li>
                            <a  href="apps-file-manager.php">
                                <span>File Manager</span>
                            </a>
                        </li>
                        <li>
                            <a  href="apps-calendar.php">
                                <span>Calendar</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">
                        <i class="nav-icon" data-feather="layers"></i> UI Elements
                    </a>
                    <ul>
                        <li>
                            <a href="#">Basic</a>
                            <ul>
                                <li>
                                    <a  href="elements-basic-alert.php">Alerts</a></li>
                                <li>
                                    <a  href="elements-basic-accordion.php">Accordion</a></li>
                                <li>
                                    <a  href="elements-basic-buttons.php">Buttons</a></li>
                                <li>
                                    <a  href="elements-basic-dropdown.php">Dropdown</a></li>
                                <li>
                                    <a  href="elements-basic-list-group.php">List Group</a></li>
                                <li>
                                    <a  href="elements-basic-pagination.php">Pagination</a></li>
                                <li>
                                    <a  href="elements-basic-typography.php">Typography</a></li>
                                <li>
                                    <a  href="elements-basic-media-object.php">Media Object</a></li>
                                <li>
                                    <a  href="elements-basic-progress.php">Progress</a></li>
                                <li>
                                    <a  href="elements-basic-modal.php">Modal</a></li>
                                <li>
                                    <a  href="elements-basic-spinners.php">Spinners</a></li>
                                <li>
                                    <a  href="elements-basic-navs.php">Navs</a></li>
                                <li>
                                    <a  href="elements-basic-tab.php">Tab</a></li>
                                <li>
                                    <a  href="elements-basic-tooltip.php">Tooltip</a></li>
                                <li>
                                    <a  href="elements-basic-popovers.php">Popovers</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Cards</a>
                            <ul>
                                <li>
                                    <a  href="elements-card-basic.php">Basic Cards </a></li>
                                <li>
                                    <a  href="elements-card-image.php">Image Cards </a></li>
                                <li>
                                    <a  href="elements-card-scroll.php">Card Scroll </a></li>
                                <li>
                                    <a  href="elements-card-other.php">Others </a></li>
                            </ul>
                        </li>
                        <li>
                            <a  href="elements-avatar.php">Avatar</a></li>
                        <li>
                            <a  href="elements-icons.php">Icons</a></li>
                        <li>
                            <a  href="elements-colors.php">Colors</a></li>
                        <li>
                            <a href="#">Plugins</a>
                            <ul>
                                <li>
                                    <a  href="elements-plugin-sweet-alert.php">Sweet Alert</a></li>
                                <li>
                                    <a  href="elements-plugin-lightbox.php">Lightbox</a></li>
                                <li>
                                    <a  href="elements-plugin-toast.php">Toast</a></li>
                                <li>
                                    <a  href="elements-plugin-tour.php">Tour</a></li>
                                <li>
                                    <a  href="elements-plugin-slick-slide.php">Slick Slide</a></li>
                                <li>
                                    <a  href="elements-plugin-nestable.php">Nestable</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Forms</a>
                            <ul>
                                <li>
                                    <a  href="elements-form-basic.php">Form Layouts</a></li>
                                <li>
                                    <a  href="elements-form-custom.php">Custom Forms</a></li>
                                <li>
                                    <a  href="elements-form-advanced.php">Advanced Form</a></li>
                                <li>
                                    <a  href="elements-form-validation.php">Validation</a></li>
                                <li>
                                    <a  href="elements-form-wizard.php">Wizard</a></li>
                                <li>
                                    <a  href="elements-form-file-upload.php">File Upload</a></li>
                                <li>
                                    <a  href="elements-form-datepicker.php">Datepicker</a></li>
                                <li>
                                    <a  href="elements-form-timepicker.php">Timepicker</a></li>
                                <li>
                                    <a  href="elements-form-colorpicker.php">Colorpicker</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Tables</a>
                            <ul>
                                <li>
                                    <a  href="elements-table-basic.php">Basic Tables</a></li>
                                <li>
                                    <a  href="elements-table-datatable.php">Datatable</a></li>
                                <li>
                                    <a  href="elements-table-responsive.php">Responsive Tables</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Charts</a>
                            <ul>
                                <li>
                                    <a  href="elements-chart-apexchart.php">Apex</a></li>
                                <li>
                                    <a  href="elements-chart-chartjs.php">Chartjs</a></li>
                                <li>
                                    <a  href="elements-chart-justgage.php">Justgage</a></li>
                                <li>
                                    <a  href="elements-chart-morsis.php">Morsis</a></li>
                                <li>
                                    <a  href="elements-chart-peity.php">Peity</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Maps</a>
                            <ul>
                                <li>
                                    <a  href="elements-map-google.php">Google</a></li>
                                <li>
                                    <a  href="elements-map-vector.php">Vector</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">
                        <i class="nav-icon" data-feather="copy"></i> Pages
                    </a>
                    <ul>
                        <li><a href="pages-login.php" target="_blank">Login</a></li>
                        <li><a href="pages-register.php" target="_blank">Register</a></li>
                        <li><a href="pages-recovery-password.php" target="_blank">Recovery Password</a></li>
                        <li><a href="pages-lock-screen.php" target="_blank">Lock Screen</a></li>
                        <li>
                            <a  href="pages-profile.php">Profile</a></li>
                        <li>
                            <a  href="pages-timeline.php">Timeline</a></li>
                        <li>
                            <a  href="pages-invoice.php">Invoice</a></li>

                        <li>
                            <a  href="pages-pricing-table.php">Pricing Table</a></li>

                        <li>
                            <a  href="pages-pricing-table.php-2">Pricing Table 2</a></li>
                        <li>
                            <a  href="pages-search-result.php">Search Result</a></li>
                        <li>
                            <a  href="pages-mailing.php">Mailing</a></li>
                        <li>
                            <a href="#">Error Pages</a>
                            <ul>
                                <li><a href="pages-errors-404.php" target="_blank">404</a></li>
                                <li><a href="pages-errors-503.php" target="_blank">503</a></li>
                                <li><a href="pages-errors-mean-at-work.php" target="_blank">Mean at Work</a></li>
                            </ul>
                        </li>
                        <li>
                            <a  href="pages-blank-page-1.php">Starter Pages</a>
                            <ul>
                                <li>
                                    <a  href="pages-blank-page-1.php">Layout 1</a></li>
                                <li>
                                    <a  href="pages-blank-page-2.php">Layout 2</a></li>
                                <li>
                                    <a  href="pages-blank-page-3.php">Layout 3</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Menu Level</a>
                            <ul>
                                <li>
                                    <a href="#">Menu Level</a>
                                    <ul>
                                        <li>
                                            <a href="#">Menu Level </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ul>
        </div> -->

    <!-- begin::main-content -->
    <div class="main-content">

    
    <div class="row app-block">
        <div class="col-md-3 app-sidebar">
            <div class="card">
                <div class="card-body">
                    <button class="btn btn-secondary btn-block" data-toggle="modal" data-target="">
                        Mail Box
                    </button>
                </div>
                <div class="app-sidebar-menu">
                    <div class="list-group list-group-flush">
                        <a href="#" class="list-group-item active d-flex align-items-center">
                            <i data-feather="mail" class="mr-2 width-15 height-15"></i>
                            Inbox
                            <span class="small ml-auto">14</span>
                        </a>
                        <!-- <a href="#" class="list-group-item">
                            <i data-feather="send" class="mr-2 width-15 height-15"></i>
                            Send
                        </a>
                        <a href="#" class="list-group-item">
                            <i data-feather="edit-3" class="mr-2 width-15 height-15"></i>
                            Draft
                        </a>
                        <a href="#" class="list-group-item d-flex align-items-center">
                            <i data-feather="star" class="mr-2 width-15 height-15"></i>
                            Starred
                            <span class="small ml-auto">10</span>
                        </a>
                        
                        <a href="#" class="list-group-item d-flex align-items-center">
                            <i data-feather="trash" class="mr-2 width-15 height-15"></i>
                            Trash
                            <span class="small ml-auto">2</span>
                        </a> -->
                    </div>
                    
                </div>
            </div>
        </div>
        <div class="col-md-9 app-content">
            <div class="app-content-overlay"></div>
            <!-- <div class="app-action">
                <div class="action-left">
                    <div class="custom-control custom-checkbox mr-3">
                        <input type="checkbox" class="custom-control-input" id="customCheckAll">
                        <label class="custom-control-label" for="customCheckAll"></label>
                    </div>
                    <ul class="list-inline">
                        <li class="list-inline-item mb-0">
                            <a href="#" class="btn btn-outline-light dropdown-toggle" data-toggle="dropdown">
                                With selected
                            </a>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">Mark as read</a>
                                <a class="dropdown-item" href="#">Mark as unread</a>
                                <a class="dropdown-item" href="#">Spam</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item text-danger" href="#">Delete</a>
                            </div>
                        </li>
                        <li class="list-inline-item mb-0">
                            <a href="#" class="btn btn-outline-light dropdown-toggle" data-toggle="dropdown">
                                Order by
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item" href="#">Date</a>
                                <a class="dropdown-item" href="#">From</a>
                                <a class="dropdown-item" href="#">Subject</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#">Size</a>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="action-right">
                    <form class="d-flex mr-3">
                        <a href="#" class="app-sidebar-menu-button btn btn-outline-light">
                            <i data-feather="menu" class="width-15 height-15"></i>
                        </a>
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Email search"
                                   aria-describedby="button-addon1">
                            <div class="input-group-append">
                                <button class="btn btn-outline-light" type="button" id="button-addon1">
                                    <i class="ti-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                    <div class="app-pager d-flex align-items-center">
                        <div class="mr-3">1-50 of 253</div>
                        <nav aria-label="Page navigation example">
                            <ul class="pagination">
                                <li class="page-item">
                                    <a class="page-link" href="#" aria-label="Previous">
                                        <i data-feather="chevron-left" class="width-15 height-15"></i>
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#" aria-label="Next">
                                        <i data-feather="chevron-right" class="width-15 height-15"></i>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div> -->
            <div class="card card-body app-content-body">
                <div class="app-lists">
                    <ul class="list-group list-group-flush">
                    <?php
                            $messages = Message::getAllMessagesList();
                            foreach ($messages as $value) {
                                ?>
                        <li class="list-group-item">
                            <div>
                                <div class="custom-control custom-checkbox mr-2">
                                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                                    <label class="custom-control-label" for="customCheck1"></label>
                                </div>
                            </div>
                            <div>
                                <!-- <a href="#" class="add-star mr-3" title="Add stars">
                                    <i class="fa fa-star-o font-size-16"></i>
                                </a> -->
                            </div>
                            <div>
                                <figure class="avatar avatar-sm mr-3">
                                    <img src="<? echo $value->userPhoto?>" class="rounded-circle" alt="image">
                                </figure>
                            </div>
                            <div class="flex-grow-1 min-width-0">
                                <div class="mb-1 d-flex justify-content-between align-items-center">
                                    <div class="text-truncate app-list-title"><? echo $value->userName?></div>
                                    <div class="pl-3 d-flex">
                                        <span class="text-nowrap text-muted"><? echo $value->messageCreate?></span>
                                        <div class="dropdown ml-3">
                                            <a href="#" class="btn btn-outline-light btn-sm" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <!-- <a class="dropdown-item" href="#">Reply</a>
                                                <a class="dropdown-item" href="#">Add star</a>
                                                <a class="dropdown-item" href="#">Add label</a> -->
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item text-danger" href="#">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-muted d-flex justify-content-between">
                                    <div class="text-truncate small"><? echo $value->messageCategory?></div>
                                    <div class="text-nowrap pl-3">
                                        <ul class="list-inline">
                                            <li class="list-inline-item mb-0">
                                            <a href="inbox-message.php?message=message&id=<?php echo $value->messageId?>" class="btn btn-primary">Read</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <?php
                            }
                        ?>
                        <!-- <li class="list-group-item active">
                            <div>
                                <div class="custom-control custom-checkbox mr-2">
                                    <input type="checkbox" class="custom-control-input" checked id="customCheck2">
                                    <label class="custom-control-label" for="customCheck2"></label>
                                </div>
                            </div>
                            <div>
                                <a href="#" class="add-star mr-3" title="Add stars">
                                    <i class="fa fa-star font-size-16 text-warning"></i>
                                </a>
                            </div>
                            <div>
                                <figure class="avatar avatar-sm mr-3">
                                    <span class="avatar-title bg-info-bright text-info rounded-circle">Z</span>
                                </figure>
                            </div>
                            <div class="flex-grow-1 min-width-0">
                                <div class="mb-1 d-flex justify-content-between align-items-center">
                                    <div class="text-truncate app-list-title">Ecommerce website Paypal integration 😃</div>
                                    <div class="pl-3 d-flex">
                                        <span class="text-nowrap text-muted">15 July</span>
                                        <div class="dropdown ml-3">
                                            <a href="#" class="btn btn-outline-light btn-sm" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="#">Reply</a>
                                                <a class="dropdown-item" href="#">Add star</a>
                                                <a class="dropdown-item" href="#">Add label</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item text-danger" href="#">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-muted d-flex justify-content-between">
                                    <div class="text-truncate small">Lorem ipsum dolor sit amet, consectetur adipisicing elit.</div>
                                    <div class="text-nowrap pl-3">
                                        <ul class="list-inline">
                                            <li class="list-inline-item mb-0">
                                                <a href="#" data-toggle="tooltip" title="Attachment">
                                                    <i class="fa fa-paperclip"></i>
                                                </a>
                                            </li>
                                            <li class="list-inline-item mb-0">
                                                <i class="fa fa-circle text-success"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div>
                                <div class="custom-control custom-checkbox mr-2">
                                    <input type="checkbox" class="custom-control-input" id="customCheck3">
                                    <label class="custom-control-label" for="customCheck3"></label>
                                </div>
                            </div>
                            <div>
                                <a href="#" class="add-star mr-3" title="Add stars">
                                    <i class="fa fa-star-o font-size-16"></i>
                                </a>
                            </div>
                            <div>
                                <figure class="avatar avatar-sm mr-3">
                                    <span class="avatar-title bg-danger-bright text-danger rounded-circle">S</span>
                                </figure>
                            </div>
                            <div class="flex-grow-1 min-width-0">
                                <div class="mb-1 d-flex justify-content-between align-items-center">
                                    <div class="text-truncate app-list-title">Randy, me (5)</div>
                                    <div class="pl-3 d-flex">
                                        <span class="text-nowrap text-muted">15 July</span>
                                        <div class="dropdown ml-3">
                                            <a href="#" class="btn btn-outline-light btn-sm" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="#">Reply</a>
                                                <a class="dropdown-item" href="#">Add star</a>
                                                <a class="dropdown-item" href="#">Add label</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item text-danger" href="#">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-muted d-flex justify-content-between">
                                    <div class="text-truncate small">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis cumque dicta eligendi, in quasi recusandae.</div>
                                    <div class="text-nowrap pl-3">
                                        <ul class="list-inline">
                                            <li class="list-inline-item mb-0">
                                                <a href="#" data-toggle="tooltip" title="Attachment">
                                                    <i class="fa fa-paperclip"></i>
                                                </a>
                                            </li>
                                            <li class="list-inline-item mb-0">
                                                <i class="fa fa-circle text-info"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div>
                                <div class="custom-control custom-checkbox mr-2">
                                    <input type="checkbox" class="custom-control-input" id="customCheck4">
                                    <label class="custom-control-label" for="customCheck4"></label>
                                </div>
                            </div>
                            <div>
                                <a href="#" class="add-star mr-3" title="Add stars">
                                    <i class="fa fa-star-o font-size-16"></i>
                                </a>
                            </div>
                            <div>
                                <figure class="avatar avatar-sm mr-3">
                                    <img src="image/user/women_avatar3.jpg" class="rounded-circle" alt="image">
                                </figure>
                            </div>
                            <div class="flex-grow-1 min-width-0">
                                <div class="mb-1 d-flex justify-content-between align-items-center">
                                    <div class="text-truncate app-list-title">Andrew Zimmer ❤❤</div>
                                    <div class="pl-3 d-flex">
                                        <span class="text-nowrap text-muted">15 July</span>
                                        <div class="dropdown ml-3">
                                            <a href="#" class="btn btn-outline-light btn-sm" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="#">Reply</a>
                                                <a class="dropdown-item" href="#">Add star</a>
                                                <a class="dropdown-item" href="#">Add label</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item text-danger" href="#">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-muted d-flex justify-content-between">
                                    <div class="text-truncate small">Lorem ipsum dolor sit amet.</div>
                                    <div class="text-nowrap pl-3">
                                        <ul class="list-inline">
                                            <li class="list-inline-item mb-0">
                                                <i class="fa fa-circle text-secondary"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div>
                                <div class="custom-control custom-checkbox mr-2">
                                    <input type="checkbox" class="custom-control-input" id="customCheck5">
                                    <label class="custom-control-label" for="customCheck5"></label>
                                </div>
                            </div>
                            <div>
                                <a href="#" class="add-star mr-3" title="Add stars">
                                    <i class="fa fa-star font-size-16 text-warning"></i>
                                </a>
                            </div>
                            <div>
                                <figure class="avatar avatar-sm mr-3">
                                    <span class="avatar-title bg-info-bright text-info rounded-circle">Z</span>
                                </figure>
                            </div>
                            <div class="flex-grow-1 min-width-0">
                                <div class="mb-1 d-flex justify-content-between align-items-center">
                                    <div class="text-truncate app-list-title">Charukaw, me (7)</div>
                                    <div class="pl-3 d-flex">
                                        <span class="text-nowrap text-muted">15 July</span>
                                        <div class="dropdown ml-3">
                                            <a href="#" class="btn btn-outline-light btn-sm" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="#">Reply</a>
                                                <a class="dropdown-item" href="#">Add star</a>
                                                <a class="dropdown-item" href="#">Add label</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item text-danger" href="#">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-muted d-flex justify-content-between">
                                    <div class="text-truncate small">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Asperiores esse et hic nesciunt quas ratione rem reprehenderit similique temporibus totam!</div>
                                    <div class="text-nowrap pl-3">
                                        <ul class="list-inline">
                                            <li class="list-inline-item mb-0">
                                                <i class="fa fa-circle text-primary"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div>
                                <div class="custom-control custom-checkbox mr-2">
                                    <input type="checkbox" class="custom-control-input" id="customCheck6">
                                    <label class="custom-control-label" for="customCheck6"></label>
                                </div>
                            </div>
                            <div>
                                <a href="#" class="add-star mr-3" title="Add stars">
                                    <i class="fa fa-star-o font-size-16"></i>
                                </a>
                            </div>
                            <div>
                                <figure class="avatar avatar-sm mr-3">
                                    <span class="avatar-title bg-danger-bright text-danger rounded-circle">S</span>
                                </figure>
                            </div>
                            <div class="flex-grow-1 min-width-0">
                                <div class="mb-1 d-flex justify-content-between align-items-center">
                                    <div class="text-truncate app-list-title">Stack Exchange</div>
                                    <div class="pl-3 d-flex">
                                        <span class="text-nowrap text-muted">15 July</span>
                                        <div class="dropdown ml-3">
                                            <a href="#" class="btn btn-outline-light btn-sm" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="#">Reply</a>
                                                <a class="dropdown-item" href="#">Add star</a>
                                                <a class="dropdown-item" href="#">Add label</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item text-danger" href="#">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-muted d-flex justify-content-between">
                                    <div class="text-truncate small">Lorem ipsum dolor sit amet.</div>
                                    <div class="text-nowrap pl-3">
                                        <ul class="list-inline">
                                            <li class="list-inline-item mb-0">
                                                <i class="fa fa-circle text-warning"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div>
                                <div class="custom-control custom-checkbox mr-2">
                                    <input type="checkbox" class="custom-control-input" id="customCheck7">
                                    <label class="custom-control-label" for="customCheck7"></label>
                                </div>
                            </div>
                            <div>
                                <a href="#" class="add-star mr-3" title="Add stars">
                                    <i class="fa fa-star-o font-size-16"></i>
                                </a>
                            </div>
                            <div>
                                <figure class="avatar avatar-sm mr-3">
                                    <span class="avatar-title bg-success-bright text-success rounded-circle">K</span>
                                </figure>
                            </div>
                            <div class="flex-grow-1 min-width-0">
                                <div class="mb-1 d-flex justify-content-between align-items-center">
                                    <div class="text-truncate app-list-title">Facebook register completed 👍</div>
                                    <div class="pl-3 d-flex">
                                        <span class="text-nowrap text-muted">15 July</span>
                                        <div class="dropdown ml-3">
                                            <a href="#" class="btn btn-outline-light btn-sm" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="#">Reply</a>
                                                <a class="dropdown-item" href="#">Add star</a>
                                                <a class="dropdown-item" href="#">Add label</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item text-danger" href="#">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-muted d-flex justify-content-between">
                                    <div class="text-truncate small">Hey John, Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda, esse.
                                    </div>
                                    <div class="text-nowrap pl-3">
                                        <ul class="list-inline">
                                            <li class="list-inline-item mb-0">
                                                <i class="fa fa-circle text-success"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div>
                                <div class="custom-control custom-checkbox mr-2">
                                    <input type="checkbox" class="custom-control-input" id="customCheck8">
                                    <label class="custom-control-label" for="customCheck8"></label>
                                </div>
                            </div>
                            <div>
                                <a href="#" class="add-star mr-3" title="Add stars">
                                    <i class="fa fa-star font-size-16 text-warning"></i>
                                </a>
                            </div>
                            <div>
                                <figure class="avatar avatar-sm mr-3">
                                    <span class="avatar-title bg-info-bright text-info rounded-circle">Z</span>
                                </figure>
                            </div>
                            <div class="flex-grow-1 min-width-0">
                                <div class="mb-1 d-flex justify-content-between align-items-center">
                                    <div class="text-truncate app-list-title">Peter, me (3)</div>
                                    <div class="pl-3 d-flex">
                                        <span class="text-nowrap text-muted">15 July</span>
                                        <div class="dropdown ml-3">
                                            <a href="#" class="btn btn-outline-light btn-sm" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="#">Reply</a>
                                                <a class="dropdown-item" href="#">Add star</a>
                                                <a class="dropdown-item" href="#">Add label</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item text-danger" href="#">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-muted d-flex justify-content-between">
                                    <div class="text-truncate small">Assumenda cupiditate dolor earum est illo labore nesciunt officia provident quis tempora?</div>
                                    <div class="text-nowrap pl-3">
                                        <ul class="list-inline">
                                            <li class="list-inline-item mb-0">
                                                <a href="#" data-toggle="tooltip" title="Attachment">
                                                    <i class="fa fa-paperclip"></i>
                                                </a>
                                            </li>
                                            <li class="list-inline-item mb-0">
                                                <i class="fa fa-circle text-info"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item">
                            <div>
                                <div class="custom-control custom-checkbox mr-2">
                                    <input type="checkbox" class="custom-control-input" id="customCheck9">
                                    <label class="custom-control-label" for="customCheck9"></label>
                                </div>
                            </div>
                            <div>
                                <a href="#" class="add-star mr-3" title="Add stars">
                                    <i class="fa fa-star-o font-size-16"></i>
                                </a>
                            </div>
                            <div>
                                <figure class="avatar avatar-sm mr-3">
                                    <span class="avatar-title bg-danger-bright text-danger rounded-circle">S</span>
                                </figure>
                            </div>
                            <div class="flex-grow-1 min-width-0">
                                <div class="mb-1 d-flex justify-content-between align-items-center">
                                    <div class="text-truncate app-list-title">How To Set Intentions That Energize You</div>
                                    <div class="pl-3 d-flex">
                                        <span class="text-nowrap text-muted">15 July</span>
                                        <div class="dropdown ml-3">
                                            <a href="#" class="btn btn-outline-light btn-sm" data-toggle="dropdown">
                                                <i class="fa fa-ellipsis-v"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <a class="dropdown-item" href="#">Reply</a>
                                                <a class="dropdown-item" href="#">Add star</a>
                                                <a class="dropdown-item" href="#">Add label</a>
                                                <div class="dropdown-divider"></div>
                                                <a class="dropdown-item text-danger" href="#">Delete</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="text-muted d-flex justify-content-between">
                                    <div class="text-truncate small">Hey John, bah kivu decrete epanorthotic
                                        unnotched
                                        Argyroneta nonius veratrine preimaginary.
                                    </div>
                                    <div class="text-nowrap pl-3">
                                        <ul class="list-inline">
                                            <li class="list-inline-item mb-0">
                                                <i class="fa fa-circle text-danger"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </li> -->
                    </ul>
                </div>
                <!-- end::app-lists -->

                <!-- begin:app-detail -->
                
            </div>
        </div>
    </div>

    <div class="modal fade" tabindex="-1" role="dialog" id="compose">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Compose Email</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="ti-close"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="d-flex justify-content-between m-b-20">
                        <div>
                            <a href="#" data-toggle="tooltip" title=""
                               class="btn btn-outline-light btn-sm mr-2"
                               data-original-title="Keep">
                                <i data-feather="save"></i>
                            </a>
                            <a href="#" data-toggle="tooltip" title=""
                               class="btn btn-outline-light btn-sm mr-2"
                               data-original-title="Delete">
                                <i data-feather="trash-2"></i>
                            </a>
                        </div>
                    </div>
                    <form>
                        <div class="form-group">
                            <input type="text" class="form-control tagsinput" placeholder="To">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Subject" required>
                        </div>
                        <div class="form-group">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" multiple id="customFileLangHTML">
                                <label class="custom-file-label" for="customFileLangHTML" data-browse="Select files">Add Document</label>
                            </div>
                        </div>
                        <div>
                            <div class="compose-quill-editor mb-3"></div>
                            <div class="d-flex justify-content-between">
                                <div class="compose-quill-toolbar">
                            <span class="ql-formats mr-0">
                                <button class="ql-bold"></button>
                                <button class="ql-italic"></button>
                                <button class="ql-underline"></button>
                                <button class="ql-link"></button>
                                <button class="ql-image"></button>
                            </span>
                                </div>
                                <button class="btn btn-primary">
                                    <i data-feather="send" class="mr-2"></i>
                                    Send
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- begin::footer -->
    <footer>
        <div class="container-fluid">
            <div>© 2021 Parkfinder  </div>
            <div>
                <nav class="nav">
                    <a href="#" class="nav-link">Licenses</a>
                    <a href="#" class="nav-link">Change Log</a>
                    <a href="#" class="nav-link">Get Help</a>
                </nav>
            </div>
        </div>
    </footer>
    <!-- end::footer -->

    </div>
    <!-- end::main-content -->

</div>
<!-- end::main -->

<!-- Plugin scripts -->
<script src="js/bundle.js"></script>


    <!-- Tagsinput -->
    <script src="js/bootstrap-tagsinput.js"></script>
    <script src="js/tagsinput.js"></script>

    <!-- quill -->
    <script src="js/quill.js"></script>

    <script>
        new Quill('.compose-quill-editor', {
            modules: {
                toolbar: ".compose-quill-toolbar"
            },
            placeholder: "Type something... ",
            theme: "snow"
        });

        new Quill('.reply-email-quill-editor', {
            modules: {
                toolbar: ".reply-email-quill-toolbar"
            },
            placeholder: "Type something... ",
            theme: "snow"
        });

        $(function () {
            $(document).on('click', '.app-block .app-content .app-action .action-left input[type="checkbox"]', function () {
                $('.app-lists ul li input[type="checkbox"]').prop('checked', $(this).prop('checked'));
                if ($(this).prop('checked')) {
                    $('.app-lists ul li input[type="checkbox"]').closest('li').addClass('active');
                } else {
                    $('.app-lists ul li input[type="checkbox"]').closest('li').removeClass('active');
                }
            });

            $(document).on('click', '.app-lists ul li input[type="checkbox"]', function () {
                if ($(this).prop('checked')) {
                    $(this).closest('li').addClass('active');
                } else {
                    $(this).closest('li').removeClass('active');
                }
            });

            $(document).on('click', '.app-block .app-content .app-content-body .app-lists ul.list-group li.list-group-item', function (e) {
                if (!$(e.target).is('.custom-control, .custom-control *, a, a *')) {
                    $('.app-detail').addClass('show').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function () {
                        $('.app-block .app-content .app-content-body .app-detail .app-detail-article').niceScroll().resize();
                    });
                }
            });

            $(document).on('click', 'a.app-detail-close-button', function () {
                $('.app-detail').removeClass('show');
                return false;
            });

            $(document).on('click', '.app-sidebar-menu-button', function () {
                $('.app-block .app-sidebar, .app-content-overlay').addClass('show');
                // $('.app-block .app-sidebar .app-sidebar-menu').niceScroll().resize();
                return false;
            });

            $(document).on('click', '.app-content-overlay', function () {
                $('.app-block .app-sidebar, .app-content-overlay').removeClass('show');
                return false;
            });
        });
    </script>


<!-- App scripts -->
<script src="js/app.min.js"></script>

</body>

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/apps-inbox.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:32 GMT -->
</html>
