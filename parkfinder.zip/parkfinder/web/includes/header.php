
<?php
    session_start();
    $admin = $_SESSION["currentAdmin"];
    if(!isset($_SESSION['currentAdmin'])){
        header("Location:index.php");
    }
    require_once './Models/Admin.php';
    if($admin->adminStatus == "0"){
        header("Location:index.php?error=You Have been blocked please contact support ");
    }
?>
<head>
    <link rel="shortcut icon" href="image/favicon1.png"/>
</head>
<!-- begin::header -->
<div class="header">

    <div class="header-left">
        <div class="navigation-toggler">
            <a href="#" data-action="navigation-toggler">
                <i data-feather="menu"></i>
            </a>
        </div>
        <div class="header-logo">
            <a href=home.php>
                <img class="logo" src="image/Fichier 3.png" alt="logo">
                <img class="logo-light" src="image/Fichier 3.png"style="width: 134px; alt="light logo">
            </a>
        </div>
    </div>

    <div class="header-body">
        <div class="header-body-left">
            <div class="page-title">
                <!-- <h4>E-commerce</h4> -->
            </div>
        </div>
        <div class="header-body-right">
            <ul class="navbar-nav">

                <!-- <li class="nav-item">
                    <a href="#" class="nav-link" data-toggle="dropdown">
                        <img width="18" src="image/flags/262-united-kingdom.png" alt="flag"
                             class="mr-2 rounded" title="United Kingdom"> EN
                    </a>
                    <div class="dropdown-menu">
                        <a href="#" class="dropdown-item">
                            <img width="18" src="image/flags/003-tanzania.png"
                                 class="mr-2 rounded"
                                 alt="flag">
                            Tanzania
                        </a>
                        <a href="#" class="dropdown-item">
                            <img width="18" src="image/flags/261-china.png"
                                 class="mr-2 rounded"
                                 alt="flag"> China
                        </a>
                        <a href="#" class="dropdown-item">
                            <img width="18" src="image/flags/013-tunisia.png"
                                 class="mr-2 rounded"
                                 alt="flag">
                            Tunisia
                        </a>
                        <a href="#" class="dropdown-item">
                            <img width="18" src="image/flags/044-spain.png"
                                 class="mr-2 rounded"
                                 alt="flag"> Spain
                        </a>
                    </div>
                </li> -->

                <!-- begin::header fullscreen -->
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link" title="Fullscreen" data-toggle="fullscreen">
                        <i class="maximize" data-feather="maximize"></i>
                        <i class="minimize" data-feather="minimize"></i>
                    </a>
                </li>
                <!-- end::header fullscreen -->

                <!-- begin::header search -->
                <!-- <li class="nav-item">
                    <a href="#" class="nav-link" title="Search" data-toggle="dropdown">
                        <i data-feather="search"></i>
                    </a>
                    <div class="dropdown-menu p-2 dropdown-menu-right">
                        <form>
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search">
                                <div class="input-group-prepend">
                                    <button class="btn" type="button">
                                        <i data-feather="search"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </li> -->
                <!-- end::header search -->

                <!-- begin::apps -->
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link" title="Apps" data-toggle="dropdown">
                        <i data-feather="box"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-big">
                        <div class="bg-dark p-4 text-center d-flex justify-content-between">
                            <h5 class="mb-0">Apps</h5>
                        </div>
                        <div class="p-3">
                            <div class="row row-xs">
                                <div class="col-6">
                                    <a href="inbox.php">
                                        <div class="border-radius-1 text-center mb-3">
                                            <figure class="avatar avatar-lg border-0">
                                                <span class="avatar-title bg-secondary text-white rounded-circle">
                                                    <i class="width-30 height-30" data-feather="mail"></i>
                                                </span>
                                            </figure>
                                            <div class="mt-2">Mail</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-6">
                                    <a href="Home.php">
                                        <div class="border-radius-1 text-center mb-3">
                                            <figure class="avatar avatar-lg border-0">
                                                <span class="avatar-title bg-secondary text-white rounded-circle">
                                                    <i class="width-30 height-30" data-feather="mail"></i>
                                                </span>
                                            </figure>
                                            <div class="mt-2">Dashboard</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-6">
                                    <a href="parking.php">
                                        <div class="border-radius-1 text-center">
                                            <figure class="avatar avatar-lg border-0">
                                                <span class="avatar-title bg-info text-white rounded-circle">
                                                    <i class="width-30 height-30" data-feather="check-circle"></i>
                                                </span>
                                            </figure>
                                            <div class="mt-2">Parking Manager</div>
                                        </div>
                                    </a>
                                </div>
                                <div class="col-6">
                                    <a href="reservation.php">
                                        <div class="border-radius-1 text-center">
                                            <figure class="avatar avatar-lg border-0">
                                                <span class="avatar-title bg-warning text-white rounded-circle">
                                                    <i class="width-30 height-30" data-feather="file"></i>
                                                </span>
                                            </figure>
                                            <div class="mt-2">Reservation Manager</div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <!-- end::apps -->

                <!-- begin::header messages dropdown -->
                <li class="nav-item dropdown">
                    <!-- <a href="#" class="nav-link nav-link-notify" title="Chats" data-toggle="dropdown">
                        <i data-feather="message-circle"></i>
                    </a> -->
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-big">
                        <div class="bg-dark p-4 text-center d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Chats</h5>
                            <small class="font-size-11 opacity-7">2 unread chats</small>
                        </div>
                        <div>
                            <ul class="list-group list-group-flush">
                                <li>
                                    <a href="#" class="list-group-item d-flex align-items-center hide-show-toggler">
                                        <div>
                                            <figure class="avatar mr-2">
                                                <img src="image/user/man_avatar1.jpg"
                                                     class="rounded-circle" alt="user">
                                            </figure>
                                        </div>
                                        <div class="flex-grow-1">
                                            <p class="mb-0 line-height-20 d-flex justify-content-between">
                                                Herbie Pallatina
                                                <i title="Mark as read" data-toggle="tooltip"
                                                   class="hide-show-toggler-item fa fa-circle-o font-size-11"></i>
                                            </p>
                                            <div class="small text-muted">
                                                <span class="mr-2">02:30 PM</span>
                                                <span>Have you madimage</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#"
                                       class="list-group-item d-flex align-items-center hide-show-toggler">
                                        <div>
                                            <figure class="avatar mr-2">
                                                <img src="image/user/women_avatar5.jpg"
                                                     class="rounded-circle" alt="user">
                                            </figure>
                                        </div>
                                        <div class="flex-grow-1">
                                            <p class="mb-0 line-height-20 d-flex justify-content-between">
                                                Andrei Miners
                                                <i title="Mark as read" data-toggle="tooltip"
                                                   class="hide-show-toggler-item fa fa-circle-o font-size-11"></i>
                                            </p>
                                            <div class="small text-muted">
                                                <span class="mr-2">08:36 PM</span>
                                                <span>I have a meetinimage</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li class="text-divider small pb-2 pl-3 pt-3">
                                    <span>Old chats</span>
                                </li>
                                <li>
                                    <a href="#"
                                       class="list-group-item d-flex align-items-center hide-show-toggler">
                                        <div>
                                            <figure class="avatar mr-2">
                                                <img src="image/user/man_avatar3.jpg"
                                                     class="rounded-circle" alt="user">
                                            </figure>
                                        </div>
                                        <div class="flex-grow-1">
                                            <p class="mb-0 line-height-20 d-flex justify-content-between">
                                                Kevin added
                                                <i title="Mark as unread" data-toggle="tooltip"
                                                   class="hide-show-toggler-item fa fa-check font-size-11"></i>
                                            </p>
                                            <div class="small text-muted">
                                                <span class="mr-2">11:09 PM</span>
                                                <span>Have you madimage</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="list-group-item d-flex align-items-center hide-show-toggler">
                                        <div>
                                            <figure class="avatar mr-2">
                                                <img src="image/user/man_avatar2.jpg"
                                                     class="rounded-circle" alt="user">
                                            </figure>
                                        </div>
                                        <div class="flex-grow-1">
                                            <p class="mb-0 line-height-20 d-flex justify-content-between">
                                                Eugenio Carnelley
                                                <i title="Mark as unread" data-toggle="tooltip"
                                                   class="hide-show-toggler-item fa fa-check font-size-11"></i>
                                            </p>
                                            <div class="small text-muted">
                                                <span class="mr-2">Yesterday</span>
                                                <span>I have a meetinimage</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="#"
                                       class="list-group-item d-flex align-items-center hide-show-toggler">
                                        <div>
                                            <figure class="avatar mr-2">
                                                <img src="image/user/women_avatar1.jpg"
                                                     class="rounded-circle" alt="user">
                                            </figure>
                                        </div>
                                        <div class="flex-grow-1">
                                            <p class="mb-0 line-height-20 d-flex justify-content-between">
                                                Neely Ferdinand
                                                <i title="Mark as unread" data-toggle="tooltip"
                                                   class="hide-show-toggler-item fa fa-check font-size-11"></i>
                                            </p>
                                            <div class="small text-muted">
                                                <span class="mr-2">Yesterday</span>
                                                <span>I have a meetinimage</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="p-2 text-right border-top">
                            <ul class="list-inline small">
                                <li class="list-inline-item mb-0">
                                    <a href="#">Mark All Read</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
                <!-- end::header messages dropdown -->

                <!-- begin::header notification dropdown -->
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link nav-link-notify" title="Notifications" data-toggle="dropdown">
                        <i data-feather="bell"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-big">
                        <div class="bg-dark p-4 text-center d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Notifications</h5>
                            <small class="font-size-11 opacity-7">1 unread notifications</small>
                        </div>
                        <div>
                            <ul class="list-group list-group-flush">
                                <li>
                                    <a href="#" class="list-group-item d-flex align-items-center hide-show-toggler">
                                        <div>
                                            <figure class="avatar mr-2">
                                                <span
                                                    class="avatar-title bg-success-bright text-success rounded-circle">
                                                    <i class="ti-user"></i>
                                                </span>
                                            </figure>
                                        </div>
                                        <div class="flex-grow-1">
                                            <p class="mb-0 line-height-20 d-flex justify-content-between">
                                                New User registered
                                                <i title="Mark as read" data-toggle="tooltip"
                                                   class="hide-show-toggler-item fa fa-circle-o font-size-11"></i>
                                            </p>
                                            <span class="text-muted small">20 min ago</span>
                                        </div>
                                    </a>
                                </li>
                                <li class="text-divider small pb-2 pl-3 pt-3">
                                    <span>Old notifications</span>
                                </li>
                                <li>
                                    <a href="#" class="list-group-item d-flex align-items-center hide-show-toggler">
                                        <div>
                                            <figure class="avatar mr-2">
                                                <span
                                                    class="avatar-title bg-warning-bright text-warning rounded-circle">
                                                    <i class="ti-package"></i>
                                                </span>
                                            </figure>
                                        </div>
                                        <div class="flex-grow-1">
                                            <p class="mb-0 line-height-20 d-flex justify-content-between">
                                                New Reservation
                                                <i title="Mark as unread" data-toggle="tooltip"
                                                   class="hide-show-toggler-item fa fa-check font-size-11"></i>
                                            </p>
                                            <span class="text-muted small">45 sec ago</span>
                                        </div>
                                    </a>
                                </li>
                                
                            </ul>
                        </div>
                        <div class="p-2 text-right border-top">
                            <ul class="list-inline small">
                                <li class="list-inline-item mb-0">
                                    <a href="#">Mark All Read</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>
                <!-- end::header notification dropdown -->

                <!-- begin::settings -->
                <!-- <li class="nav-item dropdown">
                    <a href="#" class="nav-link" title="Settings" data-toggle="dropdown">
                        <i data-feather="settings"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-big">
                        <div class="bg-dark p-4 text-center d-flex justify-content-between">
                            <h5 class="mb-0">Settings</h5>
                        </div>
                        <div>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch1" checked>
                                        <label class="custom-control-label" for="customSwitch1">Allow
                                            notifications.</label>
                                    </div>
                                </li>
                                <li class="list-group-item">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch2">
                                        <label class="custom-control-label" for="customSwitch2">Hide user
                                            requests</label>
                                    </div>
                                </li>
                                <li class="list-group-item">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch3" checked>
                                        <label class="custom-control-label" for="customSwitch3">Speed up demands</label>
                                    </div>
                                </li>
                                <li class="list-group-item">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch4" checked>
                                        <label class="custom-control-label" for="customSwitch4">Hide menus</label>
                                    </div>
                                </li>
                                <li class="list-group-item">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch5">
                                        <label class="custom-control-label" for="customSwitch5">Remember next
                                            visits</label>
                                    </div>
                                </li>
                                <li class="list-group-item">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="customSwitch6">
                                        <label class="custom-control-label" for="customSwitch6">Enable report
                                            generation.</label>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li> -->
                <!-- end::settings -->

                <!-- begin::user menu -->
                
                <li class="nav-item dropdown">
                    <a href="#" class="nav-link" title="User menu" data-toggle="dropdown" aria-expanded="false">
                        <span class="mr-2 d-sm-inline d-none"><?echo $admin->adminName ?></span>
                        <figure class="avatar avatar-sm">
                            <img src="image/user/user.png" class="rounded-circle"
                                 alt="avatar">
                        </figure>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a href="profile.php" class="dropdown-item">Profile</a>
                        <!-- <a href="#" class="dropdown-item d-flex">
                            Followers <span class="text-muted ml-auto">214</span>
                        </a>
                        <a href="#" class="dropdown-item d-flex">
                            Inbox <span class="text-muted ml-auto">18</span>
                        </a>
                        <a href="#" class="dropdown-item" data-sidebar-target="#settings">Billing</a>
                        <a href="#" class="dropdown-item" data-sidebar-target="#settings">Need help?</a> -->
                        <a href="logout.php" class="dropdown-item text-danger" data-sidebar-target="#settings">Sign Out!</a>
                    </div>
                </li>
                <!-- end::user menu -->

            </ul>

            <!-- begin::mobile header toggler -->
            <ul class="navbar-nav d-flex align-items-center">
                <li class="nav-item header-toggler">
                    <a href="#" class="nav-link">
                        <i data-feather="arrow-down"></i>
                    </a>
                </li>
            </ul>
            <!-- end::mobile header toggler -->
        </div>
    </div>

</div>
<!-- end::header -->

<!-- begin::main -->
<div id="main">

    <!-- begin::navigation -->
    <div class="navigation">
        <div class="navigation-menu-tab">
            <div class="flex-grow-1">
                <ul>
                    <li>
                        <a  class="active"
                            href="#" data-toggle="tooltip" data-placement="right" title="Dashboards"
                           data-nav-target="#dashboards">
                            <i data-feather="bar-chart-2"></i>
                        </a>
                    </li>
                    
                    <li>
                        <a  href="#" data-toggle="tooltip"
                           data-placement="right" title="Apps" data-nav-target="#apps">
                            <i data-feather="command"></i>
                            
                        </a>
                    </li>
                    <!-- <li>
                        <a  href="#" data-toggle="tooltip"
                           data-placement="right" title="UI Elements"
                           data-nav-target="#elements">
                            <i data-feather="layers"></i>
                        </a>
                    </li> -->
                    <!-- <li>
                        <a  href="#" data-toggle="tooltip"
                           data-placement="right" title="Pages" data-nav-target="#pages">
                            <i data-feather="copy"></i>
                        </a>
                    </li> -->
                </ul>
            </div>
            <div>
                <ul>
                    <!-- <li>
                        <a href="#" data-toggle="tooltip" data-placement="right" title="Dark mode">
                            <i data-feather="moon"></i>
                        </a>
                    </li> -->
                    <li>
                        <a href="logout.php" data-toggle="tooltip" data-placement="right" title="Logout"
                            target="">
                            <i data-feather="log-out"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="navigation-menu-body">
            <div class="navigation-menu-group">

                <div  class="open"
                      id="dashboards">
                    <ul>
                        <li class="navigation-divider">Dashboards</li>
                        <li>
                            <a  class=""
                                href="Home.php">Dashboard</a></li>
                        <li>
                            <a  href="dashboards-two.php">Analytics</a></li>
                        <li>
                            <!-- <a  href="dashboards-three.php">Projects</a></li> -->
                        
                            <a href="#" class="d-flex align-items-start">
                                <!-------------------- DELETED ---------------------------->
                        </li>
                    </ul>
                </div>
                <div  id="apps">
                    <ul>
                        <li class="navigation-divider">Web Apps</li>
                        <li>
                            <a  href="inbox.php">
                                <span>Mail</span>
                            </a>
                        </li>
                        <?php
                        
                        if($admin->adminSup == "1")
                        
                        echo "<li><a class=''href='parking.php'><span>Parkings</span></a></li>";
                        ?>
                        <li>
                            <a  class=""
                                href="reservation.php">
                                <span>Reservations</span>
                                
                            </a>
                        </li>
                        <li><a  class="" href="users.php"><span>Users</span></a></li>
                        
                        
                        <?php
                        
                        if($admin->adminSup == "1")
                        
                        echo "<li><a class=''href='admin.php'><span>Admins</span></a></li>";
                        ?>
                        <!-- <li>
                            <a  href="apps-chat.php">
                                <span>Chat</span>
                                <span class="badge badge-danger">5</span>
                            </a>
                        </li>
                        
                        <li>
                            <a  href="apps-todo.php">
                                <span>Todo</span>
                                <span class="badge badge-warning">2</span>
                            </a>
                        </li>
                        <li>
                            <a  href="apps-file-manager.php">
                                <span>File Manager</span>
                            </a>
                        </li>
                        <li>
                            <a  href="apps-calendar.php">
                                <span>Calendar</span>
                            </a>
                        </li>
                        <li class="navigation-divider">Recent Contacts</li>
                        <li> -->
                            <!-- <div class="list-group list-group-flush">
                                <a href="#" class="list-group-item d-flex align-items-center">
                                    <div>
                                        <div class="avatar avatar-sm m-r-10">
                                            <img src="image/user/man_avatar1.jpg"
                                                 class="rounded-circle" alt="image">
                                        </div>
                                    </div>
                                    <span>Valentine Maton</span>
                                </a>
                                <a href="#" class="list-group-item d-flex align-items-center">
                                    <div>
                                        <div class="avatar avatar-sm m-r-10">
                                            <img src="image/user/women_avatar2.jpg"
                                                 class="rounded-circle" alt="image">
                                        </div>
                                    </div>
                                    <span>Holmes Cherryman</span>
                                </a>
                                <a href="#" class="list-group-item d-flex align-items-center">
                                    <div>
                                        <div class="avatar avatar-sm m-r-10">
                                            <img src="image/user/women_avatar4.jpg"
                                                 class="rounded-circle" alt="image">
                                        </div>
                                    </div>
                                    <span>Kenneth Hune</span>
                                </a>
                                <a href="#" class="list-group-item d-flex align-items-center">
                                    <div>
                                        <div class="avatar avatar-sm m-r-10">
                                            <img src="image/user/women_avatar3.jpg"
                                                 class="rounded-circle" alt="image">
                                        </div>
                                    </div>
                                    <span>Holmes Cherryman</span>
                                </a>
                                <a href="#" class="list-group-item d-flex align-items-center">
                                    <div>
                                        <div class="avatar avatar-sm m-r-10">
                                            <img src="image/user/women_avatar5.jpg"
                                                 class="rounded-circle" alt="image">
                                        </div>
                                    </div>
                                    <span>Kenneth Hune</span>
                                </a>
                            </div> -->
                        </li>
                    </ul>
                </div>
                <div  id="elements">
                    <ul>
                        <li class="navigation-divider">UI Elements</li>
                        <li>
                            <a href="#">Basic</a>
                            <ul>
                                <li>
                                    <a  href="elements-basic-alert.php">Alerts</a></li>
                                <li>
                                    <a  href="elements-basic-accordion.php">Accordion</a></li>
                                <li>
                                    <a  href="elements-basic-buttons.php">Buttons</a></li>
                                <li>
                                    <a  href="elements-basic-dropdown.php">Dropdown</a></li>
                                <li>
                                    <a  href="elements-basic-list-group.php">List Group</a></li>
                                <li>
                                    <a  href="elements-basic-pagination.php">Pagination</a></li>
                                <li>
                                    <a  href="elements-basic-typography.php">Typography</a></li>
                                <li>
                                    <a  href="elements-basic-media-object.php">Media Object</a></li>
                                <li>
                                    <a  href="elements-basic-progress.php">Progress</a></li>
                                <li>
                                    <a  href="elements-basic-modal.php">Modal</a></li>
                                <li>
                                    <a  href="elements-basic-spinners.php">Spinners</a></li>
                                <li>
                                    <a  href="elements-basic-navs.php">Navs</a></li>
                                <li>
                                    <a  href="elements-basic-tab.php">Tab</a></li>
                                <li>
                                    <a  href="elements-basic-tooltip.php">Tooltip</a></li>
                                <li>
                                    <a  href="elements-basic-popovers.php">Popovers</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Cards</a>
                            <ul>
                                <li>
                                    <a  href="elements-card-basic.php">Basic Cards </a></li>
                                <li>
                                    <a  href="elements-card-image.php">Image Cards </a></li>
                                <li>
                                    <a  href="elements-card-scroll.php">Card Scroll </a></li>
                                <li>
                                    <a  href="elements-card-other.php">Others </a></li>
                            </ul>
                        </li>
                        <li>
                            <a  href="elements-avatar.php">Avatar</a></li>
                        <li>
                            <a  href="elements-icons.php">Icons</a></li>
                        <li>
                            <a  href="elements-colors.php">Colors</a></li>
                        <li>
                            <a href="#">Plugins</a>
                            <ul>
                                <li>
                                    <a  href="elements-plugin-sweet-alert.php">Sweet Alert</a></li>
                                <li>
                                    <a  href="elements-plugin-lightbox.php">Lightbox</a></li>
                                <li>
                                    <a  href="elements-plugin-toast.php">Toast</a></li>
                                <li>
                                    <a  href="elements-plugin-tour.php">Tour</a></li>
                                <li>
                                    <a  href="elements-plugin-slick-slide.php">Slick Slide</a></li>
                                <li>
                                    <a  href="elements-plugin-nestable.php">Nestable</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Forms</a>
                            <ul>
                                <li>
                                    <a  href="elements-form-basic.php">Form Layouts</a></li>
                                <li>
                                    <a  href="elements-form-custom.php">Custom Forms</a></li>
                                <li>
                                    <a  href="elements-form-advanced.php">Advanced Form</a></li>
                                <li>
                                    <a  href="elements-form-validation.php">Validation</a></li>
                                <li>
                                    <a  href="elements-form-wizard.php">Wizard</a></li>
                                <li>
                                    <a  href="elements-form-file-upload.php">File Upload</a></li>
                                <li>
                                    <a  href="elements-form-datepicker.php">Datepicker</a></li>
                                <li>
                                    <a  href="elements-form-timepicker.php">Timepicker</a></li>
                                <li>
                                    <a  href="elements-form-colorpicker.php">Colorpicker</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Tables</a>
                            <ul>
                                <li>
                                    <a  href="elements-table-basic.php">Basic Tables</a></li>
                                <li>
                                    <a  href="elements-table-datatable.php">Datatable</a></li>
                                <li>
                                    <a  href="elements-table-responsive.php">Responsive Tables</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Charts</a>
                            <ul>
                                <li>
                                    <a  href="elements-chart-apexchart.php">Apex</a></li>
                                <li>
                                    <a  href="elements-chart-chartjs.php">Chartjs</a></li>
                                <li>
                                    <a  href="elements-chart-justgage.php">Justgage</a></li>
                                <li>
                                    <a  href="elements-chart-morsis.php">Morsis</a></li>
                                <li>
                                    <a  href="elements-chart-peity.php">Peity</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Maps</a>
                            <ul>
                                <li>
                                    <a  href="elements-map-google.php">Google</a></li>
                                <li>
                                    <a  href="elements-map-vector.php">Vector</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div  id="pages">
                    <ul>
                        <li class="navigation-divider">Pages</li>
                        <li><a href="pages-login.php" target="_blank">Login</a></li>
                        <li><a href="pages-register.php" target="_blank">Register</a></li>
                        <li><a href="pages-recovery-password.php" target="_blank">Recovery Password</a></li>
                        <li><a href="pages-lock-screen.php" target="_blank">Lock Screen</a></li>
                        <li>
                            <a  href="pages-profile.php">Profile</a></li>
                        <li>
                            <a  href="pages-timeline.php">Timeline</a></li>
                        <li>
                            <a  href="pages-invoice.php">Invoice</a></li>

                        <li>
                            <a  href="pages-pricing-table.php">Pricing Table</a></li>

                        <li>
                            <a  href="pages-pricing-table-2.php">Pricing Table 2</a></li>
                        <li>
                            <a  href="pages-search-result.php">Search Result</a></li>
                        <li>
                            <a  href="pages-mailing.php">Mailing</a></li>
                        <li>
                            <a href="#">Error Pages</a>
                            <ul>
                                <li><a href="pages-errors-404.php" target="_blank">404</a></li>
                                <li><a href="pages-errors-503.php" target="_blank">503</a></li>
                                <li><a href="pages-errors-mean-at-work.php" target="_blank">Mean at Work</a></li>
                            </ul>
                        </li>
                        <li>
                            <a  href="pages-blank-page-1.php">Starter Pages</a>
                            <ul>
                                <li>
                                    <a  href="pages-blank-page-1.php">Layout 1</a></li>
                                <li>
                                    <a  href="pages-blank-page-2.php">Layout 2</a></li>
                                <li>
                                    <a  href="pages-blank-page-3.php">Layout 3</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Menu Level</a>
                            <ul>
                                <li>
                                    <a href="#">Menu Level</a>
                                    <ul>
                                        <li>
                                            <a href="#">Menu Level </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- end::navigation -->