<?php
	if(isset($_SESSION['currentAdmin'])){
        header("Location:home.php?error=You are already logged in!!");
    }
?>
<!doctype html>
<html lang="en">

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/pages-login.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:34 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Parkfinder - Login</title>

    <link rel="stylesheet" href="css/material-icons.css">

    <!-- Favicon -->
    <link rel="shortcut icon" href="image/favicon1.png"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="css/bundle.css" type="text/css">

    <!-- App styles -->
    <link rel="stylesheet" href="css/app.min.css" type="text/css">
</head>
<body class="form-membership">

<!-- begin::preloader-->
<div class="preloader">
    <div class="preloader-icon"></div>
</div>
<!-- end::preloader -->

<div class="form-wrapper">

    
    <!-- logo -->
    <div id="logo">
        <img class="logo" src="image/Fichier 4.png" style="width: 128px;" alt="image">
        <img class="logo-dark" src="../../assets/media/image/logo-dark.php" alt="image">
    </div>
    <!-- ./ logo -->

    <h5>Log in</h5>

    <!-- form -->
    <form action="Controllers/login_controller.php" method="POST">
        <div class="form-group">
            <input name="email" type="email" class="form-control" placeholder="Email" required autofocus>
        </div>
        <div class="form-group">
            <input name="password" type="password" class="form-control" placeholder="Password" required>
        </div>
        <div class="form-group d-flex justify-content-between">
            <!-- <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" checked="" id="customCheck1">
                <label class="custom-control-label" for="customCheck1">Remember me</label>
            </div> -->
            
        </div>
        <?php
            $err = isset($_GET['error']) ?  $_GET['error'] : "";
        ?>
        <p style="color:orangered; font-size:28px;font-weight: bold;"><?= $err ?></p>
        <button type="submit" class="btn btn-primary btn-block">Log in</button>
        <hr>

    </form>
    <!-- ./ form -->


</div>

<!-- Plugin scripts -->
<script src="js/bundle.js"></script>

<!-- App scripts -->
<script src="js/app.min.js"></script>
</body>

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/pages-login.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:34 GMT -->
</html>
