

<?php
$to = "somebody@example.com";
$subject = "Email Validation";
$txt = "Hello world! <a href='http://localhost/hghjgjg?id='>Confirm</a>";
$headers = "From: webmaster@example.com" . "\r\n" .
"CC: somebodyelse@example.com";

mail($to,$subject,$txt,$headers);
?>