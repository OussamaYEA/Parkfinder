<?php
require_once 'Models/Admin.php';
require_once 'Models/Parking.php';
?>
<!doctype html>
<html lang="en">

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/apps-chat.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:30 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Parkfinder - Parking</title>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="https://realitycheckinc.com/wp-content/themes/themify-ultra/themify/themify-icons/themify-icons.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="css/allusers.css" type="text/css">
    <!-- Favicon -->
    <link rel="shortcut icon" href="image/favicon1.png"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="css/bundle.css" type="text/css">

    
    <!-- App styles -->
    <link rel="stylesheet" href="css/app.min.css" type="text/css">
    
</head>
<body  class="stretch-layout small-navigation dark">

<!-- begin::preloader-->
<!-- <div class="preloader">
    <div class="preloader-icon"></div>
</div> -->
<!-- end::preloader -->

<?php
    include_once 'includes/header.php';
?>

    <!--<div class="horizontal-navigation">
            <ul>
                <li>
                    <a  href="#">
                        <i class="nav-icon" data-feather="bar-chart-2"></i> Dashboards
                    </a>
                    <ul>
                        <li>
                            <a  href="dashboards-one.php">Ecommerce</a></li>
                        <li>
                            <a  href="dashboards-two.php">Analytics</a></li>
                        <li>
                            <a  href="dashboards-three.php">Projects</a></li>
                        <li>
                            <a  href="dashboards-widget.php">Widgets</a></li>
                    </ul>
                </li>
                <li>
                    <a  class="active"  href="#">
                        <i class="nav-icon" data-feather="command"></i> Apps  <span class="badge badge-danger">New</span>
                    </a>
                    <ul>
                        <li>
                            <a  class="active"
                                href="apps-chat.php">
                                <span>Chat</span>
                                <span class="badge badge-danger">5</span>
                            </a>
                        </li>
                        <li>
                            <a  href="inbox.php">
                                <span>Mail</span>
                            </a>
                        </li>
                        <li>
                            <a  href="apps-todo.php">
                                <span>Todo</span>
                                <span class="badge badge-warning">2</span>
                            </a>
                        </li>
                        <li>
                            <a  href="apps-file-manager.php">
                                <span>File Manager</span>
                            </a>
                        </li>
                        <li>
                            <a  href="apps-calendar.php">
                                <span>Calendar</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">
                        <i class="nav-icon" data-feather="layers"></i> UI Elements
                    </a>
                    <ul>
                        <li>
                            <a href="#">Basic</a>
                            <ul>
                                <li>
                                    <a  href="elements-basic-alert.php">Alerts</a></li>
                                <li>
                                    <a  href="elements-basic-accordion.php">Accordion</a></li>
                                <li>
                                    <a  href="elements-basic-buttons.php">Buttons</a></li>
                                <li>
                                    <a  href="elements-basic-dropdown.php">Dropdown</a></li>
                                <li>
                                    <a  href="elements-basic-list-group.php">List Group</a></li>
                                <li>
                                    <a  href="elements-basic-pagination.php">Pagination</a></li>
                                <li>
                                    <a  href="elements-basic-typography.php">Typography</a></li>
                                <li>
                                    <a  href="elements-basic-media-object.php">Media Object</a></li>
                                <li>
                                    <a  href="elements-basic-progress.php">Progress</a></li>
                                <li>
                                    <a  href="elements-basic-modal.php">Modal</a></li>
                                <li>
                                    <a  href="elements-basic-spinners.php">Spinners</a></li>
                                <li>
                                    <a  href="elements-basic-navs.php">Navs</a></li>
                                <li>
                                    <a  href="elements-basic-tab.php">Tab</a></li>
                                <li>
                                    <a  href="elements-basic-tooltip.php">Tooltip</a></li>
                                <li>
                                    <a  href="elements-basic-popovers.php">Popovers</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Cards</a>
                            <ul>
                                <li>
                                    <a  href="elements-card-basic.php">Basic Cards </a></li>
                                <li>
                                    <a  href="elements-card-image.php">Image Cards </a></li>
                                <li>
                                    <a  href="elements-card-scroll.php">Card Scroll </a></li>
                                <li>
                                    <a  href="elements-card-other.php">Others </a></li>
                            </ul>
                        </li>
                        <li>
                            <a  href="elements-avatar.php">Avatar</a></li>
                        <li>
                            <a  href="elements-icons.php">Icons</a></li>
                        <li>
                            <a  href="elements-colors.php">Colors</a></li>
                        <li>
                            <a href="#">Plugins</a>
                            <ul>
                                <li>
                                    <a  href="elements-plugin-sweet-alert.php">Sweet Alert</a></li>
                                <li>
                                    <a  href="elements-plugin-lightbox.php">Lightbox</a></li>
                                <li>
                                    <a  href="elements-plugin-toast.php">Toast</a></li>
                                <li>
                                    <a  href="elements-plugin-tour.php">Tour</a></li>
                                <li>
                                    <a  href="elements-plugin-slick-slide.php">Slick Slide</a></li>
                                <li>
                                    <a  href="elements-plugin-nestable.php">Nestable</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Forms</a>
                            <ul>
                                <li>
                                    <a  href="elements-form-basic.php">Form Layouts</a></li>
                                <li>
                                    <a  href="elements-form-custom.php">Custom Forms</a></li>
                                <li>
                                    <a  href="elements-form-advanced.php">Advanced Form</a></li>
                                <li>
                                    <a  href="elements-form-validation.php">Validation</a></li>
                                <li>
                                    <a  href="elements-form-wizard.php">Wizard</a></li>
                                <li>
                                    <a  href="elements-form-file-upload.php">File Upload</a></li>
                                <li>
                                    <a  href="elements-form-datepicker.php">Datepicker</a></li>
                                <li>
                                    <a  href="elements-form-timepicker.php">Timepicker</a></li>
                                <li>
                                    <a  href="elements-form-colorpicker.php">Colorpicker</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Tables</a>
                            <ul>
                                <li>
                                    <a  href="elements-table-basic.php">Basic Tables</a></li>
                                <li>
                                    <a  href="elements-table-datatable.php">Datatable</a></li>
                                <li>
                                    <a  href="elements-table-responsive.php">Responsive Tables</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Charts</a>
                            <ul>
                                <li>
                                    <a  href="elements-chart-apexchart.php">Apex</a></li>
                                <li>
                                    <a  href="elements-chart-chartjs.php">Chartjs</a></li>
                                <li>
                                    <a  href="elements-chart-justgage.php">Justgage</a></li>
                                <li>
                                    <a  href="elements-chart-morsis.php">Morsis</a></li>
                                <li>
                                    <a  href="elements-chart-peity.php">Peity</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Maps</a>
                            <ul>
                                <li>
                                    <a  href="elements-map-google.php">Google</a></li>
                                <li>
                                    <a  href="elements-map-vector.php">Vector</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">
                        <i class="nav-icon" data-feather="copy"></i> Pages
                    </a>
                    <ul>
                        <li><a href="pages-login.php" target="_blank">Login</a></li>
                        <li><a href="pages-register.php" target="_blank">Register</a></li>
                        <li><a href="pages-recovery-password.php" target="_blank">Recovery Password</a></li>
                        <li><a href="pages-lock-screen.php" target="_blank">Lock Screen</a></li>
                        <li>
                            <a  href="pages-profile.php">Profile</a></li>
                        <li>
                            <a  href="pages-timeline.php">Timeline</a></li>
                        <li>
                            <a  href="pages-invoice.php">Invoice</a></li>

                        <li>
                            <a  href="pages-pricing-table.php">Pricing Table</a></li>

                        <li>
                            <a  href="pages-pricing-table.php-2">Pricing Table 2</a></li>
                        <li>
                            <a  href="pages-search-result.php">Search Result</a></li>
                        <li>
                            <a  href="pages-mailing.php">Mailing</a></li>
                        <li>
                            <a href="#">Error Pages</a>
                            <ul>
                                <li><a href="pages-errors-404.php" target="_blank">404</a></li>
                                <li><a href="pages-errors-503.php" target="_blank">503</a></li>
                                <li><a href="pages-errors-mean-at-work.php" target="_blank">Mean at Work</a></li>
                            </ul>
                        </li>
                        <li>
                            <a  href="pages-blank-page-1.php">Starter Pages</a>
                            <ul>
                                <li>
                                    <a  href="pages-blank-page-1.php">Layout 1</a></li>
                                <li>
                                    <a  href="pages-blank-page-2.php">Layout 2</a></li>
                                <li>
                                    <a  href="pages-blank-page-3.php">Layout 3</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Menu Level</a>
                            <ul>
                                <li>
                                    <a href="#">Menu Level</a>
                                    <ul>
                                        <li>
                                            <a href="#">Menu Level </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ul>
        </div> -->

    <!-- begin::main-content -->
    <div class="main-content">
        <div class="col-md-12 text-center">
            <h1 style="text-align:center; color:white">Parking Manager</h1><br>
            <a href="addparking.php"><button class="btn btn-primary btn-block" style="width: 140px;">Add Parking</button></a>
        </div>
        
        <div class="card-body">
            <div class="d-flex justify-content-between">
                <h6 class="card-title"></h6>
                <div>
                    <a href="#" class="mr-3">
                        <i class="fa fa-refresh"></i>
                    </a>
                    <!-- <div class="dropdown">
                        <a href="#" data-toggle="dropdown" aria-haspopup="true"
                           aria-expanded="false">
                            <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="#">Action</a>
                            <a class="dropdown-item" href="#">Another action</a>
                            <a class="dropdown-item" href="#">Something else here</a>
                        </div>
                    </div> -->
                </div>
            </div>
            <!-- USER MANAGER -->
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-striped mb-0 dataTable">
                            <thead>
                            <tr>
                                <th class="text-left">Parking ID</th>
                                <th>Parking Name</th>
                                <th>Parking Description</th>
                                <th>GPS</th>
                                <th>Capacity</th>
                                <th>Creation Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                        <?php
                            $parkings = Parking::getAAllParkingsList();
                            foreach ($parkings as $value) {
                                ?>
                            <tr>
                                <td>
                                    <a href="#">#<? echo $value->parkingId?></a>
                                </td>
                                <td>
                                    <a href="#"><? echo $value->parkingName?></a>
                                </td>
                                <td>
                                    <a href="#"><? echo $value->parkingDescription?></a>
                                <!-- <img style="width: 100px;" src = "<?php echo $value->parkingPhoto?> " alt = "product image"> -->
                                    
                                </td>    
                                <td><? echo $value->parkingGps?></td>
                                <td><? echo $value->parkingCapacity?></td>
                                <td><? echo $value->parkingCreate?></td>
                                <td>
                                <?php
                                if($value->parkingStatus == "1"){    
                                    echo "<span class='badge badge-success'>Onlinc</span>";
                                }
                                //echo $Parking->parkingStatus;
                                if($value->parkingStatus == "0"){    
                                    echo "<span class='badge badge-danger'>Offline</span>";
                                }
                                ?>
                                </td>
                                <td>
                                    <a href="Controllers/parking_controller.php?blockId=<?php echo $value->parkingId?>" onclick="deleteTask('y')" name="blockId" type="submit" class="btn btn-danger">X</a>
                                    <a href="Controllers/parking_controller.php?unblockId=<?php echo $value->parkingId?>" onclick="deleteTask('y')" name="unblockId" type="submit" class="btn btn-success ml-2">V</a>
                                </td>
                                <td class="text-right">
                                    <div class="dropdown">
                                        <a href="#" data-toggle="dropdown">
                                            <i class="fa fa-ellipsis-v" aria-hidden="true"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-right">
                                            <a href="editparking.php?parking=parking&id=<?php echo $value->parkingId?>" class="dropdown-item">Edit</a>
                                            <a href="Controllers/parking_controller.php?deleteId=<?php echo $value->parkingId?>" class="dropdown-item text-danger">Delete</a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php
                            }
                        ?>
                            
                            
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script src="js/main.js"></script>
    </div>


    <!-- begin::footer -->
    <footer>
        <div class="container-fluid">
            <div>© 2021 Parkfinder  </div>
            <div>
                <nav class="nav">
                    <a href="#" class="nav-link">Licenses</a>
                    <a href="#" class="nav-link">Change Log</a>
                    <a href="#" class="nav-link">Get Help</a>
                </nav>
            </div>
        </div>
    </footer>
    <!-- end::footer -->

    </div>
    <!-- end::main-content -->

</div>
<!-- end::main -->

<!-- Plugin scripts -->
<script src="js/bundle.js"></script>


<!-- App scripts -->
<script src="js/app.min.js"></script>

</body>

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/apps-chat.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:30 GMT -->
</html>
