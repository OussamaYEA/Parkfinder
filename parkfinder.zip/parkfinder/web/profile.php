<?php
    require_once './Models/Admin.php';
    include_once 'includes/header.php';
    
?>
<!doctype html>
<html lang="en">

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/pages-profile.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:52 GMT -->
<head>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="https://realitycheckinc.com/wp-content/themes/themify-ultra/themify/themify-icons/themify-icons.css" rel="stylesheet" type="text/css" />
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Parkfinder - Profile</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="image/favicon1.png"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="css/bundle.css" type="text/css">

    
    <!-- App styles -->
    <link rel="stylesheet" href="css/app.min.css" type="text/css">
</head>
<body  class="stretch-layout small-navigation dark">

<!-- begin::preloader-->
<div class="preloader">
    <div class="preloader-icon"></div>
</div>
<!-- end::preloader -->



    <!--<div class="horizontal-navigation">
            <ul>
                <li>
                    <a  href="#">
                        <i class="nav-icon" data-feather="bar-chart-2"></i> Dashboards
                    </a>
                    <ul>
                        <li>
                            <a  href="dashboards-one.php">Ecommerce</a></li>
                        <li>
                            <a  href="dashboards-two.php">Analytics</a></li>
                        <li>
                            <a  href="dashboards-three.php">Projects</a></li>
                        <li>
                            <a  href="dashboards-widget.php">Widgets</a></li>
                    </ul>
                </li>
                <li>
                    <a  href="#">
                        <i class="nav-icon" data-feather="command"></i> Apps  <span class="badge badge-danger">New</span>
                    </a>
                    <ul>
                        <li>
                            <a  href="apps-chat.php">
                                <span>Chat</span>
                                <span class="badge badge-danger">5</span>
                            </a>
                        </li>
                        <li>
                            <a  href="inbox.php">
                                <span>Mail</span>
                            </a>
                        </li>
                        <li>
                            <a  href="apps-todo.php">
                                <span>Todo</span>
                                <span class="badge badge-warning">2</span>
                            </a>
                        </li>
                        <li>
                            <a  href="apps-file-manager.php">
                                <span>File Manager</span>
                            </a>
                        </li>
                        <li>
                            <a  href="apps-calendar.php">
                                <span>Calendar</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">
                        <i class="nav-icon" data-feather="layers"></i> UI Elements
                    </a>
                    <ul>
                        <li>
                            <a href="#">Basic</a>
                            <ul>
                                <li>
                                    <a  href="elements-basic-alert.php">Alerts</a></li>
                                <li>
                                    <a  href="elements-basic-accordion.php">Accordion</a></li>
                                <li>
                                    <a  href="elements-basic-buttons.php">Buttons</a></li>
                                <li>
                                    <a  href="elements-basic-dropdown.php">Dropdown</a></li>
                                <li>
                                    <a  href="elements-basic-list-group.php">List Group</a></li>
                                <li>
                                    <a  href="elements-basic-pagination.php">Pagination</a></li>
                                <li>
                                    <a  href="elements-basic-typography.php">Typography</a></li>
                                <li>
                                    <a  href="elements-basic-media-object.php">Media Object</a></li>
                                <li>
                                    <a  href="elements-basic-progress.php">Progress</a></li>
                                <li>
                                    <a  href="elements-basic-modal.php">Modal</a></li>
                                <li>
                                    <a  href="elements-basic-spinners.php">Spinners</a></li>
                                <li>
                                    <a  href="elements-basic-navs.php">Navs</a></li>
                                <li>
                                    <a  href="elements-basic-tab.php">Tab</a></li>
                                <li>
                                    <a  href="elements-basic-tooltip.php">Tooltip</a></li>
                                <li>
                                    <a  href="elements-basic-popovers.php">Popovers</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Cards</a>
                            <ul>
                                <li>
                                    <a  href="elements-card-basic.php">Basic Cards </a></li>
                                <li>
                                    <a  href="elements-card-image.php">Image Cards </a></li>
                                <li>
                                    <a  href="elements-card-scroll.php">Card Scroll </a></li>
                                <li>
                                    <a  href="elements-card-other.php">Others </a></li>
                            </ul>
                        </li>
                        <li>
                            <a  href="elements-avatar.php">Avatar</a></li>
                        <li>
                            <a  href="elements-icons.php">Icons</a></li>
                        <li>
                            <a  href="elements-colors.php">Colors</a></li>
                        <li>
                            <a href="#">Plugins</a>
                            <ul>
                                <li>
                                    <a  href="elements-plugin-sweet-alert.php">Sweet Alert</a></li>
                                <li>
                                    <a  href="elements-plugin-lightbox.php">Lightbox</a></li>
                                <li>
                                    <a  href="elements-plugin-toast.php">Toast</a></li>
                                <li>
                                    <a  href="elements-plugin-tour.php">Tour</a></li>
                                <li>
                                    <a  href="elements-plugin-slick-slide.php">Slick Slide</a></li>
                                <li>
                                    <a  href="elements-plugin-nestable.php">Nestable</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Forms</a>
                            <ul>
                                <li>
                                    <a  href="elements-form-basic.php">Form Layouts</a></li>
                                <li>
                                    <a  href="elements-form-custom.php">Custom Forms</a></li>
                                <li>
                                    <a  href="elements-form-advanced.php">Advanced Form</a></li>
                                <li>
                                    <a  href="elements-form-validation.php">Validation</a></li>
                                <li>
                                    <a  href="elements-form-wizard.php">Wizard</a></li>
                                <li>
                                    <a  href="elements-form-file-upload.php">File Upload</a></li>
                                <li>
                                    <a  href="elements-form-datepicker.php">Datepicker</a></li>
                                <li>
                                    <a  href="elements-form-timepicker.php">Timepicker</a></li>
                                <li>
                                    <a  href="elements-form-colorpicker.php">Colorpicker</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Tables</a>
                            <ul>
                                <li>
                                    <a  href="elements-table-basic.php">Basic Tables</a></li>
                                <li>
                                    <a  href="elements-table-datatable.php">Datatable</a></li>
                                <li>
                                    <a  href="elements-table-responsive.php">Responsive Tables</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Charts</a>
                            <ul>
                                <li>
                                    <a  href="elements-chart-apexchart.php">Apex</a></li>
                                <li>
                                    <a  href="elements-chart-chartjs.php">Chartjs</a></li>
                                <li>
                                    <a  href="elements-chart-justgage.php">Justgage</a></li>
                                <li>
                                    <a  href="elements-chart-morsis.php">Morsis</a></li>
                                <li>
                                    <a  href="elements-chart-peity.php">Peity</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Maps</a>
                            <ul>
                                <li>
                                    <a  href="elements-map-google.php">Google</a></li>
                                <li>
                                    <a  href="elements-map-vector.php">Vector</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">
                        <i class="nav-icon" data-feather="copy"></i> Pages
                    </a>
                    <ul>
                        <li><a href="pages-login.php" target="_blank">Login</a></li>
                        <li><a href="pages-register.php" target="_blank">Register</a></li>
                        <li><a href="pages-recovery-password.php" target="_blank">Recovery Password</a></li>
                        <li><a href="pages-lock-screen.php" target="_blank">Lock Screen</a></li>
                        <li>
                            <a  class="active"
                                href="pages-profile.php">Profile</a></li>
                        <li>
                            <a  href="pages-timeline.php">Timeline</a></li>
                        <li>
                            <a  href="pages-invoice.php">Invoice</a></li>

                        <li>
                            <a  href="pages-pricing-table.php">Pricing Table</a></li>

                        <li>
                            <a  href="pages-pricing-table.php-2">Pricing Table 2</a></li>
                        <li>
                            <a  href="pages-search-result.php">Search Result</a></li>
                        <li>
                            <a  href="pages-mailing.php">Mailing</a></li>
                        <li>
                            <a href="#">Error Pages</a>
                            <ul>
                                <li><a href="pages-errors-404.php" target="_blank">404</a></li>
                                <li><a href="pages-errors-503.php" target="_blank">503</a></li>
                                <li><a href="pages-errors-mean-at-work.php" target="_blank">Mean at Work</a></li>
                            </ul>
                        </li>
                        <li>
                            <a  href="pages-blank-page-1.php">Starter Pages</a>
                            <ul>
                                <li>
                                    <a  href="pages-blank-page-1.php">Layout 1</a></li>
                                <li>
                                    <a  href="pages-blank-page-2.php">Layout 2</a></li>
                                <li>
                                    <a  href="pages-blank-page-3.php">Layout 3</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">Menu Level</a>
                            <ul>
                                <li>
                                    <a href="#">Menu Level</a>
                                    <ul>
                                        <li>
                                            <a href="#">Menu Level </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ul>
        </div> -->

    <!-- begin::main-content -->
    <div class="main-content">

    
    <!-- <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Home</a>
            </li>
            <li class="breadcrumb-item">
                <a href="#">Pages</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">Profile</li>
        </ol>
    </nav> -->

    <div class="row">
        <div class="col-md-12">

            <div class="row">
                <div class="col-md-4">

                    <div class="card">
                        <img src="image/image1.jpg" class="card-img-top" alt="...">
                        <div class="card-body text-center m-t-70-minus">
                            <figure class="avatar avatar-xl m-b-20">
                                <img src="image/user/user.png" class="rounded-circle" alt="...">
                            </figure>
                            <h5><?echo $admin->adminName ?></h5>
                            <p class="text-muted">Admin</p>
                            <p></p>
                            
                        </div>
                        <hr class="m-0">
                        
                    </div>

                    

                    

                    

                </div>
                <div class="col-md-8">
                    

                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title d-flex justify-content-between align-items-center">
                                Information
                                
                            </h6>
                            <div class="row mb-2">
                                <div class="col-6 text-muted">Full name</div>
                                <div class="col-6"><?echo $admin->adminName ?></div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-6 text-muted">Email:</div>
                                <div class="col-6"><?echo $admin->adminEmail ?></div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-6 text-muted">CIN:</div>
                                <div style="text-transform:uppercase" class="col-6"><?echo $admin->adminCin ?></div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-6 text-muted">Role:</div>
                                <div class="col-6">Admin</div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-6 text-muted">City:</div>
                                <div class="col-6"><?echo $admin->adminCity ?></div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-6 text-muted">Phone:</div>
                                <div class="col-6"><?echo $admin->adminPhone ?></div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-6 text-muted">Gender:</div>
                                <div class="col-6"><?echo $admin->adminGender ?></div>
                            </div>
                            <div class="row mb-2">
                                <div class="col-6 text-muted">Birth:</div>
                                <div class="col-6"><?echo $admin->adminBirth ?></div>
                            </div>
                        </div>
                    </div>
                    

                </div>
            </div>

        </div>
    </div>


    <!-- begin::footer -->
    <footer>
        <div class="container-fluid">
            <div>© 2021 Parkfinder  </div>
            <div>
                <nav class="nav">
                    <a href="#" class="nav-link">Licenses</a>
                    <a href="#" class="nav-link">Change Log</a>
                    <a href="#" class="nav-link">Get Help</a>
                </nav>
            </div>
        </div>
    </footer>
    <!-- end::footer -->

    </div>
    <!-- end::main-content -->

</div>
<!-- end::main -->

<!-- Plugin scripts -->
<script src="js/bundle.js"></script>


<!-- App scripts -->
<script src="js/app.min.js"></script>

</body>

<!-- Mirrored from primex.laborasyon.com/demos/vertical/dark/pages-profile.php by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 08 Jun 2021 18:22:52 GMT -->
</html>
