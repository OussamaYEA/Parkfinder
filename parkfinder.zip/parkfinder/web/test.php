<?php
    $curl = curl_init("http://192.168.1.177/");
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); 
    $result = curl_exec($curl);
    $result = json_decode( $result, true);
    //print_r( $result );
    print $result["Place"];

?>